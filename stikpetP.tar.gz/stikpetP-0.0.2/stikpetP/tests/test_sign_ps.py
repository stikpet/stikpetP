import pandas as pd
from scipy.stats import binom
from statistics import NormalDist
from ..other.table_cross import tab_cross

def ts_sign_ps(field1, field2, levels=None, dmu=0, method="exact"):
    
    ct = tab_cross(field1, field2, order1=levels, order2=levels)
    k1 = ct.shape[0]
    k2 = ct.shape[1]
    
    if levels is not None:
        #replace row labels with numeric score
        ct = ct.reset_index(drop=True) 
        ct.columns = [i for i in range(0, k2)]
    
    npos = 0
    nneg = 0
    for i in range(0, k1):
        for j in range(0, k2):
            if i != j:
                if ct.index[i] - ct.columns[j] > dmu:
                    npos = npos + ct.iloc[i, j]
                elif ct.index[i] - ct.columns[j] < dmu:
                    nneg = nneg + ct.iloc[i, j]
                
    nc = nneg + npos
    nMin = npos
    nMax = nneg
    
    if nneg < npos:
        nMin = nneg
        nMax = npos
    
    if method == "exact":
        z = None
        p = 2 * binom.cdf(nMin, nc, 0.5)
    elif method=="appr":
        z = (nMax - 0.5 * nc - 0.5) / (0.5 * (nc)**0.5)
        p = 2 * (1 - NormalDist().cdf(abs(z)))
    
    res = pd.DataFrame([[npos, nneg, z, p]])
    res.columns = ["n pos", "n neg", "statistic", "p-value"]
    
    return res