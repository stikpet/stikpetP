import pandas as pd
from scipy.stats import chi2
from numpy.linalg import inv
from numpy import matmul, array, transpose
from ..other.table_cross import tab_cross

def ts_stuart_maxwell(field1, field2, categories=None):
    #create the cross table
    ct = tab_cross(field1, field2, categories, categories, totals="include")    
    
    #basic counts
    k = ct.shape[0]-1
    n = ct.iloc[k, k]
    
    #STEP 1: Convert to percentages based on grand total
    p = pd.DataFrame()
    for i in range(0, k+1):
        for j in range(0, k + 1):
            p.at[i, j] = ct.iloc[i, j] / n
    
    #STEP 2: Determine the differences between the row and the column totals
    d = [0]*(k - 1)
    for i in range(0, k - 1):
        d[i] = p.iloc[i, k] - p.iloc[k, i]
    
    #STEP 3: Create the variance and covariance matrix
    
    S = pd.DataFrame()
    for i in range(0, k - 1):
        for j in range(0, k - 1):
            if i == j:
                S.at[i, j] = p.iloc[i, k] + p.iloc[k, j] - 2 * p.iloc[i, j]
            else:
                S.at[i, j] = -(p.iloc[i, j] + p.iloc[j, i])
    
    Sinv = inv(S)
    chiVal = sum(matmul(n * array(d).transpose(), Sinv) * d)
    
    #test
    df = k - 1
    pvalue = chi2.sf(chiVal, df)
    
    #results
    colNames = ["n", "statistic", "df", "p-value"]
    results = pd.DataFrame([[n, chiVal, df, pvalue]], columns=colNames)
    
    return results