import pandas as pd
from scipy.stats import rankdata
from scipy.stats import f
from scipy.stats import chi2

def ts_friedman(data, levels=None, ties=True, adj=None):
    
    #Remove rows with missing values and reset index
    data = data.dropna()    
    data = data.reset_index(drop=True)        
        
    nr = len(data)
    k = len(data.columns)
    
    if levels is not None:
        data = data.replace(levels)
    
    ranks = pd.DataFrame()
    for i in range(0, nr):
        rankRow = pd.Series(rankdata(data.iloc[i, :]))
        ranks[i] = rankRow
    
    ranks = ranks.transpose()
    
    rs = ranks.sum().sum()
    rm = rs/(nr*k)
    
    #Determine for each variable the average rank, and
    #the squared difference of this average with the overall average rank.
    rmj = ranks.sum()/nr
    rs2 = ((rmj*nr)**2).sum()
    sst = nr*((rmj - rm)**2).sum()
    sse = ranks.stack().var(ddof=0)*k/(k-1)
    
    if ties:
        qadj = sst / sse
    else:
        qadj = 12 / (nr * k * (k + 1)) * rs2 - 3 * nc * (k + 1)
    
    df = k - 1
    
    if adj=="iman-davenport":
        fVal = (nc - 1) * qadj / (nc * (k - 1) - qadj)
        df1 = df
        df2 = (k - 1) * (nc - 1)
        p = f.sf(fVal, df1, df2)
        
        res = pd.DataFrame([[nr, fVal, df1, df2, p]])
        res.columns = ["n", "statistic", "df1", "df2", "p-value"]
        
    else:
        p = chi2.sf(qadj, df)
        res = pd.DataFrame([[nr, qadj, df, p]])
        res.columns = ["n", "statistic", "df", "p-value"]
    
    return res