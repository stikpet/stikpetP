import pandas as pd
from scipy.stats import chi2
from scipy.stats import gamma
from scipy.stats import f
from scipy.stats import beta
from ..other.table_cross import tab_cross

def ts_kruskal_wallis(catField, ordField, categories=None, levels=None,  method = "chi2", tiescorr = True):
    # "chi2", "kw-gamma", "kw-gamma-chi2", "kw-beta", "kw-beta-f", "wallace-f1", "wallace-f2", "wallace-f3", "wallace-beta1", "wallace-beta2", "wallace-beta3", "ids"
    #Excel results differ if df is non-integer
    
    #create the cross table
    ct = tab_cross(ordField, catField, levels, categories, totals="include")    
    
    #basic counts
    k = ct.shape[1]-1
    nlvl = ct.shape[0]-1
    n = ct.iloc[nlvl, k]
    
    #the ranks of the levels
    lvlRank = pd.DataFrame()
    cf = 0
    for i in range(0, nlvl):
        lvlRank.at[i,0] = (2 * cf + ct.iloc[i, k] + 1) / 2
        cf = cf + ct.iloc[i, k] 
    
    #sum of ranks per category
    srj = pd.DataFrame()
    n = 0
    for j in range(0, k):
        sr = 0
        for i in range(0, nlvl):
            sr = sr + ct.iloc[i, j] * lvlRank.iloc[i,0]
        srj.at[j,0] = sr
        n = n + ct.iloc[nlvl, j]

    #H
    h = 0
    for i in range(0, k):
        h = h + srj.iloc[i,0]**2 / ct.iloc[nlvl, i]
    h = 12 / (n * (n + 1)) * h - 3 * (n + 1)
    
    if tiescorr:
        #ties
        t = 0
        for i in range(0, nlvl):
            tf = ct.iloc[i, k]
            t = t + tf**3 - tf
        
        #Hadj
        h = h / (1 - t / (n**3 - n))
    
    Var = 0
    for i in range(0, k):
        Var = Var + 1 / ct.iloc[nlvl, i]
    Var = 2 * (k - 1) - (2 * (3 * k**2 - 6 * k + n * (2 * k**2 - 6 * k + 1))) / (5 * n * (n + 1)) - 6 / 5 * Var
    
    mu = k - 1
    
    res = pd.DataFrame()
    if method=="chi2":
        #kw chi2 appr
        df = mu
        p = chi2.sf(h, df)
        
        colnames = ["n", "h", "df", "p-value"]        
        res = pd.DataFrame([[n, h, df, p]], columns=colnames)
    
    elif method == "kw-gamma":
        #kw gamma appr
        bet = Var / mu
        alp = mu**2 / Var
        p = 2 * (1 - gamma.cdf(h, alp, scale=bet))
        
        colnames = ["n", "h", "alpha", "beta", "p-value"]
        res = pd.DataFrame([[n, h, alp, bet, p]], columns=colnames)
    
    elif method == "kw-gamma-chi2":
        #kw gamma chi appr
        chi2Val = 2 * mu / Var * h
        df = 2 * mu**2 / Var
        p = chi2.sf(chi2Val, df)
        
        colnames = ["n", "h", "chi2 statistic", "df", "p-value"]        
        res = pd.DataFrame([[n, h, chi2Val, df, p]], columns=colnames)
    
    elif method == "kw-beta" or method == "kw-beta-f" :
        #kw beta appr and
        m = 0
        for i in range(0, k):
            m = ct.iloc[nlvl, i]**3        
        m = (n**3 - m) / (n * (n + 1))
        df1 = mu * (mu * (m - mu) - Var) / (0.5 * m * Var)
        df2 = df1 * (m - mu) / mu
        
        if method == "kw-beta":
            #kw beta appr
            alp = df1 * 0.5
            bet = df2 * 0.5
            p = 1 - gamma.cdf(h / m, alp, scale=1/bet)
            
            colnames = ["n", "h", "B2", "alpha", "beta", "p-value"]
            res = pd.DataFrame([[n, h, h/m, alp, bet, p]], columns=colnames)
        else:
            #kw beta F appr
            fVal = h * (m - mu) / (mu * (m - h))
            p = f.sf(fVal, df1, df2)
            
            colnames = ["n", "h", "F statistic", "df1", "df2", "p-value"]
            res = pd.DataFrame([[n, h, fVal, df1, df2, p]], columns=colnames)
    else:
        if method == "wallace-beta1" or method == "wallace-f1":
            d = ((n - k) * (k - 1) - Var) / (0.5 * (n - 1 - h))
        elif method == "wallace-beta2" or method == "wallace-f2":
            d = 1 - 6 * (n + 1) / (5 * (n - 1) * (n + 12))
        elif method == "wallace-beta3" or method == "wallace-f3":
            d = 1
        if method in ["wallace-f1", "wallace-f2", "wallace-f3", "wallace-beta1", "wallace-beta2", "wallace-beta3"]:
            df1 = (k - 1) * d
            df2 = (n - k) * d
        
        if method in ["wallace-f1", "wallace-f2", "wallace-f3"]:
            fw = (n - k) * h / ((k - 1) * (n - 1 - h))
            p = f.sf(fw, df1, df2)
            
            colnames = ["n", "h", "F statistic", "df1", "df2", "p-value"]
            res = pd.DataFrame([[n, h, fw, df1, df2, p]], columns=colnames)
            
        elif method in ["wallace-beta1", "wallace-beta2", "wallace-beta3"]:
            b = h / (n - 1)
            alp = df1 * 0.5
            bet = df2 * 0.5
            
            p = beta.sf(b, alp, bet)
            
            colnames = ["n", "h", "B2", "alpha", "beta", "p-value"]
            res = pd.DataFrame([[n, h, b, alp, bet, p]], columns=colnames)
        
        elif method == "ids":
            fw = (n - k) * h / ((k - 1) * (n - 1 - h))                        
            rm = pd.DataFrame()
            for j in range(0, k):
                rm.at[j,0] = srj.iloc[j,0] / ct.iloc[nlvl, j]
            
            v = pd.DataFrame()
            for j in range(0, k):
                vval = 0
                for i in range(0, nlvl):
                    vval = vval + (lvlRank.iloc[i,0] - rm.iloc[j,0])**2                
                vval = vval / ct.iloc[nlvl, j]
                v.at[j,0] = vval
            
            num = 0
            den = 0
            for j in range(0, k):
                num = (ct.iloc[nlvl, j] - 1) * v.iloc[j,0]
                den = ((ct.iloc[nlvl, j] - 1) * v.iloc[j,0])**2 / (ct.iloc[nlvl, j] - 1)
            
            df2 = num**2 / den
            df1 = k - 1
            p = f.sf(fw, df1, df2)
            
            colnames = ["n", "h", "F statistic", "df1", "df2", "p-value"]
            res = pd.DataFrame([[n, h, fw, df1, df2, p]], columns=colnames)
        
    
    return res