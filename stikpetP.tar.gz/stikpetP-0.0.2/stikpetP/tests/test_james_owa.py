import pandas as pd
from scipy.stats import chi2

def ts_james_owa(nomField, scaleField, categories=None, order=2, variation=2):
    if type(nomField) == list:
        nomField = pd.Series(nomField)
        
    if type(scaleField) == list:
        scaleField = pd.Series(scaleField)
        
    data = pd.concat([nomField, scaleField], axis=1)
    data.columns = ["category", "score"]
    
    #remove unused categories
    if categories is not None:
        data = data[data.category.isin(categories)]
    
    #Remove rows with missing values and reset index
    data = data.dropna()    
    data.reset_index()
    
    #overall n, mean and ss
    n = len(data["category"])
    m = data.score.mean()
    sst = data.score.var()*(n-1)
    
    #sample sizes, variances and means per category
    nj = data.groupby('category').count()
    sj2 = data.groupby('category').var()
    mj = data.groupby('category').mean()
    
    #number of categories
    k = len(mj)
    
    wj = nj / sj2
    w = float(wj.sum())
    hj = wj/w
    yw = float((hj*mj).sum())
    
    Jstat = float((wj*(mj - yw)**2).sum())
    
    if order==0:
        testUsed = "James large-sample approximation"
        
        df = k - 1
        pVal = chi2.sf(Jstat, df)
        res = pd.DataFrame([[n, Jstat, df, pVal, testUsed]])
        res.columns = ["n", "statistic", "df", "p-value", "test"]
    
    elif order==1:
        testUsed = "James first-order"
        vj = nj - 1
        lm = float(((1 - hj)**2/vj).sum())
        
        df = k - 1
        pLow=0
        pHigh=1
        pVal=.05
        nIter = 1
        
        c = chi2.ppf(1-pVal, df)
        jCrit = c*(1+(3*c+k+1)/(2*(k**2-1))*lm)
        jCritOriginal = jCrit
        while jCrit != Jstat and nIter < 100:
            if jCrit < Jstat:
                pHigh = pVal
                pVal = (pLow + pVal)/2
            elif jCrit > Jstat:
                pLow = pVal
                pVal = (pHigh + pVal)/2
                
            c = chi2.ppf(1-pVal, df)
            jCrit = c*(1+(3*c+k+1)/(2*(k**2-1))*lm)
            
            nIter = nIter + 1
            
        res = pd.DataFrame([[n, Jstat, df, pVal, testUsed]])
        res.columns = ["n", "statistic", "df", "p-value", "test"]
    
    elif order==2:
        testUsed = "James second-order"
        vj = nj-variation
        lm = float(((1 - hj)**2/vj).sum())
        
        #R values
        R10 = float((hj**0/(vj**1)).sum())
        R11 = float((hj**1/(vj**1)).sum())
        R12 = float((hj**2/(vj**1)).sum())
        R20 = float((hj**0/(vj**2)).sum())
        R21 = float((hj**1/(vj**2)).sum())
        R22 = float((hj**2/(vj**2)).sum())
        R23 = float((hj**3/(vj**2)).sum())
        
        #determine denominator for chi-variables
        chi2den = k + 2 * 1 - 3
        chi4den = chi2den * (k + 2 * 2 - 3)
        chi6den = chi4den * (k + 2 * 3 - 3)
        chi8den = chi6den * (k + 2 * 4 - 3)
        
        df = k - 1
        pLow=0
        pHigh=1
        pVal=.05
        nIter = 1
        loop = True
        original = True
        
        while loop:
            #critical chi-square value
            c = chi2.ppf(1-pVal, df)
            
            #chi-variables
            chi2v = c / chi2den
            chi4 = c**2 / chi4den
            chi6 = c**3 / chi6den
            chi8 = c**4 / chi8den

            prt1 = c + 1 / 2 * (3 * chi4 + chi2v) * lm + 1 / 16 * (3 * chi4 + chi2v)**2 * (1 - (k - 3) / c) * lm**2
            prt2a = 1 / 2 * (3 * chi4 + chi2v)
            prt2b = (8 * R23 - 10 * R22 + 4 * R21 - 6 * R12 **2 + 8 * R12 * R11 - 4 * R11 **2)
            prt2c = (2 * R23 - 4 * R22 + 2 * R21 - 2 * R12**2 + 4 * R12 * R11 - 2 * R11**2) * (chi2v - 1)
            prt2d = 1 / 4 * (-1 * R12 **2 + 4 * R12 * R11 - 2 * R12 * R10 - 4 * R11 **2 + 4 * R11 * R10 - R10 **2) * (3 * chi4 - 2 * chi2v - 1)
            prt2 = prt2a * (prt2b + prt2c + prt2d)
            prt3 = (R23 - 3 * R22 + 3 * R21 - R20) * (5 * chi6 + 2 * chi4 + chi2v)
            prt4 = 3 / 16 * (R12**2 - 4 * R23 + 6 * R22 - 4 * R21 + R20) * (35 * chi8 + 15 * chi6 + 9 * chi4 + 5 * chi2v)
            prt5 = 1 / 16 * (-2 * R22 + 4 * R21 - R20 + 2 * R12 * R10 - 4 * R11 * R10 + R10**2) * (9 * chi8 - 3 * chi6 - 5 * chi4 - chi2v)
            prt6 = 1 / 4 * (-1 * R22 + R11**2) * (27 * chi8 + 3 * chi6 + chi4 + chi2v)
            prt7 = 1 / 4 * (R23 - R12 * R11) * (45 * chi8 + 9 * chi6 + 7 * chi4 + 3 * chi2v)

            Jcrit = prt1 + prt2 + prt3 + prt4 + prt5 + prt6 + prt7
            
            if original:
                JcritOr = Jcrit
                original = False
            
            if Jcrit < Jstat:
                pHigh = pVal
                pVal = (pLow + pVal) / 2
            elif Jcrit > Jstat:
                pLow = pVal
                pVal = (pHigh + pVal) / 2

            nIter = nIter + 1
            
            if nIter > 100 or Jcrit==Jstat:
                loop = False
        
        res = pd.DataFrame([[n, Jstat, JcritOr, df, pVal, testUsed]])
        res.columns = ["n", "statistic", "J critical", "df", "p-value", "test"]
        
    
    return res