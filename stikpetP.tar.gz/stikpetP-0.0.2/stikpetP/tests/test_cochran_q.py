import pandas as pd
from scipy.stats import chi2

def ts_cochran_q(data, success=None):
    
    #Remove rows with missing values and reset index
    data = data.dropna()    
    data = data.reset_index(drop=True)
    
    n = len(data)
    k = len(data.columns)
    
    if success is None:
        suc = data.iloc[0,0]
    else:
        suc = success
    
    isSuc = data == suc
    cj = isSuc.sum()
    ri = isSuc.sum(axis=1)
    ns = cj.sum()
    cm = ns/k
    
    q = k*(k - 1)*((cj - cm)**2).sum() / (k*ns - (ri**2).sum())
    df = k - 1
    pVal = chi2.sf(q, df)
    
    res = pd.DataFrame([[n, q, df, pVal]])
    res.columns = ["n", "statistic", "df", "p-value"]
    
    return res