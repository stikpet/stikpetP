import pandas as pd
from scipy.stats import binom
from statistics import NormalDist
from ..other.table_cross import tab_cross
from ..distributions.dist_multinomial import di_mpmf

def ts_trinomial_ps(field1, field2, levels=None, dmu=0):
    
    ct = tab_cross(field1, field2, order1=levels, order2=levels)
    k1 = ct.shape[0]
    k2 = ct.shape[1]
    
    if levels is not None:
        #replace row labels with numeric score
        ct = ct.reset_index(drop=True) 
        ct.columns = [i for i in range(0, k2)]
    
    npos = 0
    nneg = 0
    n0 = 0
    for i in range(0, k1):
        for j in range(0, k2):
            if ct.index[i] - ct.columns[j] > dmu:
                npos = npos + ct.iloc[i, j]
            elif ct.index[i] - ct.columns[j] < dmu:
                nneg = nneg + ct.iloc[i, j]
            else:
                n0 = n0 + ct.iloc[i, j]
                
    nc = nneg + npos
    nMin = npos
    nMax = nneg
    
    n = npos + nneg + n0
    nd = abs(npos - nneg)
    p0 = n0 / n
    ppos = (1 - p0) / 2
    pneg = ppos
    probs = [ppos, pneg, p0]
    
    ns = [0]*3
    sig = 0
    for z in range(nd, n+1):
        for j in range(0, int((n - z)/2)+1):
            ns[0] = j
            ns[1] = j + z
            ns[2] = n - j - (j + z)
            sig = sig + di_mpmf(ns, probs)
    
    if sig < 0.5:
        pVal = sig * 2
    else:
        pVal = 2 * (1 - pVal)
    
    res = pd.DataFrame([[npos, nneg, n0, pVal]])
    res.columns = ["n pos", "n neg", "n 0", "p-value"]
    
    return res