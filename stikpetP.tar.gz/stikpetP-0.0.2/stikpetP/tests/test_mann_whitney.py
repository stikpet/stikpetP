import pandas as pd
from scipy.stats import rankdata
from statistics import NormalDist
from ..distributions.dist_permutation2 import di_perm2cdf

def ts_mann_whitney(catField, ordField, categories=None, levels=None, method="exact", cc=True):
    #convert to pandas series if needed
    if type(catField) is list:
        catField = pd.Series(catField)
    
    if type(ordField) is list:
        ordField = pd.Series(ordField)
    
    #combine as one dataframe
    df = pd.concat([catField, ordField], axis=1)
    df = df.dropna()
    
    #replace the ordinal values if levels is provided
    if levels is not None:
        df.iloc[:,1] = df.iloc[:,1].replace(levels)
        df.iloc[:,1]  = pd.to_numeric(df.iloc[:,1] )
    else:
        df.iloc[:,1]  = pd.to_numeric(df.iloc[:,1] )
    
    #the two categories
    if categories is not None:
        cat1 = categories[0]
        cat2 = categories[1]
    else:
        cat1 = df.iloc[:,0].value_counts().index[0]
        cat2 = df.iloc[:,0].value_counts().index[1]
    
    #seperate the scores for each category
    scoresCat1 = list(df.iloc[:,1][df.iloc[:,0] == cat1])
    scoresCat2 = list(df.iloc[:,1][df.iloc[:,0] == cat2])
    
    n1 = len(scoresCat1)
    n2 = len(scoresCat2)
    N = n1 + n2
    
    #combine this into one long list
    allScores = scoresCat1 + scoresCat2
    
    #get the ranks
    allRanks = rankdata(allScores)
    
    #get the ranks per category
    cat1Ranks = allRanks[0:n1]
    cat2Ranks = allRanks[n1:N]
    
    R1 = sum(cat1Ranks)
    R2 = sum(cat2Ranks)
    
    #The U statistics
    U1 = R1 - n1 * (n1 + 1) / 2
    U2 = R2 - n2 * (n2 + 1) / 2
    U = min(U1, U2)
    
    #The count of each rank
    counts = pd.Series(allRanks).value_counts()
    
    #check if ties exist
    if max(counts)>1 and method=="exact":
        print("ties exist, swith to approximate")
        method="approx"
    
    if method=="exact":
        testUsed = "Mann-Whitney U exact"
        nMin = min(n1, n2)
        nMax = max(n1, n2)
        
        p = di_perm2cdf(u, nMin, nMax)
        
        if U >= n1 * n2 / 2:
            p = 1 - p
        
        p = 2 * p        
        statistic = "n.a."
    else:    
        testUsed = "Mann-Whitney U normal approximation"
        T = sum(counts**3-counts)/12

        SE = (n1 * n2 / (N * (N - 1)) * ((N**3 - N) / 12 - T)) ** 0.5

        Z1 = (2 * U1 - n1 * n2) / (2 * SE)
        Z2 = (2 * U2 - n1 * n2) / (2 * SE)
        
        zabs = abs(Z1)
        
        if cc:
            zabs = zabs - 0.5/SE
            testUsed = "Mann-Whitney U normal approximation, with continuity correction"
        
        pValue = 2 * (1 - NormalDist().cdf(zabs)) 
        statistic = zabs
        
    #the results
    results = pd.DataFrame([[N, U1, U2, statistic, pValue, testUsed]], columns=["n", "U1", "U2", "statistic", "p-value", "test"])
    
    return results