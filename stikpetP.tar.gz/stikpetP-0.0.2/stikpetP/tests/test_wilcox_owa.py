import pandas as pd
from scipy.stats import chi2

def ts_wilcox_owa(nomField, scaleField, categories=None):
    if type(nomField) == list:
        nomField = pd.Series(nomField)
        
    if type(scaleField) == list:
        scaleField = pd.Series(scaleField)
        
    data = pd.concat([nomField, scaleField], axis=1)
    data.columns = ["category", "score"]
    
    #remove unused categories
    if categories is not None:
        data = data[data.category.isin(categories)]
    
    #Remove rows with missing values and reset index
    data = data.dropna()    
    data.reset_index()
    
    #overall n, mean and ss
    n = len(data["category"])
    m = data.score.mean()
    sst = data.score.var()*(n-1)
    
    #sample sizes, variances and means per category
    nj = data.groupby('category').count()
    sj2 = data.groupby('category').var()
    mj = data.groupby('category').mean()
    xj = data.groupby('category').max()
    sj = data.groupby('category').sum()
    
    #number of categories
    k = len(mj)
    
    t = float((sj2/nj).max())
    bj = (1 + ((nj - 1)*(nj*t - sj2)/sj2)**0.5) / nj
    wj = bj*xj + (1 - bj)/nj * (sj - xj)
    wm = wj.sum()/k
    
    h = float(((wj - wm)**2).sum()/t)
    df = k - 1    
    pVal = chi2.sf(h, df)
    
    #results
    res = pd.DataFrame([[n, h, df, pVal]])
    res.columns = ["n", "statistic", "df", "p-value"]
    
    return res