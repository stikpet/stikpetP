import pandas as pd
from statistics import NormalDist

def ts_z_ps(field1, field2, dmu=0, dsigma=None):
    if type(field1) == list:
        field1 = pd.Series(field1)
        
    if type(field2) == list:
        field2 = pd.Series(field2)
    
    data = pd.concat([field1, field2], axis=1)
    data.columns = ["field1", "field2"]
    #Remove rows with missing values and reset index
    data = data.dropna()    
    data.reset_index()
    
    #overall n
    n = len(data["field1"])
    
    data["diffs"] = data["field1"] - data["field2"]
    if dsigma is None:
        dsigma = data["diffs"].std()
        
    dm = data["diffs"].mean()
    se = dsigma/n**0.5
    z = (dm - dmu)/se
    pvalue = 2 * (1 - NormalDist().cdf(abs(z)))
    
    res = pd.DataFrame([[n, z, pvalue]])
    res.columns = ["n", "z", "p-value"]
    
    return res