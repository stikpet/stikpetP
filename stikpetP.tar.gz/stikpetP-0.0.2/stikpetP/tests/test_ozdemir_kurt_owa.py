import pandas as pd
from scipy.stats import chi2
from scipy.stats import norm
from numpy import log

def ts_ozdemir_kurt_owa(nomField, scaleField, categories=None):
    if type(nomField) == list:
        nomField = pd.Series(nomField)
        
    if type(scaleField) == list:
        scaleField = pd.Series(scaleField)
        
    data = pd.concat([nomField, scaleField], axis=1)
    data.columns = ["category", "score"]
    
    #remove unused categories
    if categories is not None:
        data = data[data.category.isin(categories)]
    
    #Remove rows with missing values and reset index
    data = data.dropna()    
    data.reset_index()
    
    #overall n, mean and ss
    n = len(data["category"])
    m = data.score.mean()
    sst = data.score.var()*(n-1)
    
    #sample sizes, variances and means per category
    nj = data.groupby('category').count()
    sj2 = data.groupby('category').var()
    mj = data.groupby('category').mean()
    
    #number of categories
    k = len(mj)
    
    sej = (sj2/nj)**0.5
    wj = nj/sj2
    w = float(wj.sum())
    hj = wj/w
    wm = float((hj*mj).sum())
    vj = nj - 1
    tj = (mj - wm)/sej
    
    pVal = 0.05
    zcrit = norm.ppf(1-pVal/2)
    cj = (4*vj**2 + 5*(2*zcrit**2 + 3)/24)/(4*vj**2 + vj + (4*zcrit**2+9)/12) * vj**0.5
    b2 = float(((cj**2*log(1+tj**2/vj))).sum())
    df = k - 1
    chiCrit = chi2.ppf(1 - pVal, df)
    
    nIter = 0    
    pLow = 0
    pHigh = 1
    
    while b2 != chiCrit and nIter < 100:
            if chiCrit < b2:
                pHigh = pVal
                pVal = (pLow + pVal)/2
            elif chiCrit > b2:
                pLow = pVal
                pVal = (pHigh + pVal)/2
                
            zcrit = norm.ppf(1-pVal/2)
            cj = (4*vj**2 + 5*(2*zcrit**2 + 3)/24)/(4*vj**2 + vj + (4*zcrit**2+9)/12) * vj**0.5
            b2 = float(((cj**2*log(1+tj**2/vj))).sum())
            chiCrit = chi2.ppf(1 - pVal, df)
            
            nIter = nIter + 1
    
    pVal = chi2.sf(b2, df)
    
    #results
    res = pd.DataFrame([[n, b2, df, pVal]])
    res.columns = ["n", "statistic", "df", "p-value"]
    
    return res