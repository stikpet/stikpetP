import pandas as pd
from scipy.stats import f

def ts_welch_owa(nomField, scaleField, categories=None):
    if type(nomField) == list:
        nomField = pd.Series(nomField)
        
    if type(scaleField) == list:
        scaleField = pd.Series(scaleField)
        
    data = pd.concat([nomField, scaleField], axis=1)
    data.columns = ["category", "score"]
    
    #remove unused categories
    if categories is not None:
        data = data[data.category.isin(categories)]
    
    #Remove rows with missing values and reset index
    data = data.dropna()    
    data.reset_index()
    
    #overall n, mean and ss
    n = len(data["category"])
    m = data.score.mean()
    sst = data.score.var()*(n-1)
    
    #sample sizes, variances and means per category
    nj = data.groupby('category').count()
    sj2 = data.groupby('category').var()
    mj = data.groupby('category').mean()
    
    #number of categories
    k = len(mj)
    
    wj = nj / sj2
    w = float(wj.sum())
    hj = wj/w
    yw = float((hj*mj).sum())
    lm = float(((1 - hj)**2/(nj - 1)).sum())
    
    chi2Val = float((wj*(mj - yw)**2).sum())
    fVal = chi2Val / ((k - 1)+2*lm*(k - 2)/(k+1))
    
    df1 = k - 1
    df2 = (k**2 - 1)/(3*lm)
    pVal = f.sf(fVal, df1, df2)
    
    #results
    res = pd.DataFrame([[n, fVal, df1, df2, pVal]])
    res.columns = ["n", "statistic", "df1", "df2", "p-value"]
    
    return res