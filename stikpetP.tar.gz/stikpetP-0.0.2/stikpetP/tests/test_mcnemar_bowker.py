import pandas as pd
from scipy.stats import chi2
from ..other.table_cross import tab_cross

def ts_mcnemar_bowker(field1, field2, categories=None):
    #create the cross table
    ct = tab_cross(field1, field2, categories, categories, totals="include")    
    
    #basic counts
    k = ct.shape[0]-1
    n = ct.iloc[k, k]
    
    chiVal = 0
    for i in range(0, k-1):
        for j in range(i+1, k):
            chiVal = chiVal + (ct.iloc[i, j] - ct.iloc[j, i])**2 / (ct.iloc[i, j] + ct.iloc[j, i])
    
    df = k * (k - 1) / 2
    pvalue = chi2.sf(chiVal, df)
    
    #results
    colNames = ["n", "statistic", "df", "p-value"]
    results = pd.DataFrame([[n, chiVal, df, pvalue]], columns=colNames)
    
    return results