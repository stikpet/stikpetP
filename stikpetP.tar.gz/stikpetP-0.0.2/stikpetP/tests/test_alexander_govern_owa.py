import pandas as pd
from scipy.stats import chi2
from numpy import log

def ts_alexander_govern_owa(nomField, scaleField, categories=None):
    if type(nomField) == list:
        nomField = pd.Series(nomField)
        
    if type(scaleField) == list:
        scaleField = pd.Series(scaleField)
        
    data = pd.concat([nomField, scaleField], axis=1)
    data.columns = ["category", "score"]
    
    #remove unused categories
    if categories is not None:
        data = data[data.category.isin(categories)]
    
    #Remove rows with missing values and reset index
    data = data.dropna()    
    data.reset_index()
    
    #overall n, mean and ss
    n = len(data["category"])
    m = data.score.mean()
    sst = data.score.var()*(n-1)
    
    #sample sizes, variances and means per category
    nj = data.groupby('category').count()
    sj2 = data.groupby('category').var()
    mj = data.groupby('category').mean()
    
    #number of categories
    k = len(mj)
    
    sej = (sj2/nj)**0.5
    ssej = (1/sej**2).sum()
    wj = 1/(sej**2 * ssej)
    ym = (wj*mj).sum()
    tj = (mj - ym)/sej
    aj = nj - 1.5
    bj = 48*aj**2
    cj = (aj*log(1+tj**2/(nj - 1)))**0.5
    zj = cj + (cj**3 + 3*cj)/bj - (4*cj**7 + 33*cj**5 + 240*cj**3 + 855*cj)/(10*bj**2 + 8*bj*cj**4 + 1000*bj)
    
    a = float((zj**2).sum())
    df = k - 1
    
    pVal = chi2.sf(a, df)
    
    #results
    res = pd.DataFrame([[n, a, df, pVal]])
    res.columns = ["n", "statistic", "df", "p-value"]
    
    return res