import pandas as pd
from scipy.stats import t 

def ts_student_t_ps(field1, field2, dmu=0):
    if type(field1) == list:
        field1 = pd.Series(field1)
        
    if type(field2) == list:
        field2 = pd.Series(field2)
    
    data = pd.concat([field1, field2], axis=1)
    data.columns = ["field1", "field2"]
    #Remove rows with missing values and reset index
    data = data.dropna()    
    data.reset_index()
    
    #overall n
    n = len(data["field1"])
    
    data["diffs"] = data["field1"] - data["field2"]
    dsigma = data["diffs"].std()
    dm = data["diffs"].mean()
    se = dsigma/n**0.5
    tval = (dm - dmu)/se
    df = n - 1
    pvalue = 2 * (1 - t.cdf(abs(tval), df))
    
    res = pd.DataFrame([[n, tval, df, pvalue]])
    res.columns = ["n", "statistic", "df", "p-value"]
    
    return res