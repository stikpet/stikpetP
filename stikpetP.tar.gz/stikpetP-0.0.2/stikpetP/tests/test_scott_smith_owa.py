import pandas as pd
from scipy.stats import chi2

def ts_scott_smith_owa(nomField, scaleField, categories=None):
    if type(nomField) == list:
        nomField = pd.Series(nomField)
        
    if type(scaleField) == list:
        scaleField = pd.Series(scaleField)
        
    data = pd.concat([nomField, scaleField], axis=1)
    data.columns = ["category", "score"]
    
    #remove unused categories
    if categories is not None:
        data = data[data.category.isin(categories)]
    
    #Remove rows with missing values and reset index
    data = data.dropna()    
    data.reset_index()
    
    #overall n, mean and ss
    n = len(data["category"])
    m = data.score.mean()
    sst = data.score.var()*(n-1)
    
    #sample sizes, variances and means per category
    nj = data.groupby('category').count()
    sj2 = data.groupby('category').var()
    mj = data.groupby('category').mean()
    
    #number of categories
    k = len(mj)
    
    sj = sj2**0.5
    tj = (mj - m)*nj**0.5 / sj
    dj = tj*((nj-3)/(nj-1))**0.5
    
    chiVal = float((dj**2).sum())
    df = k
    
    pVal = chi2.sf(chiVal, df)
    
    #results
    res = pd.DataFrame([[n, chiVal, df, pVal]])
    res.columns = ["n", "statistic", "df", "p-value"]
    
    return res