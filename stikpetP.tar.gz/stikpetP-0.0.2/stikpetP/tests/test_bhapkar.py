import pandas as pd
from scipy.stats import chi2
from numpy.linalg import inv
from numpy import matmul, array, transpose
from ..other.table_cross import tab_cross

def ts_bhapkar(field1, field2, categories=None):
    #create the cross table
    ct = tab_cross(field1, field2, categories, categories, totals="include")    
    
    #basic counts
    k = ct.shape[0]-1
    n = ct.iloc[k, k]
    
    #STEP 1: Convert to percentages based on grand total
    p = pd.DataFrame()
    for i in range(0, k+1):
        for j in range(0, k + 1):
            p.at[i, j] = ct.iloc[i, j] / n
    
    #STEP 2: Determine the differences between the row and the column totals
    d = [0]*(k - 1)
    for i in range(0, k - 1):
        d[i] = p.iloc[i, k] - p.iloc[k, i]
    
    #STEP 3: Create the variance and covariance matrix
    #For values on the diagonal add the row and column p total,
    #subtract twice the cell p and then
    #subtract the squared difference between the row and column p total.
    
    #For values not on the diagonal add the mirrored cell p and then
    #add a minus sign, then subtract the product of
    #the difference of the row p total of the current cell and the column p total of the mirrored cell,
    #with the difference of the row p total of the mirrored cell and column p total of the current cell.
    
    S = pd.DataFrame()
    for i in range(0, k - 1):
        for j in range(0, k - 1):
            if i == j:
                S.at[i, j] = p.iloc[i, k] + p.iloc[k, j] - 2 * p.iloc[i, j] - (p.iloc[i, k] - p.iloc[k, j])**2
            else:
                S.at[i, j] = -(p.iloc[i, j] + p.iloc[j, i]) - (p.iloc[i, k] - p.iloc[k, i]) * (p.iloc[j, k] - p.iloc[k, j])
    
    Sinv = inv(S)
    chiVal = sum(matmul(n * array(d).transpose(), Sinv) * d)
    
    #test
    df = k - 1
    pvalue = chi2.sf(chiVal, df)
    
    #results
    colNames = ["n", "statistic", "df", "p-value"]
    results = pd.DataFrame([[n, chiVal, df, pvalue]], columns=colNames)
    
    return results