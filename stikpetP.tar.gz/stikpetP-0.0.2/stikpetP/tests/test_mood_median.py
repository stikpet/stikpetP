import pandas as pd
from ..other.table_cross import tab_cross
#from ..tests.test_fisher import ts_fisher
#from ..tests.test_freeman_tukey_ind import ts_freeman_tukey_ind
#from ..tests.test_g_ind import ts_g_ind
#from ..tests.test_mod_log_likelihood_ind import ts_mod_log_likelihood_ind
#from ..tests.test_neyman_ind import ts_neyman_ind
#from ..tests.test_pearson_ind import ts_pearson_ind
#from ..tests.test_powerdivergence_ind import ts_powerdivergence_ind

def ts_mood_median(catField, ordField, categories=None, levels=None, test="pearson", cc=None, lambd=None):
    if lambd is None:
        lambd = 2/3
    
    #create the cross table    
    ct = tab_cross(ordField, catField, order1=levels, order2=categories, totals="include")
    
    #basic counts
    k = ct.shape[1]-1
    nlvl = ct.shape[0]-1
    n = ct.iloc[nlvl, k]
    
    #the overall median
    #note that this will not exactly determine a between value for the median
    #but thats okay since we only care if original values are above median or equal+ below
    medIndex = int((n + 1) / 2)
    cf = ct.iloc[0, k]
    med = 1
    while cf < medIndex:
        med = med + 1
        cf = cf + ct.iloc[med-1, k]
    
    #observed below and above overall median
    obs = pd.DataFrame()
    nbtot = 0
    natot = 0
    for j in range(0, k):
        nbelow = 0
        i = 1
        while i <= med:
            nbelow = nbelow + ct.iloc[i-1, j]
            i = i + 1
        obs.at[0, j] = nbelow
        nbtot = nbtot + nbelow
        natot = natot + ct.iloc[nlvl, j] - nbelow
        obs.at[1, j] = ct.iloc[nlvl, j] - nbelow
    
    catArr = pd.Series(dtype="object")
    ordArr = pd.Series(dtype="object")
    arrRow = 0
    for j in range(0, k):
        for i in range(0,2):
            for sc in range(0 , int(obs.loc[i, j])):
                catArr.at[arrRow] = ct.columns[j]
                ordArr.at[arrRow] = i+1
                arrRow = arrRow + 1
    
    #now for the test
    if test=="fisher":
        if k>2:
            test = "pearson"
        else:
            res = ts_fisher(catArr, ordArr)
    
    if test=="freeman-tukey":
        res = ts_freeman_tukey_ind(catArr, ordArr, cc=cc)
    elif test=="g":
        res = ts_g_ind(catArr, ordArr, cc=cc)
    elif test=="mod-log":
        res = ts_mod_log_likelihood_ind(catArr, ordArr, cc=cc)
    elif test=="neyman":
        res = ts_neyman_ind(catArr, ordArr, cc=cc)
    elif test=="pearson":
        res = ts_pearson_ind(catArr, ordArr, cc=cc)
    elif test=="power":
        res = ts_powerdivergence_ind(catArr, ordArr, cc=cc, lambd=lambd)
    
    return res