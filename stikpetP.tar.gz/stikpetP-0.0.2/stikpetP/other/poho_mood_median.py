import pandas as pd
from ..other.table_cross import tab_cross
from ..tests.test_mood_median import ts_mood_median

def ph_mood_median(catField, ordField, categories=None, levels=None, test="pearson", cc=None, lambd=None):
    
    #create the cross table    
    ct = tab_cross(ordField, catField, order1=levels, order2=categories, totals="include")
    
    #basic counts
    k = ct.shape[1]-1
    
    ncomp = (k * (k - 1)) / 2
    res = pd.DataFrame()    
    selCats= pd.Series(dtype="object")
    resRow = 0
    for i in range(0, k-1):
        for j in range(i + 1,k):
            res.at[resRow, 0] = ct.columns[i]
            res.at[resRow, 1] = ct.columns[j]
            
            selCats.at[0] = res.iloc[resRow, 0]
            selCats.at[1] = res.iloc[resRow, 1]
            
            tstRes = ts_mood_median(catField, ordField, selCats, levels, test, cc, lambd)
            
            if test=="fisher":                
                res.at[resRow, 2] = None
                res.at[resRow, 3] = None
                res.at[resRow, 4] = tstRes
                res.at[resRow, 5] = tstRes
                res.at[resRow, 6] = "Fisher exact"
            else:
                res.at[resRow, 2] = tstRes.iloc[0,3]
                res.at[resRow, 3] = tstRes.iloc[0,4]
                res.at[resRow, 4] = tstRes.iloc[0,5]
                res.at[resRow, 5] = tstRes.iloc[0,5]
                res.at[resRow, 6] = tstRes.iloc[0,8]
            
            res.at[resRow, 5] = res.iloc[resRow, 4] * ncomp
            if res.iloc[resRow, 5] > 1:
                res.at[resRow, 5] = 1            
            
            resRow = resRow + 1
    
    colNames = ["category 1","category 2","statistic", "df", "p-value","adj. p-value","test"]
    res.columns=colNames
    
    return res