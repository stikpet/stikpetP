import pandas as pd
from statistics import NormalDist
from ..other.table_cross import tab_cross

def ph_residual(field1, field2, categories1=None, categories2=None, residual="adjusted"):
    #create the cross table
    ct = tab_cross(field1, field2, categories1, categories2, totals="include")
  
    #basic counts
    nrows = ct.shape[0] - 1
    ncols =  ct.shape[1] - 1
    n = ct.iloc[nrows, ncols]
    
    res = pd.DataFrame()
    
    ipair=0
    for i in range(0, nrows):
        for j in range(0, ncols):
            res.loc[ipair, 0] = list(ct.index)[i]
            res.loc[ipair, 1] = list(ct.columns)[j]
            res.loc[ipair, 2] = ct.iloc[i, j]
            
            #expected count
            res.loc[ipair, 3] = ct.iloc[nrows, j] * ct.iloc[i, ncols] / n
            
            #residual
            res.loc[ipair, 4] = res.iloc[ipair, 2] - res.iloc[ipair, 3]
            
            #adjusted
            if (residual == "standardized"):
                se = res.iloc[ipair, 3]**0.5
            elif (residual == "adjusted"):
                se = (res.iloc[ipair, 3] * (1 - ct.iloc[i, ncols] / n) * (1 - ct.iloc[nrows, j] / n))**0.5
            
            res.loc[ipair, 5] = res.iloc[ipair, 4] / se
            
            #p-value
            res.loc[ipair, 6] = 2 * (1 - NormalDist().cdf(abs(res.iloc[ipair, 5])))
            
            #adj
            res.loc[ipair, 7] = res.iloc[ipair, 6] * nrows * ncols
            if (res.iloc[ipair, 7] > 1):
                res.iloc[ipair, 7] = 1
            ipair = ipair + 1
            
    
    #column names
    if (residual == "standardized"):
        resUsed = "st. residual"
    elif (residual == "adjusted"):
        resUsed = "adj. st. residual"        
    colNames = ["field1", "field2", "observed", "expected", "residual", resUsed, "p-value", "adj. p-value"]
    res.columns = colNames
    return (res)