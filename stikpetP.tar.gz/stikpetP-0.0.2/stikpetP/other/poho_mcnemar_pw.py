import pandas as pd
from scipy.stats import chi2
from scipy.stats import binom
from ..other.table_cross import tab_cross
from ..tests.test_mcnemar_bowker import ts_mcnemar_bowker

def ph_mcnemar_pw(field1, field2, categories=None, exact=False, cc=False):
    #create the cross table
    ct = tab_cross(field1, field2, categories, categories, totals="include")    
    
    #basic counts
    k = ct.shape[0]-1
    n = ct.iloc[k, k]
    
    #number of pairs
    ncomp = k*(k-1)/2
    
    resRow=0
    res = pd.DataFrame()
    for i in range(0, k-1):
        for j in range(i+1, k):
            cats = [ct.index[i], ct.index[j]]
            res.at[resRow,0] = ct.index[i]
            res.at[resRow,1] = ct.index[j]
            
            if exact:
                tab = tab_cross(field1, field2, order1=cats, order2=cats)
                n = tab.iloc[0,1] + tab.iloc[1,0]
                minCount = min(tab.iloc[0,1], tab.iloc[1,0])
                pVal = binom.cdf(minCount, n,0.5)
                if cc:
                    pVal = pVal - binom.pmf(minCount, n,0.5)
                
                stat = None
                df = None
            else:
                resMc = ts_mcnemar_bowker(field1, field2, categories=cats, cc=cc)
                n = resMc.iloc[0,0]
                stat = resMc.iloc[0,1]
                df = resMc.iloc[0,2]
                pVal = resMc.iloc[0,3]
                                                
            res.at[resRow,3] = n
            res.at[resRow,4] = stat
            res.at[resRow,5] = df
            res.at[resRow,6] = pVal
            res.at[resRow,7] = res.loc[resRow,6] * ncomp
            if res.loc[resRow,7] > 1:
                res.loc[resRow,7] = 1
            resRow = resRow + 1
    
    res.columns = ["field1", "field2", "n", "statistic", "df", "p-value", "adj. p-value"]
    
    return res