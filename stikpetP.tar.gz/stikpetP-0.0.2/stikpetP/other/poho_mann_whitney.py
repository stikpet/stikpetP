import pandas as pd
from ..other.table_cross import tab_cross
from ..tests.test_mann_whitney import ts_mann_whitney

def ph_mann_whitney(catField, ordField, categories=None, levels=None, method="appr", cc=True):
    
    #create the cross table    
    ct = tab_cross(ordField, catField, order1=levels, order2=categories, totals="include")
    
    #basic counts
    k = ct.shape[1]-1
    
    ncomp = (k * (k - 1)) / 2
    res = pd.DataFrame()    
    selCats= pd.Series(dtype="object")
    resRow = 0
    for i in range(0, k-1):
        for j in range(i + 1,k):
            res.at[resRow, 0] = ct.columns[i]
            res.at[resRow, 1] = ct.columns[j]
            
            selCats.at[0] = res.iloc[resRow, 0]
            selCats.at[1] = res.iloc[resRow, 1]
            mwu = ts_mann_whitney(catField, ordField, selCats, levels, method, cc)
            
            res.at[resRow, 2] = mwu.iloc[0, 3]
            res.at[resRow, 3] = mwu.iloc[0, 4]
            res.at[resRow, 4] = res.iloc[resRow, 3] * ncomp
            if res.iloc[resRow, 4] > 1:
                res.at[resRow, 4] = 1            
            res.at[resRow, 5] = mwu.iloc[0, 5]
            
            resRow = resRow + 1
    
    colNames = ["category 1","category 2","statistic","p-value","adj. p-value","test"]
    res.columns=colNames
    
    return res