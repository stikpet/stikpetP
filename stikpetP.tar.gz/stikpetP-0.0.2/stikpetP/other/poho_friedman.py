import pandas as pd
from scipy.stats import rankdata
from statistics import NormalDist
from scipy.stats import t 
from scipy.stats import studentized_range

def ph_friedman(data, levels=None, method = "dunn", ties=True):
    
    #Remove rows with missing values and reset index
    data = data.dropna()    
    data = data.reset_index(drop=True)        
        
    nr = len(data)
    k = len(data.columns)
    
    if levels is not None:
        data = data.replace(levels)
    
    ranks = pd.DataFrame()
    for i in range(0, nr):
        rankRow = pd.Series(rankdata(data.iloc[i, :]))
        ranks[i] = rankRow
    
    ranks = ranks.transpose()
    
    rs = ranks.sum().sum()
    rm = rs/(nr*k)
    
    #Determine for each variable the average rank, and
    #the squared difference of this average with the overall average rank.
    rmj = ranks.sum()/nr
    rs2 = (ranks**2).sum().sum()
    sst = nr*((rmj - rm)**2).sum()
    sse = ranks.stack().var(ddof=0)*k/(k-1)
    
    if ties:
        qadj = sst / sse
    else:
        qadj = 12 / (nr * k * (k + 1)) * rs2 - 3 * nc * (k + 1)
    
    ncomp = k*(k - 1)/2
    
    res = pd.DataFrame([[0]*7]*int(ncomp))
    useRow=0
    for i in range(0, k-1):
            for j in range(i+1, k):
                res.iloc[useRow,0] = data.columns[i]
                res.iloc[useRow,1] = data.columns[j]
                res.iloc[useRow,2] = nr
                useRow = useRow + 1
    
    useRow=0
    if method=="dunn":                
        se = (k * (k + 1) / (6 * nr))**0.5
        df = nr - k
        for i in range(0, k-1):
            for j in range(i+1, k):
                z = (rmj[i] - rmj[j])/se
                res.iloc[useRow,3] = z
                res.iloc[useRow,4] = None
                res.iloc[useRow,5] = 2 * (1 - NormalDist().cdf(abs(z))) 
                
                useRow = useRow + 1
                
    elif method == "conover":
        r2 = ((rmj * nr)**2).sum()        
        se = (2 * (nr * rs2 - r2) / ((nr - 1) * (k - 1)))**0.5
        df = (nr - 1) * (k - 1)
        for i in range(0, k-1):
            for j in range(i+1, k):
                tVal = (rmj[i] - rmj[j]) * nr / se
                res.iloc[useRow,3] = tVal
                res.iloc[useRow,4] = df
                res.iloc[useRow,5] = 2 * (1 - t.cdf(abs(tVal), df)) 
                
                useRow = useRow + 1
    elif method == "nemenyi":
        se = (k * (k + 1) / (6 * nr))**0.5
        df = nr - k
        for i in range(0, k-1):
            for j in range(i+1, k):
                q = (rmj[i] - rmj[j]) / se * (2**0.5)
                res.iloc[useRow,3] = q
                res.iloc[useRow,4] = df
                res.iloc[useRow,5] = 1 - studentized_range.cdf(abs(q), k=k, df=df, scale=1)
                
                useRow = useRow + 1
                
    useRow=0
    for i in range(0, k-1):
            for j in range(i+1, k):
                res.iloc[useRow,6] = res.iloc[useRow, 5]*ncomp
                if res.iloc[useRow,6] > 1:
                    res.iloc[useRow,6] = 1
                useRow = useRow + 1
                
    res.columns = ["field 1", "field 2", "n", "statistic", "df", "p-value", "adj. p-value"]
    
    return res