import pandas as pd
from scipy.stats import t 

def ph_winer(nomField, scaleField, categories=None):
    if type(nomField) == list:
        nomField = pd.Series(nomField)
        
    if type(scaleField) == list:
        scaleField = pd.Series(scaleField)
        
    data = pd.concat([nomField, scaleField], axis=1)
    data.columns = ["category", "score"]
    
    #remove unused categories
    if categories is not None:
        data = data[data.category.isin(categories)]
    
    #Remove rows with missing values and reset index
    data = data.dropna()    
    data.reset_index()
    
    cats = pd.unique(data["category"])
    
    k = len(cats)
    ncomp = k * (k - 1) / 2
    
    
    #overall n, mean and ss
    n = len(data["category"])
    m = data.score.mean()
    sst = data.score.var()*(n-1)
    
    #sample sizes, and means per category
    nj = data.groupby('category').count()
    sj = data.groupby('category').sum()
    mj = data.groupby('category').mean()
    
    ssb = float((nj*(mj-m)**2).sum())
    ssw = sst - ssb
    
    dfw = n - k
    msw = ssw/dfw
    
    ncomp = k * (k - 1) / 2
    res = pd.DataFrame()
    resRow=0
    for i in range(0, k-1):
        for j in range(i+1, k):
            res.at[resRow, 0] = cats[i]
            res.at[resRow, 1] = cats[j]
            res.at[resRow, 2] = nj.iloc[i, 0]
            res.at[resRow, 3] = nj.iloc[j, 0]
            res.at[resRow, 4] = mj.iloc[i, 0]
            res.at[resRow, 5] = mj.iloc[j, 0]
            res.at[resRow, 6] = res.iloc[resRow, 4] - res.iloc[resRow, 5]
            res.at[resRow, 7] = 0
            
            sej = (msw * (1 / res.iloc[resRow, 2] + 1 / res.iloc[resRow, 3]))**0.5
            tVal = res.iloc[resRow, 6]/sej
            res.at[resRow, 8] = tVal
            
            res.at[resRow, 9] = dfw
            pValue = 2*(1-t.cdf(abs(tVal), dfw))
            res.at[resRow, 10] = pValue
            res.at[resRow, 11] = pValue*ncomp
            if res.iloc[resRow,11] > 1:
                res.iloc[resRow,11] = 1
            
            res.at[resRow, 12] = "Winer pairwise t"
            resRow = resRow + 1
    
    res.columns = ["category 1", "category 2", "n1", "n2", "mean 1", "mean 2", "sample diff.", "hyp diff.", "statistic", "df", "p-value", "adj. p-value", "test"]
    return res