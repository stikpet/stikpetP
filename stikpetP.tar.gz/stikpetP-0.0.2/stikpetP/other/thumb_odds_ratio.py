import pandas as pd

def th_odds_ratio(odrat, qual="chen"):
    '''
    Rules of Thumb for Odds Ratio
    -----------------------------
     
    This function will give a qualification (classification) for a given Odds Ratio
    
    Parameters
    ----------
    odrat : float
        the odds ratio value
    qual : {chen, wuensch, jones}, optional
        rules-of-thumb to use
    
    Returns
    -------
    results : a dataframe with.
    
    * *classification*, the qualification of the effect size
    * *reference*, a reference for the rule of thumb used
    
    Notes
    -----
    For the rules-of-thumb if the odds ratio is less than 1 the inverse is used:
    
    $$OR^{\\ast} = \\begin{cases} OR & \\text{ if } OR\\geq =1 \\\\ \\frac{1}{OR} & \\text{ if } OR< 1  \\end{cases}$$
    
    The following rules-of-thumb can be used:
    
    "chen" => Chen et al. (2010, p. 864)
    
    |\\(OR^{\\ast}\\)| Interpretation|
    |---|----------|
    |1.00 < 1.68 | negligible |
    |1.68 < 3.47 | small |
    |3.47 < 6.71 | medium |
    |6.71 or more | large |
    
    "wuensch" => Wuensch (2009, p. 2)
    
    |\\(OR^{\\ast}\\)| Interpretation|
    |---|----------|
    |1.00 < 1.49 | negligible |
    |1.49 < 3.45 | small |
    |3.45 < 9.00 | medium |
    |9.00 or more | large |
    
    "jones" => Jones (2014)
    
    |\\(OR^{\\ast}\\)| Interpretation|
    |---|----------|
    |1.00 < 1.50 | negligible |
    |1.50 < 2.50 | small |
    |2.50 < 4.30 | medium |
    |4.30 or more | large |
    
    See Also
    --------
    stikpetP.effect_sizes.eff_size_odds_ratio.es_odds_ratio : to determine the odds ratio.
    
    References
    ----------
    Chen, H., Cohen, P., & Chen, S. (2010). How big is a big Odds Ratio? Interpreting the magnitudes of Odds Ratios in epidemiological studies. *Communications in Statistics - Simulation and Computation, 39*(4), 860–864. https://doi.org/10.1080/03610911003650383
    
    Chinn, S. (2000). A simple method for converting an odds ratio to effect size for use in meta-analysis. *Statistics in Medicine, 19*(22), 3127–3131. https://doi.org/10.1002/1097-0258(20001130)19:22<3127::aid-sim784>3.0.co;2-m
    
    Jones, K. (2014, June 5). How do you interpret the odds ratio (OR)? ResearchGate. https://www.researchgate.net/post/How_do_you_interpret_the_odds_ratio_OR
    
    Wuensch, K. (2009). Cohen’s conventions for small, medium, and large effects. https://imaging.mrc-cbu.cam.ac.uk/statswiki/FAQ/effectSize?action=AttachFile&do=get&target=esize.doc
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> th_odds_ratio(5.23)
    
    '''
    if (odrat < 1):
        odrat = 1/odrat
        
    #Chen et al. (2010, p. 862).
    if (qual=="chen"):
        src = "Chen et al. (2010, p. 862)"
        if (abs(odrat) < 1.68): qual = "negligible"
        elif (abs(odrat) < 3.47): qual = "weak"
        elif (abs(odrat) < 6.71): qual = "moderate"
        else: qual = "strong"
            
    #Wuensch (2009, p. 2).
    if (qual=="wuensch"):
        src = "Wuensch (2009, p. 2)"
        if (abs(odrat) < 1.49) : qual = "negligible"
        elif (abs(odrat) < 3.45): qual = "small"
        elif (abs(odrat) < 9): qual = "medium"
        else: qual = "large"
            
    #Jones (2014)
    if (qual=="jones"):
        src = "Jones (2014)"
        if (abs(odrat) < 1.5): qual = "negligible"
        elif (abs(odrat) < 2.5): qual = "small"
        elif (abs(odrat) < 4.3): qual = "medium"
        else: qual = "large"
    
    results = pd.DataFrame([[qual, src]], columns=["classification", "reference"])
    
    return(results)

    
    
    
    