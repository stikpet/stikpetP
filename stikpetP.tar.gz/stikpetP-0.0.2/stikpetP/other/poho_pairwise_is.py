import pandas as pd
from ..tests.test_student_t_is import ts_student_t_is
from ..tests.test_welch_t_is import ts_welch_t_is
from ..tests.test_trimmed_mean_is import ts_trimmed_mean_is
from ..tests.test_z_is import ts_z_is

def ph_pairwise_is(nomField, scaleField, categories=None, isTest = "student", trimProp = 0.1):
    if type(nomField) == list:
        nomField = pd.Series(nomField)
        
    if type(scaleField) == list:
        scaleField = pd.Series(scaleField)
        
    data = pd.concat([nomField, scaleField], axis=1)
    data.columns = ["category", "score"]
    
    #remove unused categories
    if categories is not None:
        data = data[data.category.isin(categories)]
    
    #Remove rows with missing values and reset index
    data = data.dropna()    
    data.reset_index()
    
    cats = pd.unique(data["category"])
    
    k = len(cats)
    ncomp = k * (k - 1) / 2
    
    res = pd.DataFrame()
    resRow=0
    for i in range(0, k-1):
        for j in range(i+1, k):
            res.at[resRow, 0] = cats[i]
            res.at[resRow, 1] = cats[j]
            sel2cat = [cats[i], cats[j]]
            if isTest == "student":
                isRes = ts_student_t_is(nomField, scaleField, sel2cat)
            elif isTest == "welch":
                isRes = ts_welch_t_is(nomField, scaleField, sel2cat)
            elif isTest == "trimmed":
                isRes = ts_trimmed_mean_is(nomField, scaleField, sel2cat, trimProp=trimProp, se="yuen-dixon")
            elif isTest == "yuen":
                isRes = ts_trimmed_mean_is(nomField, scaleField, sel2cat, trimProp=trimProp, se="yuen")
            elif isTest == "z":
                isRes = ts_z_is(nomField, scaleField, sel2cat)
                
            res.at[resRow, 2] = isRes.iloc[0,0]
            res.at[resRow, 3] = isRes.iloc[0,1]
            res.at[resRow, 4] = isRes.iloc[0,2]
            res.at[resRow, 5] = isRes.iloc[0,3]
            res.at[resRow, 6] = isRes.iloc[0,4]
            res.at[resRow, 7] = isRes.iloc[0,5]
            res.at[resRow, 8] = isRes.iloc[0,6]
            if isTest == "z":
                res.at[resRow, 9] = None
                res.at[resRow, 10] = isRes.iloc[0,7]
            else:
                res.at[resRow, 9] = isRes.iloc[0,7]
                res.at[resRow, 10] = isRes.iloc[0,8]
            
            res.at[resRow, 11] = res.iloc[resRow,10] * ncomp
            if res.iloc[resRow,11] > 1:
                res.iloc[resRow,11] = 1
            
            if isTest == "z":
                res.at[resRow, 12] = isRes.iloc[0,8]
            else:
                res.at[resRow, 12] = isRes.iloc[0,9]
                
            resRow = resRow + 1
    
    res.columns = ["category 1", "category 2", "n1", "n2", "mean 1", "mean 2", "sample diff.", "hyp diff.", "statistic", "df", "p-value", "adj. p-value", "test"]
    return res