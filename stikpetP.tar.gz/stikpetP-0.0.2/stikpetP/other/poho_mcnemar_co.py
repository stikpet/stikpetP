import pandas as pd
from scipy.stats import chi2
from scipy.stats import binom
from ..other.table_cross import tab_cross

def ph_mcnemar_co(field1, field2, categories=None, exact=False, cc=False):
    #create the cross table
    ct = tab_cross(field1, field2, categories, categories, totals="include")    
    
    #basic counts
    k = ct.shape[0]-1
    n = ct.iloc[k, k]
    
    res = pd.DataFrame()
    for i in range(0, k):
        a = ct.iloc[i,i]
        b = ct.iloc[i,k] - a
        c = ct.iloc[k, i] - a
        d = n - a - b - c
                
        res.at[i, 0] = ct.index[i]
        res.at[i,1] = n
        
        if exact:
            minCount = min(b,c)
            pVal = 2*binom.cdf(minCount, n, 0.5)
            if cc:
                pVal = pVal - binom.pmf(minCount, n,0.5)
            
            stat = None
            df = None
            
        else:            
            if cc:
                stat = (abs(b - c)-1)**2 / (b+c)
            else:
                stat = (b - c)**2 / (b+c)
            df = 1
            pVal = chi2.sf(stat, df)
            
        res.at[i,2] = stat
        res.at[i,3] = df
        res.at[i,4] = pVal
        res.at[i,5] = res.loc[i,4] * k
        if res.loc[i,5] > 1:
            res.loc[i,5] = 1
            
    res.columns = ["category", "n", "statistic", "df", "p-value", "adj. p-value"]

    return res