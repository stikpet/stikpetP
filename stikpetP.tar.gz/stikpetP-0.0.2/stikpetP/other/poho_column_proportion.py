import pandas as pd
from statistics import NormalDist
#from ..other.table_cross import tab_cross

def ph_column_proportion(field1, field2, categories1=None, categories2=None, seMethod = "spss"):
    #create the cross table
    ct = ps.tab_cross(field1, field2, categories1, categories2, totals="include")
    
    #basic counts
    nrows = ct.shape[0] - 1
    ncols =  ct.shape[1] - 1
    n = ct.iloc[nrows, ncols]
    
    res = pd.DataFrame()
    ipair=0
    for i in range(0, nrows):
        for j in range(0, ncols-1):
            for k in range((j+1),ncols):
                res.loc[ipair, 0] = list(ct.index)[i]
                res.loc[ipair, 1] = list(ct.columns)[j]
                res.loc[ipair, 2] = list(ct.columns)[k]
        
                #column proportions
                res.loc[ipair, 3] = ct.iloc[i, j] / ct.iloc[nrows, j]
                res.loc[ipair, 4] = ct.iloc[i, k] / ct.iloc[nrows, k]

                #residual
                res.loc[ipair, 5] = res.iloc[ipair, 3] - res.iloc[ipair, 4]
                
                #statistic
                if (seMethod == "spss"):
                    phat = (ct.iloc[nrows, j] * res.iloc[ipair, 3] + ct.iloc[nrows, k] * res.iloc[ipair, 4]) / (ct.iloc[nrows, j] + ct.iloc[nrows, k])
                    se = (phat * (1 - phat) * (1 / ct.iloc[nrows, j] + 1 / ct.iloc[nrows, k]))**0.5
                else:
                    se = (1 / ct[nrows, j] * (res.iloc[ipair, 3] * (1 - res.iloc[ipair, 4])) + 1 / ct.iloc[nrows, k] * (res.iloc[ipair, 4] * (1 - res.iloc[ipair, 3])))**0.5
                    
                res.loc[ipair, 6] = res.iloc[ipair, 5] / se
                
                #p-value
                res.loc[ipair, 7] = 2 * (1 - NormalDist().cdf(abs(res.iloc[ipair, 6])))
                
                #adj
                res.loc[ipair, 8] = res.iloc[ipair, 7] * ncols * (ncols - 1) / 2
                if (res.iloc[ipair, 8] > 1):
                    res.iloc[ipair, 8] = 1

                ipair = ipair + 1
      
    colNames = ["field1", "field2-1", "field2-2", "col. prop. 1", "col. prop. 2", "difference", "z-value", "p-value", "adj. p-value"]
    res.columns = colNames

    return (res)