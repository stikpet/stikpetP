import pandas as pd

def tab_cross(field1, field2, order1=None, order2=None, percent=None, totals="exclude", dropEmpty=False):
    '''
    Cross Table / Contingency Table
    -------------------------------
    
    A contingency table can be defined as “tables arising when observations on a number of categorical variables are cross-classified” (Everitt, 2004, p.89).
    
    There are quite a few variations on the name for this type of table. Perhaps the oldest name is actually contingency table, which was the name Pearson (1904, p. 34) gave to them. Another popular name is cross tabulation (Upton & Cook, 2002, p. 79), but also cross classification table (Zekeck, 2014, p. 71) and bivariate frequency table (Porkess, 1988, p. 48) are used. The one I used cross table which can for example be found in Newbold et al. (2013, p. 9) or Sá (2007, p. 52).
    
    Parameters
    ----------
    field1 : pandas series
        data with categories for the rows
    field2 : pandas series
        data with categories for the columns
    order1 : list or dictionary, optional
        order for categories of field1
    order2 : list or dictionary, optional
        order for categories of field2
    percent : {None, "all", "row", "column"}, optional
        which percentages to show. Default is None (will show counts)
    totals : {"exclude", "include"}, optional
        add margin totals. Default is "exclude"
    dropEmpty : boolean, optional
        drop rows and/or columns with only zeros. Default is False
        
    Returns
    -------
    dataframe : the cross table
    
    References
    ----------
    Everitt, B. (2004). *The Cambridge dictionary of statistics* (2nd ed.). Cambridge University Press.
    
    Newbold, P., Carlson, W. L., & Thorne, B. (2013). *Statistics for business and economics* (8th ed). Pearson.
    
    Pearson, K. (1904). *Contributions to the Mathematical Theory of Evolution*. XIII. On the theory of contingency and its relation to association and normal correlation. Dulau and Co.
    
    Porkess, R. (1988). *Dictionary of statistics*. Collins.
    
    Sá, J. P. M. de. (2007). *Applied statistics: Using SPSS, Statistica, MATLAB, and R* (2nd ed.). Springer.
    
    Upton, G., & Cook, I. (2002). *Oxford: Dictionary of statistics*. Oxford University Press.
    
    Zedeck, S. (Ed.). (2014). *APA dictionary of statistics and research methods*. American Psychological Association.
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> file1 = "https://peterstatistics.com/Packages/ExampleData/GSS2012a.csv"
    >>> df1 = pd.read_csv(file1, sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> tab_cross2(df1['mar1'], df1['sex'], percent="column", totals="include")
    sex               FEMALE       MALE      Total
    mar1                                          
    DIVORCED       16.104869  16.265750  16.177228
    MARRIED        48.314607  52.233677  50.077280
    NEVER MARRIED  19.382022  21.534937  20.350335
    SEPARATED       4.681648   3.321879   4.070067
    WIDOWED        11.516854   6.643757   9.325090

    >>> order1 = ["DIVORCED", "WIDOWED", "SEPARATED", "MARRIED", "NEVER MARRIED"]
    >>> order2 = ["MALE", "FEMALE"]
    >>> tab_cross2(df1['mar1'], df1['sex'], order1 = order1, order2=["MALE", "FEMALE"])
    col_0          MALE  FEMALE
    row_0                      
    DIVORCED        142     172
    WIDOWED          58     123
    SEPARATED        29      50
    MARRIED         456     516
    NEVER MARRIED   188     207

    >>> order = ["Not scientific at all", "Not too scientific", "Pretty scientific", "Very scientific"]
    >>> tab_cross2(df1['mar1'], df1['accntsci'], order2=order)
    col_0          Not scientific at all  Not too scientific  Pretty scientific  Very scientific
    mar1                                                                                        
    DIVORCED                          55                  51                 32               14
    MARRIED                          150                 173                 95               40
    NEVER MARRIED                     57                  74                 41               23
    SEPARATED                         14                  12                  6                6
    WIDOWED                           24                  32                 22               15

    '''
    
    if type(field1) is list:
        field1 = pd.Series(field1)
    
    if order1 is not None:
        if type(order1) is dict:
            orderx = {y: x for x, y in order1.items()}
            field1 = field1.replace(orderx)
            
        field1 = pd.Categorical(field1, categories=order1, ordered=True)
        
        
    if type(field2) is list:
        field2 = pd.Series(field2)
    
    if order2 is not None:
        if type(order2) is dict:
            orderx = {y: x for x, y in order2.items()}
            field2 = field2.replace(orderx)
            
        field2 = pd.Categorical(field2, categories=order2, ordered=True)
        
    if totals=="exclude":
        marg = False
    else:
        marg = True
    
    if percent=="all":
        fact = 100
        norm = "all"
    elif percent=="row":
        fact = 100
        norm = "index"
    elif percent=="column":
        fact = 100
        norm = "columns"
    else:
        fact = 1
        norm = False
    
    tab = pd.crosstab(field1, field2, margins=marg, margins_name="Total", normalize=norm, dropna=dropEmpty)*fact
    
    return (tab)