import pandas as pd

def tab_cross(field1, field2, percent=None, totals="exclude"):
    '''
    Cross Table / Contingency Table
    
    A contingency table can be defined as “tables arising when observations on a number of categorical variables are cross-classified” (Everitt, 2004, p.89).
    
    There are quite a few variations on the name for this type of table. Perhaps the oldest name is actually contingency table, which was the name Pearson (1904, p. 34) gave to them. Another popular name is cross tabulation (Upton & Cook, 2002, p. 79), but also cross classification table (Zekeck, 2014, p. 71) and bivariate frequency table (Porkess, 1988, p. 48) are used. The one I used cross table which can for example be found in Newbold et al. (2013, p. 9) or Sá (2007, p. 52).
    
    Parameters
    ----------
    field1 : pandas series
        data with categories for the rows
    field2 : pandas series
        data with categories for the columns
    percent : {None, "all", "row", "column"}, optional
        which percentages to show. Default is None (will show counts)
    totals : {"exclude", "include"}, optional
        add margin totals. Default is "exclude"
        
    Returns
    -------
    dataframe : the cross table
    
    References
    ----------
    Everitt, B. (2004). *The Cambridge dictionary of statistics* (2nd ed.). Cambridge University Press.
    
    Newbold, P., Carlson, W. L., & Thorne, B. (2013). *Statistics for business and economics* (8th ed). Pearson.
    
    Pearson, K. (1904). *Contributions to the Mathematical Theory of Evolution*. XIII. On the theory of contingency and its relation to association and normal correlation. Dulau and Co.
    
    Porkess, R. (1988). *Dictionary of statistics*. Collins.
    
    Sá, J. P. M. de. (2007). *Applied statistics: Using SPSS, Statistica, MATLAB, and R* (2nd ed.). Springer.
    
    Upton, G., & Cook, I. (2002). *Oxford: Dictionary of statistics*. Oxford University Press.
    
    Zedeck, S. (Ed.). (2014). *APA dictionary of statistics and research methods*. American Psychological Association.
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> df1 = pd.read_csv('https://peterstatistics.com/Packages/ExampleData/GSS2012a.csv', sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> tab_crosstable(df1['mar1'], df1['sex'], percent="column", totals="include")
    sex               FEMALE       MALE      Total
    mar1                                          
    DIVORCED       16.104869  16.265750  16.177228
    MARRIED        48.314607  52.233677  50.077280
    NEVER MARRIED  19.382022  21.534937  20.350335
    SEPARATED       4.681648   3.321879   4.070067
    WIDOWED        11.516854   6.643757   9.325090

    '''
    
    if totals=="exclude":
        marg = False
    else:
        marg = True
    
    if percent=="all":
        fact = 100
        norm = "all"
    elif percent=="row":
        fact = 100
        norm = "index"
    elif percent=="column":
        fact = 100
        norm = "columns"
    else:
        fact = 1
        norm = False
    
    tab = pd.crosstab(field1, field2, margins=marg, margins_name="Total", normalize=norm)*fact
    
    return (tab)