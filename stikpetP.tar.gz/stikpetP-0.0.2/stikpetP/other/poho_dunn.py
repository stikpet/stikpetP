import pandas as pd
from statistics import NormalDist
from ..other.table_cross import tab_cross

def ph_dunn(catField, ordField, categories=None, levels=None):
    
    #create the cross table    
    ct = tab_cross(ordField, catField, order1=levels, order2=categories, totals="include")
    
    #basic counts
    k = ct.shape[1]-1
    nlvl = ct.shape[0]-1
    n = ct.iloc[nlvl, k]
    
    #ties
    t = 0
    n = 0
    for i in range(0,nlvl):
        n = n + ct.iloc[i, k]
        tf = ct.iloc[i, k]
        t = t + tf**3 - tf
    
    a = n * (n + 1) / 12 - t / (12 * (n - 1))
    
    #the ranks of the levels
    lvlRank = pd.Series(dtype="object")
    cf = 0
    for i in range(0,nlvl):
        lvlRank.at[i] = (2 * cf + ct.iloc[i, k] + 1) / 2
        cf = cf + ct.iloc[i, k]
    
    #sum of ranks per category
    srj = pd.Series(dtype="object")
    for j in range(0,k):
        sr = 0
        for i in range(0,nlvl):
             sr = sr + ct.iloc[i, j] * lvlRank.iloc[i]
        
        srj.at[j] = sr
    
    ncomp = k * (k - 1) / 2
    res = pd.DataFrame()
    resRow = 0
    for i in range(0, k-1):
        for j in range(i+1, k):
            n1 = ct.iloc[nlvl, i]
            n2 = ct.iloc[nlvl, j]
            m1 = srj.iloc[i] / n1
            m2 = srj.iloc[j] / n2
            d = m1 - m2
            Var = a * (1 / n1 + 1 / n2)
            se = (Var)**0.5
            Z = d / se
            p = 2 * (1 - NormalDist().cdf(abs(Z)))
            
            res.at[resRow, 0] = ct.columns[i]
            res.at[resRow, 1] = ct.columns[j]
            res.at[resRow, 2] = n1
            res.at[resRow, 3] = n2
            res.at[resRow, 4] = m1
            res.at[resRow, 5] = m2
            res.at[resRow, 6] = Z
            res.at[resRow, 7] = p
            res.at[resRow, 8] = p * ncomp
            if res.iloc[resRow, 8] > 1:
                res.at[resRow, 8] = 1            
            
            resRow = resRow + 1
    
    colNames = ["cat. 1", "cat. 2", "n1", "n2", "mean rank 1", "mean rank 2", "statistic", "p-value", "adj. p-value"]
    res.columns = colNames
    return res