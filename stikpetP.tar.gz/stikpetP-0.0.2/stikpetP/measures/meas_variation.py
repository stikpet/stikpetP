import pandas as pd
import numpy as np
from statistics import mode
from .meas_mean import me_mean

def me_variation(data, levels=None, measure="std", ddof=1, center="mean", azs="square"):
    '''
    Measures of Quantitative Variation
    
    Probably the most famous measure of dispersion is the standard deviation, but there are more. This function provides a variety of measures and allows the creation of your own version.
    
    Parameters
    ----------
    data : list or pandas data series 
        numeric data
    levels : dictionary, optional 
        coding to use
    measure : {"std", "var", "mad", "madmed", "medmad", "stddm", "cv", "cd", "own"}, optional
        the measure to determine. Default is "std"
    ddof : float, optional
        option to adjust the division in standard deviation or variance with. Default is 1.
    center : {"mean", "median", "mode"} or float, optional
        if measure is "own" the value to use as center. Default is "mean"
    azs : {"square", "abs"}, optional
        if measure is "own" the way to avoid a zero sum. Either by squaring or absolute value
        
    Returns
    -------
    A dataframe with:
    
    * *value*, the value of the measure
    * *measure*, description of the measure
    
    Notes
    -----
    
    **Standard Deviation** (std)
    
    The formula used is:
    $$s = \\sqrt{\\frac{\\sum_{i=1}^n \\left(x_i - \\bar{x}\\right)^2}{n - d}}$$
    
    Where \\(d\\) is the offset specified at *ddof*. By default this is 1, giving the sample standard deviation.
    
    **Variance** (var)
    
    The formula used is:
    $$s^2 = \\frac{\\sum_{i=1}^n \\left(x_i - \\bar{x}\\right)^2}{n - d}$$
    
    Where \\(d\\) is the offset specified at *ddof*. By default this is 1, giving the sample standard deviation.
    
    **Mean Absolute Deviation** (mad)
    
    The formula used is:
    $$MAD = \\frac{\\sum_{i=1}^n \\left| x_i - \\bar{x}\\right|}{n}$$
    
    **Mean Absolute Deviation from the Median** (madmed)
    
    The formula used is:
    $$MAD = \\frac{\\sum_{i=1}^n \\left| x_i - \\tilde{x}\\right|}{n}$$
    
    Where \\(\\tilde{x}\\) is the median
    
    **Median Absolute Deviation** (medad)
    
    The formula used is:
    $$MAD = MED\\left(\\left| x_i - \\tilde{x}\\right|\\right)$$
    
    **Decile Standard Deviation**
    
    The formula used is (Siraj-Ud-Doulah, 2018, p. 310):
    $$s_{dm} = \\sqrt{\\frac{\\sum_{i=1}^n \\left(x_i - DM\\right)^2}{n - d}}$$
    
    Where DM is the decile mean.
    
    **Coefficient of Variation** (cv)
    
    The formula used is (Pearson, 1896, p. 277):
    $$CV = \\frac{s}{\\bar{x}}$$
    
    **Coefficient of Diversity** (cd)
    
    The formula used is (Siraj-Ud-Doulah, 2018, p. 310):
    $$CD = \\frac{s_{dm}}{DM}$$
    
    **Own**
    
    it's possible to create one's own method. Decide on a specific center. Default options are the mean, median and mode. Then on either to sum the squared deviations or the absolute differences.
    
    References
    ----------
    Pearson, K. (1896). Contributions to the mathematical theory of evolution. III. Regression, Heredity, and Panmixia. *Philosophical Transactions of the Royal Society of London*. (A.), 1896, 253–318.
    
    Siraj-Ud-Doulah, M. (2018). Alternative measures of standard deviation coefficient of variation and standard error. *International Journal of Statistics and Applications, 8*(6), 309–315. https://doi.org/10.5923/j.statistics.20180806.04
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    if type(data) is list:        
        data = pd.Series(data)
        
    data = data.dropna()
    if levels is not None:
        dataN = data.replace(levels)
        dataN = pd.to_numeric(dataN)
    else:
        dataN = pd.to_numeric(data)
    
    dataN = dataN.sort_values().reset_index(drop=True)    
    n = len(dataN)
    
    if measure=="std" and ddof==1:
        lbl = "standard deviation (sample)"
        res = np.std(dataN, ddof=1)
    elif measure=="std" and ddof==0:
        lbl = "standard deviation (population)"
        res = np.std(dataN, ddof=0)
    elif measure=="std":
        lbl = "standard deviation corrected with " + str(ddof)
        res = np.std(dataN, ddof=ddof)
    elif measure=="var" and ddof==1:
        lbl = "variance (sample)"
        res = np.var(dataN, ddof=1)
    elif measure=="var" and ddof==0:
        lbl = "variance (population)"
        res = np.var(dataN, ddof=0)
    elif measure=="var":
        lbl = "variance corrected with " + str(ddof)
        res = np.var(dataN, ddof=ddof)
    elif measure=="mad":
        lbl = "mean absolute deviation"
        mu = np.mean(dataN)
        res = sum(abs(dataN - mu))/n
    elif measure=="madmed":
        lbl = "mean absolute deviation around median"
        mu = np.median(dataN)
        res = sum(abs(dataN - mu))/n
    elif measure=="medmad":
        lbl = "median absolute deviation"
        mu = np.median(dataN)
        res = np.median(abs(dataN - mu))    
    elif measure=="cv":
        lbl = "coefficient of variation"
        mu = np.mean(dataN)
        s = np.std(dataN, ddof=ddof)
        res = s/mu
    elif measure=="stddm":
        lbl = "standard deviation with decile mean"
        mu = me_mean(dataN, version="decile")
        res = (sum((dataN - mu)**2)/(n-ddof))**0.5        
    elif measure=="cd":
        lbl = "coefficient of deviation"
        mu = me_mean(dataN, version="decile")
        s = (sum((dataN - mu)**2)/(n-ddof))**0.5
        res = s/mu
    else:
        if center=="mean":
            lbl = "mean"
            mu = np.mean(dataN)
        elif center=="median":
            lbl = "median"
            mu = np.median(dataN)
        elif center=="mode":
            lbl = "mode"
            mu = mode(dataN)
        else:
            lbl = str(center)
            mu = center
            
        if azs=="square":
            lbl = "sum squared deviation around " + str(lbl)
            res = sum((dataN - mu)**2)
        elif azs=="abs":
            lbl = "sum absolute deviation around " + str(lbl)
            res = sum(abs(dataN - mu))
    
    results = pd.DataFrame(list([[res, lbl]]), columns = ["value", "measure"])
                 
    return (results)