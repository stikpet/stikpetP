import pandas as pd
import matplotlib.pyplot as plt

def vi_histogram_split(catField, scaleField, categories=None, **kwargs):
    if type(catField) is list:
        catField = pd.Series(catField)
    
    if type(scaleField) is list:
        scaleField = pd.Series(scaleField)
    
    #combine as one dataframe
    df = pd.concat([catField, scaleField], axis=1)
    df = df.dropna()
    
    myClusters = df.iloc[:,0]
    myScale = df.iloc[:,1]
    
    if categories != None:
        myCats = categories
    else:
        myCats = myClusters.unique()
    
    myList = []
    for i in myCats:
        myCatScores = myScale[myClusters == i].dropna()
        myList.append(myCatScores)
        
    k = len(myCats)
    
    plt.figure(1, figsize=(8,8))
    plt.subplots_adjust(hspace=0.5)
    
    for i in range(len(myCats)):
        plt.subplot(k,1,i+1)
        plt.hist(myList[i], **kwargs)            
        plt.xlim(min(myScale), max(myScale))
        plt.xlabel(myCats[i])
        plt.ylabel('Frequency')
        
    plt.show()