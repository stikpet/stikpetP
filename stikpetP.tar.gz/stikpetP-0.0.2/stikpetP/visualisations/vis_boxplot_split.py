import pandas as pd
import seaborn as sns

def vi_boxplot_split(catField, scaleField, categories=None, **kwargs):
    if type(catField) is list:
        catField = pd.Series(catField)        
        catName = ""
    else:
        catName = catField.name        
        
    if type(scaleField) is list:
        scaleField = pd.Series(scaleField)
        scaleName = ""        
    else:
        scaleName = scaleField.name
    
    #combine as one dataframe
    df = pd.concat([catField, scaleField], axis=1)
    df = df.dropna()    
    df.columns=["category", "score"]
    if categories is not None:
        df = df[df["category"].isin(categories)]

    myClusters = df.iloc[:,0]
    myScale = df.iloc[:,1]
    sns.boxplot(x="score", y="category", data = df, orient="h", **kwargs).set(xlabel=scaleName, ylabel=catName)
