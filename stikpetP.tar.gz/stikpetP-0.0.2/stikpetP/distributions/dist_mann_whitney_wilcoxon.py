import math
def di_mwwpmf(x, n1, n2):
    # input is a U statistic
    p = he_srf2(x, n1, n2) / math.comb(n1 + n2, n1)
    
    return p
    
def di_mwwcdf(x, n1, n2):
    '''
    Mann-Whitney-Wilcoxon Distribution
    ----------------------------------
    This distribution is also referred to as a permutation distribution.
    
    It is used in the Mann-Whitney U and Wilcoxon Rank Sum test.
    
    In this version the U-statistic is used as input
    
    Parameters
    ----------
    x : int
        the U test statistic
    n1 : int
        the sample size of the first category
    n2 : int
        the sample size of the second category
    
    Returns
    -------
    p : the cumulative probability
    
    Notes
    -----
    To convert a W statistic to a U statistic use:
    $$\\U = W - \\frac{n_1\\times\\left(n_1 + 1\\right)}{2}$$
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    # input is a U statistic
    p = 0
    for i in range(int(x)):
        p = p + di_mwwpmf(i, n1, n2)
    
    return p


def he_srf2(u, n1, n2):
    if (u < 0) or (u > n1 * n2):
        res = 0
    elif n1 == 1:
        res = 1
    else:
        res = he_srf2(u - n2, n1 - 1, nMax) + he_srf2(u, n1, n2 - 1)
        
    return (res)