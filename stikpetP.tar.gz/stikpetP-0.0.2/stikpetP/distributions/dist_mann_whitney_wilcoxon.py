import math
def di_mwwpmf(x, n1, n2):
    # input is a U statistic
    p = he_srf2(x, n1, n2) / math.comb(n1 + n2, n1)
    
    return p
    
def di_mwwcdf(x, n1, n2): 
    # input is a U statistic
    p = 0
    for i in range(int(x)):
        p = p + di_mwwpmf(i, n1, n2)
    
    return p


def he_srf2(u, nMin, nMax):
    if (u < 0) or (u > nMin * nMax):
        res = 0
    elif nMin == 1:
        res = 1
    else:
        res = he_srf2(u - nMax, nMin - 1, nMax) + he_srf2(u, nMin, nMax - 1)
        
    return (res)