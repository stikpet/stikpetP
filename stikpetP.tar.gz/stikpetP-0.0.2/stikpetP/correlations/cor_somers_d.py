import pandas as pd
from statistics import NormalDist
from ..other.table_cross import tab_cross

def r_somers_d(ordField1, ordField2, levels1=None, levels2=None, useRanks=False):
    
    ct = tab_cross(ordField1, ordField2, order1=levels1, order2=levels2)
    k1 = ct.shape[0]
    k2 = ct.shape[1]
    
    if useRanks==False:
        if levels1 is not None:
            #replace row labels with numeric score
            ct = ct.reset_index(drop=True)
            
        if levels2 is not None:            
            ct.columns = [i for i in range(0, k2)]
    
    n = 0
    conc = [[0]*k1]*k2
    disc = [[0]*k1]*k2
    conc = pd.DataFrame(conc)
    disc = pd.DataFrame(disc)
    
    for i in range(0, k1):
        for j in range(0, k2):
            for h in range(0, k1):
                for k in range(0, k2):
                    
                    if useRanks:
                        if h > i and k > j:
                            conc.iloc[i,j] = conc.iloc[i,j] + ct.iloc[h,k]
                        elif h<i and k<j:
                            conc.iloc[i,j] = conc.iloc[i,j] + ct.iloc[h,k]
                        elif h>i and k<j:
                            disc.iloc[i,j] = disc.iloc[i,j] + ct.iloc[h,k]
                        elif h<i and k>j:
                            disc.iloc[i,j] = disc.iloc[i,j] + ct.iloc[h,k]                        
                    else:
                        if ct.index[h] > ct.index[i] and ct.columns[k] > ct.columns[j]:
                            conc.iloc[i,j] = conc.iloc[i,j] + ct.iloc[h,k]
                        elif ct.index[h] < ct.index[i] and ct.columns[k] < ct.columns[j]:
                            conc.iloc[i,j] = conc.iloc[i,j] + ct.iloc[h,k]
                        elif ct.index[h] > ct.index[i] and ct.columns[k] < ct.columns[j]:
                            disc.iloc[i,j] = disc.iloc[i,j] + ct.iloc[h,k]
                        elif ct.index[h] < ct.index[i] and ct.columns[k] > ct.columns[j]:
                            disc.iloc[i,j] = disc.iloc[i,j] + ct.iloc[h,k]
            n = n + ct.iloc[i,j]
    
    ct = ct.reset_index(drop=True)
    ct.columns = [i for i in range(0, k2)]
    
    p = (ct*conc).sum().sum()
    q = (ct*disc).sum().sum()
    
    rs = ct.sum(axis=1)
    cs = ct.sum()
    
    dr = n**2 - (rs**2).sum()
    dc = n**2 - (cs**2).sum()
    
    dyx = (p - q)/dr
    dxy = (p - q)/dc
    d = 2 * (p - q) / (dr + dc)
    ds = [d, dxy, dyx]
    
    S = (ct*(conc-disc)**2).sum().sum()
    S = (S - (p - q)**2 / n)**0.5
    
    ase0 = 4 / (dr + dc) * S
    ase0yx = 2 / dr * S
    ase0xy = 2 / dc * S
        
    Z = d / ase0
    Zyx = dyx / ase0yx
    Zxy = dxy / ase0xy
            
    pVal = 2 * (1 - NormalDist().cdf(abs(Z)))
    pValyx = 2 * (1 - NormalDist().cdf(abs(Zyx)))
    pValxy = 2 * (1 - NormalDist().cdf(abs(Zxy)))
    
    r1 = ["symmetric", d, Z, pVal]
    r2 = ["field 1", dxy, Zxy, pValxy]
    r3 = ["field 2", dyx, Zyx, pValyx]
    res = pd.DataFrame([r1, r2, r3])
    res.columns = ["dependent", "Somers d", "statistic", "p-value"]
    
    return res