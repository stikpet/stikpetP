import pandas as pd
from statistics import NormalDist
from ..other.table_cross import tab_cross
from ..distributions.dist_kendall_tau import di_kendall_tau

def r_kendall_tau(ordField1, ordField2, levels1=None, levels2=None, version="b", test="kendall-appr", cc=False, useRanks=False):
    
    ct = tab_cross(ordField1, ordField2, order1=levels1, order2=levels2)
    k1 = ct.shape[0]
    k2 = ct.shape[1]
    
    if useRanks==False:
        if levels1 is not None:
            #replace row labels with numeric score
            ct = ct.reset_index(drop=True)
            
        if levels2 is not None:            
            ct.columns = [i for i in range(0, k2)]
    
    n = 0
    conc = [[0]*k1]*k2
    disc = [[0]*k1]*k2
    conc = pd.DataFrame(conc)
    disc = pd.DataFrame(disc)
    
    for i in range(0, k1):
        for j in range(0, k2):
            for h in range(0, k1):
                for k in range(0, k2):
                    
                    if useRanks:
                        if h > i and k > j:
                            conc.iloc[i,j] = conc.iloc[i,j] + ct.iloc[h,k]
                        elif h<i and k<j:
                            conc.iloc[i,j] = conc.iloc[i,j] + ct.iloc[h,k]
                        elif h>i and k<j:
                            disc.iloc[i,j] = disc.iloc[i,j] + ct.iloc[h,k]
                        elif h<i and k>j:
                            disc.iloc[i,j] = disc.iloc[i,j] + ct.iloc[h,k]                        
                    else:
                        if ct.index[h] > ct.index[i] and ct.columns[k] > ct.columns[j]:
                            conc.iloc[i,j] = conc.iloc[i,j] + ct.iloc[h,k]
                        elif ct.index[h] < ct.index[i] and ct.columns[k] < ct.columns[j]:
                            conc.iloc[i,j] = conc.iloc[i,j] + ct.iloc[h,k]
                        elif ct.index[h] > ct.index[i] and ct.columns[k] < ct.columns[j]:
                            disc.iloc[i,j] = disc.iloc[i,j] + ct.iloc[h,k]
                        elif ct.index[h] < ct.index[i] and ct.columns[k] > ct.columns[j]:
                            disc.iloc[i,j] = disc.iloc[i,j] + ct.iloc[h,k]
            n = n + ct.iloc[i,j]
    
    ct = ct.reset_index(drop=True)
    ct.columns = [i for i in range(0, k2)]
    
    p = (ct*conc).sum().sum()
    q = (ct*disc).sum().sum()
    
    if version=="a":
        #Kendall Tau a
        tauUsed = "Kendall Tau-a"
        tau = (p - q) / (n * (n - 1))
    
        varA = (4 * n + 10) / (9 * n * (n - 1))
        seA = (varA / n)**0.5
        z = tau / seA
        pVal = 2 * (1 - NormalDist().cdf(abs(z))) 
        testUsed = "Kendall approximation"
        
    elif version=="b":
        #Kendall Tau b
        tauUsed = "Kendall Tau-b"
        n0 = n * (n - 1) / 2
        
        rs = ct.sum(axis=1)
        n1 = (rs*(rs-1)).sum()/2
        
        cs = ct.sum()
        n2 = (cs*(cs-1)).sum()/2
        
        nc = p / 2
        nd = q / 2
        
        tau = (nc - nd) / ((n0 - n1) * (n0 - n2))**0.5
        
        if test=="bb":
            #Brown and Benedetti (1977, p. 311) = version from SPSS
            ase0 = (ct*(conc-disc)**2).sum().sum()           
            dr = n**2 - (rs**2).sum()
            dc = n**2 - (cs**2).sum()            
            ase0 = 2 * ((ase0 - (p - q)**2 / n) / (dr * dc))**0.5
            if cc:
                tauTest = abs(tau) - 2 / (n * (n - 1))
            else:
                tauTest = tau
                        
            z = tauTest / ase0
            
            pVal = 2 * (1 - NormalDist().cdf(abs(z)))
            testUsed = "Brown and Benedetti approximation"
            
        elif test=="kendall-appr":
            #Kendall (1962, p. 55)
            v2P1 = (rs*(rs - 1)*(rs - 2)).sum()
            v1P1 = (rs*(rs - 1)).sum()
            vr = (rs*(rs - 1)*(2*rs + 5)).sum()
            
            v2P2 = (cs*(cs - 1)*(cs - 2)).sum()
            v1P2 = (cs*(cs - 1)).sum()
            vc = (cs*(cs - 1)*(2*cs + 5)).sum()
            
            v0 = n * (n - 1) * (2 * n + 5)
            v1 = v1P1 * v1P2 / (2 * n * (n - 1))
            v2 = v2P1 * v2P2 / (9 * n * (n - 1) * (n - 2))
            v = (v0 - vr - vc) / 18 + v1 + v2
            
            if cc:
                z = (abs(nc - nd) - 1) / (v)**0.5
            else:
                z = (nc - nd) / (v)**0.5            
            
            pVal = 2 * (1 - NormalDist().cdf(abs(z)))
            if tau < 0:
                z = -abs(z)
                        
            testUsed = "Kendall approximation"
            
        elif test== "as71":
            pVal = di_kendall_tau(n, tau, "as71", cc)
            z = None
            testUsed = "exact with AS71 algorithm"
            
        elif test== "kendall-exact":
            pVal = di_kendall_tau(n, tau, "kendall", cc)
            z = None
            testUsed = "Kendall exact"
        
    res = pd.DataFrame([[tau, z, pVal, testUsed]])
    res.columns = [tauUsed, "statistic", "p-value", "test"]
    
    return res