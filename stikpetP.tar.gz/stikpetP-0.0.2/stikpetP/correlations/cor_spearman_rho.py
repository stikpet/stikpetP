import pandas as pd
from statistics import NormalDist
from ..other.table_cross import tab_cross
from ..distributions.dist_spearman import di_scdf

def r_spearman_rho(ordField1, ordField2, levels1=None, levels2=None, test="t"):
    
    ct = tab_cross(ordField1, ordField2, order1=levels1, order2=levels2)
    k1 = ct.shape[0]
    k2 = ct.shape[1]
    
    if levels1 is not None:
        #replace row labels with numeric score
        ct = ct.reset_index(drop=True)

    if levels2 is not None:            
        ct.columns = [i for i in range(0, k2)]
    
    rs = ct.sum(axis=1)
    cs = ct.sum()
    
    
    sr1 = (rs*ct.index).sum()
    sr2 = (cs*ct.columns).sum()
    
    n1 = rs.sum()
    n2 = cs.sum()
    mr1 = sr1 / n1
    mr2 = sr2 / n2
    
    ss1 = (rs * (ct.index - mr1)**2).sum()
    ss2 = (cs * (ct.columns - mr2)**2).sum()
    
    cov = 0
    for i in range(0, k1):
        for j in range(0, k2):
            cov = cov + ct.iloc[i,j]*(ct.index[i] - mr1) * (ct.columns[j] - mr2)
        
    r = cov / (ss1 * ss2)**0.5
    
    if test == "none":
        res = r
    else:
        diRes = di_scdf(ordField1, ordField2, levels1, levels2, test)
        
        if test in ["as89", "exact", "iman-conover"]:
            pCdf = diRes
        else:
            pCdf = diRes.iloc[0, 0]        
        
        if r > 0:
            p = 2 * (1 - pCdf)
        else:
            p = 2 * pCdf
        
        if test in ["as89", "exact", "iman-conover"]:
            res = pd.DataFrame([[r, p]])
            res.columns = ["Spearman rho", "p-value"]
        
        elif test == "t":
            res = pd.DataFrame([[r, p, diRes.iloc[0,1], diRes.iloc[0,2]]])
            res.columns = ["Spearman rho", "p-value", "statistic", "df"]
            
        elif test == "z-fieller" or test == "z-olds":
            res = pd.DataFrame([[r, p, diRes.iloc[0,1]]])
            res.columns = ["Spearman rho", "p-value", "statistic"]
            
    return res