import pandas as pd
from math import atanh
from statistics import NormalDist
from scipy.stats import t 

def r_pearson(field1, field2, corr=None, test = "t"):
    if type(field1) == list:
        field1 = pd.Series(field1)
        
    if type(field2) == list:
        field2 = pd.Series(field2)
    
    r = field1.corr(field2)
    
    data = pd.concat([field1, field2], axis=1)
    data.columns = ["field1", "field2"]
    #Remove rows with missing values and reset index
    data = data.dropna()    
    data.reset_index()
    
    #overall n, mean and ss
    n = len(data["field1"])
    
    #Corrections
    if corr == "fisher":
        r = r * (1 + (1 - r**2) / (2 * n))
        
    elif corr == "olkin-pratt-2":
        r = r * (1 + (1 - r**2) / (2 * (n - 3)))
    
    if test == "t":
        
        tVal = r * ((n - 2) / (1 - r**2))**0.5
        df = n - 2
        pvalue = 2*(1 - t.cdf(abs(tVal), df))
        statistic = tVal
        
    elif test == "z":
        z = abs(atanh(r)) * (n - 3)**0.5
        pvalue = 2 * (1 - NormalDist().cdf(abs(z)))
        df = None
        statistic = z
        
    res = pd.DataFrame([[r, statistic, df, pvalue]])
    res.columns = ["r", "statistic", "df", "p-value"]
    
    return res