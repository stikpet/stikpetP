import pandas as pd
from statistics import NormalDist
from math import log
from ..other.table_cross import tab_cross

def es_theil_u(field1, field2, categories1=None, categories2=None):
    #create the cross table
    ct = tab_cross(field1, field2, categories1, categories2, totals="include")    
    
    #basic counts
    nrows = ct.shape[0]-1
    ncols =  ct.shape[1]-1
    n = ct.iloc[nrows, ncols]
    
    #the margin totals
    rs = ct.iloc[0:nrows, ncols]
    cs = ct.iloc[nrows, 0:ncols]
    
    #h and hx
    h = 0
    hx = 0
    for i in range(0, nrows):
        hx = hx + rs[i] / n * log(rs[i] / n)
        
        for j in range(0, ncols):
            h = h + ct.iloc[i, j] / n * log(ct.iloc[i, j] / n)
    #hy
    hy=0
    for j in range(0, ncols):
        hy = hy + cs[j] / n * log(cs[j] / n)
        
    h = -h
    hx = -hx
    hy = -hy
    
    #U values
    uyx = (hx + hy - h) / hy
    uxy = (hy + hx - h) / hx
    u = 2 * ((hy + hx - h) / (hx + hy))
    
    #ase1 and q for ase0
    ase1 = 0
    ase1xy = 0
    ase1yx = 0
    q = 0
    for i in range(0, nrows):
        for j in range(0, ncols):
            ase1yx = ase1yx + ct.iloc[i, j] * (hy * log(ct.iloc[i, j] / rs[i]) + (hx - h) * log(cs[j] / n))**2
            ase1xy = ase1xy + ct.iloc[i, j] * (hx * log(ct.iloc[i, j] / cs[j]) + (hy - h) * log(rs[i] / n))**2
            ase1 = ase1 + ct.iloc[i, j] * (h * log(rs[i] * cs[j] / n**2) - (hx + hy) * log(ct.iloc[i, j] / n))**2
            q = q + ct.iloc[i, j] * (log(rs[i] * cs[j] / (n * ct.iloc[i, j])))**2
    ase1yx = (ase1yx)**0.5 / (n * hy**2)
    ase1xy = (ase1xy)**0.5 / (n * hx**2)
    ase1 = 2 * (ase1)**0.5 / (n * (hx + hy)**2)
    
    
    #ase0
    ase0yx = (q - n * (hx + hy - h)**2)**0.5 / (n * hy)
    ase0xy = (q - n * (hx + hy - h)**2)**0.5 / (n * hx)
    ase0 = 2 * (q - n * (hx + hy - h)**2)**0.5 / (n * (hx + hy))
    
    #t
    tyx = uyx / ase0yx
    txy = uxy / ase0xy
    t = u / ase0
    
    #p-values
    p = 2 * (1 - NormalDist().cdf(abs(t))) 
    pyx = 2 * (1 - NormalDist().cdf(abs(tyx)))
    pxy = 2 * (1 - NormalDist().cdf(abs(txy)))
    
    #the results
    ver = ["symmetric", "field1", "field2"]
    us = [u, uxy, uyx]
    ns = [n, n, n]
    
    ase0s = [ase0, ase0xy, ase0yx]
    ase1s = [ase1, ase1xy, ase1yx]
    zs = [t, txy, tyx]
    pvalues = [p, pxy, pyx]
    
    colNames = ["dependent", "n", "value", "ASE_0", "ASE_1", "statistic", "p-value"]
    results = pd.DataFrame(list(zip(ver, ns, us, ase0s, ase1s, zs, pvalues)), columns=colNames)
    
    return results