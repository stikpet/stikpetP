import pandas as pd
from statistics import NormalDist
from ..other.table_cross import tab_cross

def es_cohen_kappa(field1, field2, categories=None):
    
    #create the cross table
    ct = tab_cross(field1, field2, categories, categories, totals="include")    
    
    #basic counts
    k = ct.shape[0]-1
    n = ct.iloc[k, k]
    
    #STEP 1: Convert to percentages based on grand total
    p = pd.DataFrame()
    for i in range(0, k + 1):
        for j in range(0, k + 1):
            p.at[i, j] = ct.iloc[i, j] / n
    
    #STEP 2: P and Q
    Pcap = 0
    QC = 0
    for i in range(0, k):
        Pcap = Pcap + ct.iloc[i, i]
        QC = QC + ct.iloc[i, k] * ct.iloc[k, i]
    p0 = Pcap / n
    pc = QC / (n**2)
    
    #Cohen kappa
    kappa = (p0 - pc) / (1 - pc)
    
    
    #TEST
    ss0P1 = 0
    ss0P2 = 0
    for i in range(0, k):
        ss0P1 = ss0P1 + p.iloc[i, k] * p.iloc[k, i] * (1 - (p.iloc[k, i] + p.iloc[i, k]))**2
        
        for j in range(0, k):
            if i != j:
                ss0P2 = ss0P2 + p.iloc[i, k] * p.iloc[k, j] * (p.iloc[k, i] + p.iloc[j, k])**2
    
    ss0 = ss0P1 + ss0P2 - pc**2
    ase0 = (ss0 / (n * (1 - pc)**2))**0.5
    
    z = kappa / ase0
    pValue = 2 * (1 - NormalDist().cdf(abs(z))) 
    
    #the results
    colnames = ["Kappa", "n", "statistic", "p-value"]
    results = pd.DataFrame([[kappa, n, z, pValue]], columns=colnames)
    
    return (results)