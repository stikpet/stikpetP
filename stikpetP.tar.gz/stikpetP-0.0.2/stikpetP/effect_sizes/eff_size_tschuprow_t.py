def es_tschuprow_t(chi2, n, r, c, cc=None):
    if cc=="bergsma":
        phi2 = chi2/n
        rHat = r - (r - 1)**2/(n - 1)
        cHat = c - (c - 1)**2/(n - 1)
        df = (r - 1)*(c - 1)
        phi2 = max(0, phi2 - df/(n - 1))
        es = (phi2/((rHat - 1)*(cHat - 1))**0.5)**0.5
        
    else:
        es = (chi2/(n*((r - 1)*(c - 1))**0.5))  **0.5
        
    return es