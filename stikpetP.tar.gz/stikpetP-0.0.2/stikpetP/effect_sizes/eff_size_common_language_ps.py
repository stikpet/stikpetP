import pandas as pd
from math import asin
from math import pi
from statistics import NormalDist
from ..tests.test_z_ps import ts_z_ps
from ..correlations.cor_pearson import r_pearson

def es_common_language_ps(field1, field2, dmu=0, method = "dunlap"):
    if method == "mcgraw-wong":
    
        tres = ts_z_ps(field1, field2, dmu=dmu)
        n = tres.iloc[0, 0]
        z = abs(tres.iloc[0, 1] / (n**0.5))
        
        cl = NormalDist().cdf(z)
    
    else:
        rres = r_pearson(field1, field2)
        r = rres.iloc[0,0]
        cl = asin(r) / pi + 0.5
    
    return cl