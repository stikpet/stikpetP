import pandas as pd
from math import asin
from math import pi
from statistics import NormalDist
from ..tests.test_z_ps import ts_z_ps
from ..correlations.cor_pearson import r_pearson

def es_common_language_ps(field1, field2, dmu=0, method = "dunlap"):
    '''
    Common Language Effect Size (Paired-Samples)
    --------------------------------------------
    the probability that a randomly selected score from the one population will be greater than a randomly sampled score from the other population.
    
    Parameters
    ----------
    field1 : pandas series
        the ordinal or scale scores of the first variable
    field2 : pandas series
        the ordinal or scale scores of the second variable
    levels : list or dictionary, optional
        the categories to use
    dmu : float, optional 
        hypothesized difference. Default is zero
    method : {"dunlap", "mcgraw-wong"}, optional
        method to determine CL. Default is "dunlap".
        
    Returns
    -------
    cl : float
        the common language effect size measure value
    
    Notes
    -----
    The formula used from Dunlap (1994, p. 509):
    $$CL = \\sin^{-1}\\left(r_p\\right) + \\frac{1}{2}$$
    
    The function uses r_pearson() to determine \\(r_p\\), the Pearson correlation coefficient.
    
    The formula used from McGraw and Wong (1992, p. 361):
    $$CL = \\Phi\\left(z\\right)$$
    
    With:
    $$z = \\frac{\\left|\\bar{x}_1-\\bar{x}_2\\right| - d_{H0}}{SE}$$
    $$SE = \\sqrt{\\frac{\\sigma_d^2}{n}}\\approx\\sqrt{\\frac{s_d^2}{n}}$$
    $$s_d^2 = \\frac{\\sum_{i=1}^n \\left(d_i -\\bar{d}\\right)^2}{n-1}$$
    $$d_i = x_{i,1} - x_{i,2}$$
    $$\\bar{d}=\\frac{\\sum_{i=1}^n d_i}{n}$$
    
    The function uses the ts_z_ps() function to determine these.
    
    *Symbols used*
    
    * \\(r_p\\), the Pearson correlation coefficient (see r_pearson() for details)
    * \\(x_{i,1}\\), is the i-th score from the first variable
    * \\(x_{i,2}\\), is the i-th score from the second variable
    * \\(d_{H0}\\), difference according to null hypothesis (dmu parameter)
    * \\(\\Phi\\left(\\dots\\right)\\), cumulative density function of the standard normal 
    
    References
    ----------
    Dunlap, W. P. (1994). Generalizing the common language effect size indicator to bivariate normal correlations. *Psychological Bulletin, 116*(3), 509–511. doi:10.1037/0033-2909.116.3.509
    
    McGraw, K. O., & Wong, S. P. (1992). A common language effect size statistic. *Psychological Bulletin, 111*(2), 361–365. doi:10.1037/0033-2909.111.2.361

    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    if method == "mcgraw-wong":
    
        tres = ts_z_ps(field1, field2, dmu=dmu)
        n = tres.iloc[0, 0]
        z = abs(tres.iloc[0, 1] / (n**0.5))
        
        cl = NormalDist().cdf(z)
    
    else:
        rres = r_pearson(field1, field2)
        r = rres.iloc[0,0]
        cl = asin(r) / pi + 0.5
    
    return cl