import pandas as pd
from ..correlations.cor_pearson import r_pearson

def es_cohen_d_ps(field1, field2, within=True):
    '''
    Cohen d<sub>z</sub>
    -------------------
    An effect size measure for paired samples. 
    
    Parameters
    ----------
    field1 : pandas series
        the ordinal or scale scores of the first variable
    field2 : pandas series
        the ordinal or scale scores of the second variable
    levels : list or dictionary, optional
        the categories to use
    within : boolean, optional 
        Use within correlation correction. Default is True
    
    
    Returns
    -------
    dz : float
        the Cohen dz value
    
    Notes
    -----
    The formula used (Cohen, 1988, p. 48):
    $$d_z = \\frac{\\bar{d}}{s_d}$$
    
    With:
    $$s_d = \\sqrt{\\frac{\\sum_{i=1}^n \\left(d_i - \\bar{d}\\right)^2}{n-1}}$$
    $$d_i = x_{i,1}-x_{i,2}$$
    $$\\bar{d} = \\frac{\\sum_{i=1}^n d_i}{n}$$
    
    Using a within correlation correction, the formula changes to (Borenstein et al., 2009, p. 29):
    $$d_z = \\frac{\\bar{d}}{s_w}$$
    
    With:
    $$s_w = \\frac{s_d}{\\sqrt{2\\times\\left(1-r_p\\right)}}$$
    
    *Symbols used*
    
    * \\(r_p\\), the Pearson correlation coefficient. See r_pearson() for details.
    * \\(x_{i,1}\\), is the i-th score from the first variable
    * \\(x_{i,2}\\), is the i-th score from the second variable
    
    References
    ----------
    Borenstein, M., Hedges, L. V., Higgins, J. P. T., & Rothstein, H. R. (2009). Effect sizes based on means. In *Introduction to Meta-Analysis* (pp. 21–32). John Wiley & Sons, Ltd. doi:10.1002/9780470743386
    
    Cohen, J. (1988). *Statistical power analysis for the behavioral sciences* (2nd ed.). L. Erlbaum Associates.
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    
    if type(field1) == list:
        field1 = pd.Series(field1)
        
    if type(field2) == list:
        field2 = pd.Series(field2)
    
    data = pd.concat([field1, field2], axis=1)
    data.columns = ["field1", "field2"]
    #Remove rows with missing values and reset index
    data = data.dropna()    
    data.reset_index()
    
    #overall n
    n = len(data["field1"])
    
    data["diffs"] = data["field1"] - data["field2"]
    dsigma = data["diffs"].std()
    dm = data["diffs"].mean()
    dz = dm/dsigma
    
    if within:
        rres = r_pearson(field1, field2)
        r = rres.iloc[0,0]
        sw = dsigma / (2 * (1 - r))**0.5
        dz = dm / sw
    
    return dz