import pandas as pd
from ..correlations.cor_pearson import r_pearson

def es_cohen_d_ps(field1, field2, within=True):
    if type(field1) == list:
        field1 = pd.Series(field1)
        
    if type(field2) == list:
        field2 = pd.Series(field2)
    
    data = pd.concat([field1, field2], axis=1)
    data.columns = ["field1", "field2"]
    #Remove rows with missing values and reset index
    data = data.dropna()    
    data.reset_index()
    
    #overall n
    n = len(data["field1"])
    
    data["diffs"] = data["field1"] - data["field2"]
    dsigma = data["diffs"].std()
    dm = data["diffs"].mean()
    dz = dm/dsigma
    
    if within:
        rres = r_pearson(field1, field2)
        r = rres.iloc[0,0]
        sw = dsigma / (2 * (1 - r))**0.5
        dz = dm / sw
    
    return dz