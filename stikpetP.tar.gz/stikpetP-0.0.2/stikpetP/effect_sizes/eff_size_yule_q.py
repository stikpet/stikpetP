import pandas as pd
from ..other.table_cross import tab_cross

def es_yule_q(field1, field2, categories1=None, categories2=None):
    '''
    Yule Q / Cole C4 / Pearson Q2
    -----------------------------
    
    Yule Q as well as Yule Y measure how much bigger the diagonal top-left to bottom-right is, than top-right to bottom-left. If the two variables are paired it can be seen as the difference between the pairs that are in agreement with the ones that are in disagreement over the total number of pairs.
    
    It ranges from -1 to 1.
    
    Parameters
    ----------
    field1 : pandas series
        data with categories for the rows
    field2 : pandas series
        data with categories for the columns
    categories1 : list or dictionary, optional
        the two categories to use from field1. If not set the first two found will be used
    categories2 : list or dictionary, optional
        the two categories to use from field2. If not set the first two found will be used

    Returns
    -------
    Yule Q
        
    Notes
    -----    
    Yule's Q (1900) is also Cole's C4 (1949, p. 415) and Pearson's Q2 (1900, p. 15).
    
    The formula used (Yule, 1900, p. 272):
    $$Q = \\frac{a\\times d - b\\times c}{a\\times d + b\\times c}$$
    
    *Symbols used:*
    
    * \\(a\\) the count in the top-left cell of the cross table
    * \\(b\\) the count in the top-right cell of the cross table 
    * \\(c\\) the count in the bottom-left cell of the cross table 
    * \\(d\\) the count in the bottom-right cell of the cross table
    
    See Also
    --------
    stikpetP.other.thumb_yule_q.th_yule_q : rules of thumb for Yule Q
    
    stikpetP.other.convert_es.es_convert : to convert Yule Q to an Odds Ratio or Yule Y.

    References
    ----------
    Cole, L. C. (1949). The measurement of interspecific associaton. *Ecology, 30*(4), 411–424. https://doi.org/10.2307/1932444
    
    Pearson, K. (1900). Mathematical contributions to the theory of evolution. VII. On the correlation of characters not quantitatively measurable. *Philosophical Transactions of the Royal Society of London*, 195, 1–405. https://doi.org/10.1098/rsta.1900.0022
    
    Yule, G. U. (1900). On the association of attributes in statistics: With illustrations from the material of the childhood society, &c. *Philosophical Transactions of the Royal Society of London*, 194, 257–319. https://doi.org/10.1098/rsta.1900.0019
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> pd.set_option('display.width',1000)
    >>> pd.set_option('display.max_columns', 1000)
    >>> file1 = "https://peterstatistics.com/Packages/ExampleData/GSS2012a.csv"
    >>> df1 = pd.read_csv(file1, sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> es_yule_q(df1['mar1'], df1['sex'], categories1=["WIDOWED", "DIVORCED"])
    0.2729392901392027
    
        
    '''
    # determine sample cross table
    tab = tab_cross(field1, field2, order1=categories1, order2=categories2, percent=None, totals="exclude")
    
    # cell values of sample cross table
    a = tab.iloc[0,0]
    b = tab.iloc[0,1]
    c = tab.iloc[1,0]
    d = tab.iloc[1,1]
    
    q = (a*d - b*c)/(a*d + b*c)
    
    
    return (q)