def es_cont_coeff(chi2, n, adj=None, r=None, c=None):
    es = (chi2/(n + chi2))**0.5
    
    if adj=="sakoda":
        m = r
        if (c < r):
            m = c        
        cmax = ((m - 1)/m)**0.5
        es = es/cmax
    
    return es