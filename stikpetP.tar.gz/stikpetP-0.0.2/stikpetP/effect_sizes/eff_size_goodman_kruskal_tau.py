import pandas as pd
from scipy.stats import chi2
from ..other.table_cross import tab_cross

def es_goodman_kruskal_tau(field1, field2, categories1=None, categories2=None):
    #create the cross table
    ct = tab_cross(field1, field2, categories1, categories2, totals="include")
    
    #basic counts
    nrows = ct.shape[0]-1
    ncols =  ct.shape[1]-1
    n = ct.iloc[nrows, ncols]
    
    #the margin totals
    rs = ct.iloc[0:nrows, ncols]
    cs = ct.iloc[nrows, 0:ncols]
    
    #tau
    tauyx = 0
    tauxy = 0
    for i in range(0, nrows):
        for j in range(0, ncols):
            tauyx = tauyx + ct.iloc[i, j]**2 / rs[i]
            tauxy = tauxy + ct.iloc[i, j]**2 / cs[j]
    scs2 = 0
    for j in range(0, ncols):
        scs2 = scs2 + cs[j]**2
    tauyx = (n * tauyx - scs2) / (n**2 - scs2)
    
    srs2 = 0
    for i in range(0, nrows):
        srs2 = srs2 + rs[i]**2
    tauxy = (n * tauxy - srs2) / (n**2 - srs2)
    
    chi2yx = (n - 1) * (ncols - 1) * tauyx
    chi2xy = (n - 1) * (nrows - 1) * tauxy
    df = (nrows - 1) * (ncols - 1)
    pyx = chi2.sf(chi2yx, df)
    pxy = chi2.sf(chi2xy, df)
    
    #the results
    ver = ["field1", "field2"]
    tau = [tauxy, tauyx]
    statistic = [chi2xy, chi2yx]
    dfs = [df, df]
    pvals = [pxy, pyx]
    
    colNames = ["dependent", "value", "statistic", "df", "p-value"]
    results = pd.DataFrame(list(zip(ver, tau, statistic, dfs, pvals)), columns=colNames)
    
    return results