import pandas as pd
from ..other.table_cross import tab_cross

def es_cole_c7(field1, field2, categories1=None, categories2=None):
    '''
    Cole C7 / Coefficient of Interspecific Association
    --------------------------------------------------
    A measure of association between two binary variables.
    
    It is Cole's adjustment to the McEwen and Michael coefficient to compensate for some extreme cases by dividing the absolute difference of deviation from no association by the number of possible tables with a positive association.
    
    Parameters
    ----------
    field1 : pandas series
        data with categories for the rows
    field2 : pandas series
        data with categories for the columns
    categories1 : list or dictionary, optional
        the two categories to use from field1. If not set the first two found will be used
    categories2 : list or dictionary, optional
        the two categories to use from field2. If not set the first two found will be used

    Returns
    -------
    Cole C7
        
    Notes
    -----    
    The formula used is (Cole, 1949, pp. 420-421).
    $$C_7 = \\begin{cases} \\frac{a\\times d - b\\times c}{R_1\\times C_2} & \\text{ if } a\\times d\\geq b\\times c \\\\ \\frac{a\\times d - b\\times c}{R_1 \\times C_1} & \\text{ if } a\\times d < b\\times c \\text{ and } a\\leq d  \\\\ \\frac{a\\times d - b\\times c}{R_2\\times C_2} & \\text{ if } a\\times d < b\\times c \\text{ and } a >  d \\end{cases}$$
    
    *Symbols used:*
    
    * \\(a\\) the count in the top-left cell of the cross table
    * \\(b\\) the count in the top-right cell of the cross table 
    * \\(c\\) the count in the bottom-left cell of the cross table 
    * \\(d\\) the count in the bottom-right cell of the cross table
    * \\(R_i\\) the sum of counts in the i-th row 
    * \\(C_i\\) the sum of counts in the i-th column
    
    Cole refers to this as the 'coefficient of interspecific association' 
    
    Note that Cole C2 is the phi coefficient, Cole C3 is McEwen-Michael coefficient, Cole C4 is Yule Q, and Cole C6 is Yule r.
    
    References
    ----------
    Cole, L. C. (1949). The measurement of interspecific associaton. *Ecology, 30*(4), 411–424. https://doi.org/10.2307/1932444
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> pd.set_option('display.width',1000)
    >>> pd.set_option('display.max_columns', 1000)
    >>> file1 = "https://peterstatistics.com/Packages/ExampleData/GSS2012a.csv"
    >>> df1 = pd.read_csv(file1, sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> es_cole_c7(df1['mar1'], df1['sex'], categories1=["WIDOWED", "DIVORCED"])
    0.2069060773480663
    
    '''
    # determine sample cross table
    tab = tab_cross(field1, field2, order1=categories1, order2=categories2, percent=None, totals="exclude")
    
    # cell values of sample cross table
    a = tab.iloc[0,0]
    b = tab.iloc[0,1]
    c = tab.iloc[1,0]
    d = tab.iloc[1,1]
    
    if (a*d >= b*c):
        c7 = (a*d-b*c)/((a+b)*(b+d))
    elif(a<=d):
        c7 = (a*d-b*c)/((a+b)*(a+c))
    else:
        c7 = (a*d-b*c)/((b+d)*(c+d))
    
    return(c7)