import pandas as pd
from scipy.stats import rankdata

def es_vargha_delaney_a(catField, ordField, categories=None, levels=None):
    '''
    Vargha-Delaney A
    ----------------
    A generalisation of the Common Language Effect size for ordinal data. Taking a random case from each of the two categories, Vargha-Delaney A is then the probability that the score of the first category is higher than the second.
    
    Parameters
    ----------
    catField : pandas series
        data with categories for the rows
    ordField : pandas series
        data with the scores (ordinal field)
    categories : list or dictionary, optional
        the two categories to use from catField. If not set the first two found will be used
    levels : list or dictionary, optional
        the scores in order
        
    Returns
    -------
    A dataframe with:
    
    * *A1*, Vargha-Delaney A for the first category
    * *A2*, Vargha-Delaney A for the second category
    
    Notes
    -----
    The formula used is (Vargha & Delaney, 2000, p. 107):
    $$A = \\frac{1}{n_j}\\times\\left(\\frac{R_i}{n_i} - \\frac{n_i + 1}{2}\\right)$$
    
    *Symbols used:*
    
    * \\(n_i\\) the number of scores in category i
    * \\(R_i\\) the sum of the ranks in category i
    
    It could also be calculated from the Mann-Whitney U value:
    $$A = \\frac{U}{n_1\\times n_2}$$
    
    Note that the difference between the two options (using category 1 or category 2) will be the deviation from 0.5. If all scores in the first category are lower than the scores in the second, A will be 0 using the first category, and 1 for the second.
    
    If the number of scores in the first category higher than the second, is the same as the other way around, A (no matter which category used) will be 0.5.
    
    References 
    ----------
    Vargha, A., & Delaney, H. D. (2000). A critique and improvement of the CL common language effect size statistics of McGraw and Wong. *Journal of Educational and Behavioral Statistics, 25*(2), 101–132. https://doi.org/10.3102/10769986025002101
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> file1 = "https://peterstatistics.com/Packages/ExampleData/GSS2012a.csv"
    >>> df1 = pd.read_csv(file1, sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> myLevels = {'Not scientific at all': 1, 'Not too scientific': 2, 'Pretty scientific': 3, 'Very scientific': 4}
    >>> es_vargha_delaney_a(df1['sex'], df1['accntsci'], levels=myLevels)
       A-FEMALE    A-MALE
    0  0.490644  0.509356
    
    
    '''
    #convert to pandas series if needed
    if type(catField) is list:
        catField = pd.Series(catField)
    
    if type(ordField) is list:
        ordField = pd.Series(ordField)
    
    #combine as one dataframe
    df = pd.concat([catField, ordField], axis=1)
    df = df.dropna()
    
    #replace the ordinal values if levels is provided
    if levels is not None:
        df.iloc[:,1] = df.iloc[:,1].replace(levels)
        df.iloc[:,1]  = pd.to_numeric(df.iloc[:,1] )
    else:
        df.iloc[:,1]  = pd.to_numeric(df.iloc[:,1] )
    
    #the two categories
    if categories is not None:
        cat1 = categories[0]
        cat2 = categories[1]
    else:
        cat1 = df.iloc[:,0].value_counts().index[0]
        cat2 = df.iloc[:,0].value_counts().index[1]
    
    #seperate the scores for each category
    scoresCat1 = list(df.iloc[:,1][df.iloc[:,0] == cat1])
    scoresCat2 = list(df.iloc[:,1][df.iloc[:,0] == cat2])
    
    n1 = len(scoresCat1)
    n2 = len(scoresCat2)
    n = n1 + n2
    
    #combine this into one long list
    allScores = scoresCat1 + scoresCat2
    
    #get the ranks
    allRanks = rankdata(allScores)
    
    #get the ranks per category
    cat1Ranks = allRanks[0:n1]
    cat2Ranks = allRanks[n1:n]
    
    r1 = sum(cat1Ranks)
    r2 = sum(cat2Ranks)
    
    a1 = 1 / n2 * (r1 / n1 - (n1 + 1) / 2)
    a2 = 1 / n1 * (r2 / n2 - (n2 + 1) / 2)
    
    colNames = ["A-" + cat1, "A-"+ cat2]
    results = pd.DataFrame([[a1, a2]], columns=colNames)
    
    return results