import math
import pandas as pd
from ..other.table_cross import tab_cross

def es_edward_q(field1, field2, categories1=None, categories2=None):
    '''
    Edward Q
    --------
    A measure of association between two binary variables.
    
    Yule Q and Yule Y can each be written in the format of:
    $$\\frac{OR^x - 1}{OR^x + 1}$$
    
    With OR being the Odds Ratio. For Yule Q the \\(x=1\\) and for Yule Y \\(x=0.5\\). Digby (1983, p. 754) showed that Yule’s Q consistently overestimates the association, while Yule’s Y underestimates it It seems that a better approximation might be somewhere between 0.5 and 1 as the power to use on the Odds Ratio. 
    
    Edwards proposed to use \\(\\frac{\\pi}{4}\\)
    
    Parameters
    ----------
    field1 : pandas series
        data with categories for the rows
    field2 : pandas series
        data with categories for the columns
    categories1 : list or dictionary, optional
        the two categories to use from field1. If not set the first two found will be used
    categories2 : list or dictionary, optional
        the two categories to use from field2. If not set the first two found will be used

    Returns
    -------
    Edward Q
        
    Notes
    -----    
    The formula used (Edwards 1957, as cited in Becker & Clogg, 1988, p. 408):
    $$Q_E = \\frac{OR^{\\frac{\\pi}{4}} - 1}{OR^{\\frac{\\pi}{4}} + 1}$$
    
    With:
    $$OR = \\frac{a\\times d}{b \\times c}$$
    
    *Symbols used:*
    
    * \\(a\\) the count in the top-left cell of the cross table
    * \\(b\\) the count in the top-right cell of the cross table 
    * \\(c\\) the count in the bottom-left cell of the cross table 
    * \\(d\\) the count in the bottom-right cell of the cross table
    * \\(OR\\) the Odds Ratio
    
    References
    ----------
    Becker, M. P., & Clogg, C. C. (1988). A note on approximating correlations from Odds Ratios. *Sociological Methods & Research, 16*(3), 407–424. https://doi.org/10.1177/0049124188016003003
    
    Digby, P. G. N. (1983). Approximating the tetrachoric correlation coefficient. *Biometrics, 39*(3), 753–757. https://doi.org/10.2307/2531104
    
    Edwards, J. H. (1957). A note on the practical interpretation of 2 x 2 tables. *Journal of Epidemiology & Community Health, 11*(2), 73–78. https://doi.org/10.1136/jech.11.2.73
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> pd.set_option('display.width',1000)
    >>> pd.set_option('display.max_columns', 1000)
    >>> file1 = "https://peterstatistics.com/Packages/ExampleData/GSS2012a.csv"
    >>> df1 = pd.read_csv(file1, sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> es_edward_q(df1['mar1'], df1['sex'], categories1=["WIDOWED", "DIVORCED"])
    0.21646136563622564
    
    '''
    # determine sample cross table
    tab = tab_cross(field1, field2, order1=categories1, order2=categories2, percent=None, totals="exclude")
    
    # cell values of sample cross table
    a = tab.iloc[0,0]
    b = tab.iloc[0,1]
    c = tab.iloc[1,0]
    d = tab.iloc[1,1]
    
    odrat = a*d/(b*c)
    q = ((odrat)**(math.pi/4)-1)/((odrat)**(math.pi/4)+1)
    
    return(q)