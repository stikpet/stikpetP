import math
import pandas as pd
from ..other.table_cross import tab_cross

def es_pearson_q1(field1, field2, categories1=None, categories2=None):
    '''
    Pearson Q1
    ----------
    
    An effect size measure for two binary variables.
    
    Note that Pearson (1900) stated: "Q1 was found of little service" (p. 16).
    
    Parameters
    ----------
    field1 : pandas series
        data with categories for the rows
    field2 : pandas series
        data with categories for the columns
    categories1 : list or dictionary, optional
        the two categories to use from field1. If not set the first two found will be used
    categories2 : list or dictionary, optional
        the two categories to use from field2. If not set the first two found will be used

    Returns
    -------
    Pearson Q1
        
    Notes
    -----    
    The formula used (Pearson, 1900, p. 15):
    $$Q_1 = \\sin\\left(\\frac{\\pi}{2} \\times \\frac{a\\times d - b\\times c}{\\left(a+b\\right)\\times\\left(b+d\\right)}\\right)$$
    
    With:
    The cross table arranged such that \\(a\\times d > b\\times c}, \\(a>d}, and \\(c>b}.
    
    *Symbols used:*
    
    * \\(a\\) the count in the top-left cell of the cross table
    * \\(b\\) the count in the top-right cell of the cross table 
    * \\(c\\) the count in the bottom-left cell of the cross table 
    * \\(d\\) the count in the bottom-right cell of the cross table 
    
    Note that Pearson Q2 is the same as Yule Q and Pearson Q3 is the same as Yule r.
    
    References
    ----------
    Pearson, K. (1900). Mathematical contributions to the theory of evolution. VII. On the correlation of characters not quantitatively measurable. *Philosophical Transactions of the Royal Society of London, 195*, 1–405. https://doi.org/10.1098/rsta.1900.0022
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> pd.set_option('display.width',1000)
    >>> pd.set_option('display.max_columns', 1000)
    >>> file1 = "https://peterstatistics.com/Packages/ExampleData/GSS2012a.csv"
    >>> df1 = pd.read_csv(file1, sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> es_pearson_q1(df1['mar1'], df1['sex'], categories1=["WIDOWED", "DIVORCED"])
    -0.7693502771706044
    
        
    '''
    # determine sample cross table
    tab = tab_cross(field1, field2, order1=categories1, order2=categories2, percent=None, totals="exclude")
    
    # cell values of sample cross table
    a = tab.iloc[0,0]
    b = tab.iloc[0,1]
    c = tab.iloc[1,0]
    d = tab.iloc[1,1]
    
    #Pearson requires for Q1 that ad>bc, a>d, and c>b
    sw = -1
    runs=0
    
    while(runs < 2):
        #swop the rows
        if (a*d < b*c or a < d or c < b):
            at = a
            a = c
            c = at
            bt = b
            b = d
            d = bt
            sw = -sw
        #swop columns
        if (a*d < b*c or a < d or c < b):
            at = a
            a = b
            b = at
            ct = c
            c = d
            d = ct
            sw = -sw
        #swop the rows again
        if (a*d < b*c or a < d or c < b):
            at = a
            a = c
            c = at
            bt = b
            b = d
            d = bt
            sw = -sw
        #pivot the table
        if (a*d < b*c or a < d or c < b):
            bt = b
            b = c
            c = bt
            sw = -sw
        
        runs = runs + 1    
   
    q1 = sw*math.sin(math.pi/2 * (c+d)*(a+c)/((a+b) * (b+d)))
  
    return(q1)