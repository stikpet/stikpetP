import pandas as pd
from ..other.table_cross import tab_cross

def es_cole_c1(field1, field2, categories1=None, categories2=None):
    '''
    Cole C1
    -------
    A measure of association between two binary variables.
    
    This is an adjustment of the Forbes coefficient, to convert the scale between -1 and 1, by simply subtracting 1 from Forbes F.
    
    Parameters
    ----------
    field1 : pandas series
        data with categories for the rows
    field2 : pandas series
        data with categories for the columns
    categories1 : list or dictionary, optional
        the two categories to use from field1. If not set the first two found will be used
    categories2 : list or dictionary, optional
        the two categories to use from field2. If not set the first two found will be used

    Returns
    -------
    Cole C1
        
    Notes
    -----    
    The formula used (Cole, 1949, p. 415):
    $$C_1 = \\frac{a\\times d - b\\times c}{\\left(a+b\\right)\\times\\left(a+c\\right)}$$
    
    *Symbols used:*
    
    * \\(a\\) the count in the top-left cell of the cross table
    * \\(b\\) the count in the top-right cell of the cross table 
    * \\(c\\) the count in the bottom-left cell of the cross table 
    * \\(d\\) the count in the bottom-right cell of the cross table 
    
    It is an adjustment of Forbes F so it would range from -1 to 1. 
    
    Note that Cole C2 is the phi coefficient, Cole C3 is McEwen-Michael coefficient, Cole C4 is Yule Q, and Cole C6 is Yule r.
    
    References
    ----------
    Cole, L. C. (1949). The measurement of interspecific associaton. *Ecology, 30*(4), 411–424. https://doi.org/10.2307/1932444
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> pd.set_option('display.width',1000)
    >>> pd.set_option('display.max_columns', 1000)
    >>> file1 = "https://peterstatistics.com/Packages/ExampleData/GSS2012a.csv"
    >>> df1 = pd.read_csv(file1, sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> es_cole_c1(df1['mar1'], df1['sex'], categories1=["WIDOWED", "DIVORCED"])
    0.1402753066766551
    
    '''
    # determine sample cross table
    tab = tab_cross(field1, field2, order1=categories1, order2=categories2, percent=None, totals="exclude")
    
    # cell values of sample cross table
    a = tab.iloc[0,0]
    b = tab.iloc[0,1]
    c = tab.iloc[1,0]
    d = tab.iloc[1,1]
    
    c1 = (a*d - b*c)/((a+b) * (a+c))
    
    return(c1)