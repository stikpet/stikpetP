import pandas as pd
from ..other.table_cross import tab_cross

def es_digby_h(field1, field2, categories1=None, categories2=None):
    '''
    Digby H
    --------
    A measure of association between two binary variables.
    
    Yule Q and Yule Y can each be written in the format of:
    $$\\frac{OR^x - 1}{OR^x + 1}$$
    
    With OR being the Odds Ratio. For Yule Q the \\(x=1\\) and for Yule Y \\(x=0.5\\). Digby (1983, p. 754) showed that Yule’s Q consistently overestimates the association, while Yule’s Y underestimates it It seems that a better approximation might be somewhere between 0.5 and 1 as the power to use on the Odds Ratio. Digby proposed to use 0.75
    
    Parameters
    ----------
    field1 : pandas series
        data with categories for the rows
    field2 : pandas series
        data with categories for the columns
    categories1 : list or dictionary, optional
        the two categories to use from field1. If not set the first two found will be used
    categories2 : list or dictionary, optional
        the two categories to use from field2. If not set the first two found will be used

    Returns
    -------
    Digby H
        
    Notes
    -----    
    The formula used (Digby, 1983, pp. 753-754):
    $$H = \\frac{\\left(a\\times d\\right)^{3/4} - \\left(b\\times c\\right)^{3/4}}{\\left(a\\times d\\right)^{3/4} + \\left(b\\times c\\right)^{3/4}}$$
    
    Alternative this can be written as:
    $$H= \\frac{OR^{3/4}-1}{OR^{3/4}+1}$$
    
    With:
    $$OR = \\frac{a\\times d}{b \\times c}$$
    
    *Symbols used:*
    
    * \\(a\\) the count in the top-left cell of the cross table
    * \\(b\\) the count in the top-right cell of the cross table 
    * \\(c\\) the count in the bottom-left cell of the cross table 
    * \\(d\\) the count in the bottom-right cell of the cross table
    * \\(OR\\) the Odds Ratio
    
    References
    ----------
    Digby, P. G. N. (1983). Approximating the tetrachoric correlation coefficient. *Biometrics, 39*(3), 753–757. https://doi.org/10.2307/2531104
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> pd.set_option('display.width',1000)
    >>> pd.set_option('display.max_columns', 1000)
    >>> file1 = "https://peterstatistics.com/Packages/ExampleData/GSS2012a.csv"
    >>> df1 = pd.read_csv(file1, sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> es_digby_h(df1['mar1'], df1['sex'], categories1=["WIDOWED", "DIVORCED"])
    0.2069930342023453
    
    '''
    # determine sample cross table
    tab = tab_cross(field1, field2, order1=categories1, order2=categories2, percent=None, totals="exclude")
    
    # cell values of sample cross table
    a = tab.iloc[0,0]
    b = tab.iloc[0,1]
    c = tab.iloc[1,0]
    d = tab.iloc[1,1]
    
    h = ((a*d)**0.75 - (b*c)**0.75) / ((a*d)**0.75 + (b*c)**0.75)
    
    return(h)