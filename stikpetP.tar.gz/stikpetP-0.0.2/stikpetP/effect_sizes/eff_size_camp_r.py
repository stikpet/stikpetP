import math
import pandas as pd
from ..other.table_cross import tab_cross
from statistics import NormalDist

def es_camp_r(field1, field2, categories1=None, categories2=None, method="cureton"):
    '''
    Camp r
    ----------
    
    An approximation for the tetrachoric correlation coefficient. 
    
    Parameters
    ----------
    field1 : pandas series
        data with categories for the rows
    field2 : pandas series
        data with categories for the columns
    categories1 : list or dictionary, optional
        the two categories to use from field1. If not set the first two found will be used
    categories2 : list or dictionary, optional
        the two categories to use from field2. If not set the first two found will be used
    method : {"cureton", "camp1", "camp2"}, optional
        method to use for phi

    Returns
    -------
    Camp r
    
    Notes
    -----    
    Camp (1934, pp. 309) describes the following steps for the calculation:
    
    Step 1: If total of column 1 (C1) is less than column 2 (C2), swop the two columns
    
    Step 2: Calculate \\(p = \\frac{C1}{n}\\), \\(p_1 = \\frac{a}{n}\\), and \\(p_2 = \\frac{c}{C2}\\)
    
    Step 3: Determine \\(z_1\\), \\(z_2\\), \\(z_3\\) as the normal deviate corresponding to the area \\(p_1\\), \\(p_2\\), \\(p\\) resp. (inverse standard normal cumulative distribution)
    
    Step 4: Determine y the normal ordinate corresponding to \\(z_3\\) (the height of the normal distribution)
    
    Step 5: Calculate \\(m = \\frac{p\\times\\left(1-p\\right)\\times\\left(z_1 + z_2\\right)}{y}\\)
    
    Step 6: Find phi in a table of phi values
    
    Camp suggested for a very basic approximation to simply use \\eqn{\\phi=1}.
    
    For a better approximation Camp made the following table:
    
    | p | 0.5 | 0.6 | 0.7 | 0.8 | 0.9 |
    |---|-----|-----|-----|-----|-----|
    |phi|0.637|0.63|0.62|0.60|0.56|
    
    Cureton (1968, p. 241) expanded on this table and produced:
    
    | p | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
    |-----|-------|-------|-------|-------|-------|-------|-------|-------|-------|-------|-------|
    | 0.5 | 0.637 | 0.636 | 0.636 | 0.635 | 0.635 | 0.634 | 0.634 | 0.633 | 0.633 | 0.632 | 0.631 |
    | 0.6 | 0.631 | 0.631 | 0.630 | 0.629 | 0.628 | 0.627 | 0.626 | 0.625 | 0.624 | 0.622 | 0.621 |
    | 0.7 | 0.621 | 0.620 | 0.618 | 0.616 | 0.614 | 0.612 | 0.610 | 0.608 | 0.606 | 0.603 | 0.600 |
    | 0.8 | 0.600 | 0.597 | 0.594 | 0.591 | 0.587 | 0.583 | 0.579 | 0.574 | 0.569 | 0.564 | 0.559 |
    
    Step 7: Calculate \\(r_t = \\frac{m}{\\sqrt{1+\\phi\\times m^2}}\\)
    
    *Symbols used:*
    
    * \\(a\\) the count in the top-left cell of the cross table
    * \\(b\\) the count in the top-right cell of the cross table 
    * \\(c\\) the count in the bottom-left cell of the cross table 
    * \\(d\\) the count in the bottom-right cell of the cross table
    * \\(R_i\\) the sum of counts in the i-th row
    * \\(C_i\\) the sum of counts in the i-th column
    
    Cureton (1968) describes quite a few shortcomings with this approximation, and circumstances when it might be appropriate.
    
    References
    ----------
    Camp, B. H. (1934). *Mathematical part of elementary statistics*. D.C. Heath and Company, London.
    
    Cureton, E. E. (1968). Tetrachoric correlation by the Camp approximation. *Educational and Psychological Measurement, 28*(2), 239–244. https://doi.org/10.1177/001316446802800202
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> file1 = "https://peterstatistics.com/Packages/ExampleData/GSS2012a.csv"
    >>> df1 = pd.read_csv(file1, sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> es_camp_r(df1['mar1'], df1['sex'], categories1=["WIDOWED", "DIVORCED"])
    0.21063580021670522
    
    >>> es_camp_r(df1['mar1'], df1['sex'], categories1=["WIDOWED", "DIVORCED"], method="camp1")
    0.2089324656253958
    
    >>> es_camp_r(df1['mar1'], df1['sex'], categories1=["WIDOWED", "DIVORCED"], method="camp2")
    0.2106077696990773
    
    
    '''
    
    # determine sample cross table
    tab = tab_cross(field1, field2, order1=categories1, order2=categories2, percent=None, totals="exclude")
    
    # cell values of sample cross table
    a = tab.iloc[0,0]
    b = tab.iloc[0,1]
    c = tab.iloc[1,0]
    d = tab.iloc[1,1]
    
    #swop columns if first column total is less than second
    #"always orienting the table initially so that F1 > 0.5" (Camp, 1934, p. 309)
    sg = 1
    if a+c < b+d:
        at = a
        a = b
        b = at
        
        ct = c
        c = d
        d = ct
        
        sg = -1
    
    #The totals
    R1 = a + b
    R2 = c + d
    C1 = a + c
    C2 = b + d
    n = R1 + R2
    
    #step 2: determine three proportions
    p1 = a/C1
    p2 = d/C2
    p = C1/n
    
    #step 3: determine the corresponding z-values
    z1 = NormalDist().inv_cdf(p1)
    z2 = NormalDist().inv_cdf(p2)
    z3 = NormalDist().inv_cdf(p)
    
    #step 4: determine the height of the normal distribution
    y = NormalDist().pdf(z3)
    
    #step 5: calculate m
    m = p*(1-p)*(z1+z2)/y
    
    if method=="camp1":
        phi=1
    
    elif method=="camp2":
        thetaTable = {0.5:0.637, 0.6:0.63, 0.7:0.62, 0.8:0.6, 0.9:0.56}
        phi = thetaTable[math.trunc(p*10)/10]
    
    else:
        #step 6: find phi in table of phi-values
        thetaTable = {0.5:[0.637, 0.636, 0.636, 0.635, 0.635, 0.634, 0.634, 0.633, 0.633, 0.632, 0.631], 
                       0.6:[0.631, 0.631, 0.63, 0.629, 0.628, 0.627, 0.626, 0.625, 0.624, 0.622, 0.621], 
                       0.7:[0.621, 0.62, 0.618, 0.616, 0.614, 0.612, 0.61, 0.608, 0.606, 0.603, 0.6], 
                       0.8:[0.6, 0.597, 0.594, 0.591, 0.587, 0.583, 0.579, 0.574, 0.569, 0.564, 0.559]}

        phi = thetaTable[math.trunc(p*10)/10][int(round(p*100,0))-math.trunc(p*10)*10]

    #step 7: calculate r
    r = sg * m/(1+phi*m**2)**0.5

    return (r)