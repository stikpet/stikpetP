import pandas as pd
from ..other.table_cross import tab_cross

def es_bonett_price_y(field1, field2, categories1=None, categories2=None):
    '''
    Bonett and Price Y*
    -------------------
    A measure of association between two binary variables.
    
    Yule Q and Yule Y can each be written in the format of:
    $$\\frac{OR^x - 1}{OR^x + 1}$$
    
    With OR being the Odds Ratio. For Yule Q the \eqn{x=1} and for Yule Y \\(x=0.5\\). Digby (1983, p. 754) showed that Yule’s Q consistently overestimates the association, while Yule’s Y underestimates it It seems that a better approximation might be somewhere between 0.5 and 1 as the power to use on the Odds Ratio. Bonett and Price derived a formula to determine the optimal value for x in each situation.
    
    Parameters
    ----------
    field1 : pandas series
        data with categories for the rows
    field2 : pandas series
        data with categories for the columns
    categories1 : list or dictionary, optional
        the two categories to use from field1. If not set the first two found will be used
    categories2 : list or dictionary, optional
        the two categories to use from field2. If not set the first two found will be used

    Returns
    -------
    Bonett and Price Y*
        
    Notes
    -----    
    The formula used (Bonett and Price, 2007, pp. 433-434):
    $$Y* = \\frac{\\hat{\\omega}^x-1}{\\hat{\\omega}^x+1}$$
    
    With:
    $$x = \\frac{1}{2}-\\left(\\frac{1}{2}-p_{min}\\right)^2$$
    $$p_{min} = \\frac{\\min\\left(R_1, R_2, C_1, C_2\\right)}{n}$$
    $$\\hat{\\omega} = \\frac{\\left(a+0.1\\right)\\times\\left(d+0.1\\right)}{\\left(b+0.1\\right)\\times\\left(c+0.1\\right)}$$
    
    *Symbols used:*
    
    * \\(a\\) the count in the top-left cell of the cross table
    * \\(b\\) the count in the top-right cell of the cross table 
    * \\(c\\) the count in the bottom-left cell of the cross table 
    * \\(d\\) the count in the bottom-right cell of the cross table
    * \\(R_i\\) the sum of counts in the i-th row 
    * \\(C_i\\) the sum of counts in the i-th column
    
    Note that \\(\\hat{\\omega}\\) is a biased corrected version of the Odds Ratio
    
    References
    ----------
    Bonett, D. G., & Price, R. M. (2007). Statistical inference for generalized yule coefficients in 2 × 2 contingency tables. *Sociological Methods & Research, 35*(3), 429–446. https://doi.org/10.1177/0049124106292358
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> pd.set_option('display.width',1000)
    >>> pd.set_option('display.max_columns', 1000)
    >>> file1 = "https://peterstatistics.com/Packages/ExampleData/GSS2012a.csv"
    >>> df1 = pd.read_csv(file1, sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> es_bonett_price_y(df1['mar1'], df1['sex'], categories1=["WIDOWED", "DIVORCED"])
    0.13396448908572506
    
    '''
    # determine sample cross table
    tab = tab_cross(field1, field2, order1=categories1, order2=categories2, percent=None, totals="exclude")
    
    # cell values of sample cross table
    a = tab.iloc[0,0]
    b = tab.iloc[0,1]
    c = tab.iloc[1,0]
    d = tab.iloc[1,1]
    
    #the totals
    R1 = a + b
    R2 = c + d
    C1 = a + c
    C2 = b + d
    n = R1 + R2
    #smallest proportion of rows and columns
    pMin = min(min(R1, R2),  min(C1, C2))/n

    #determine power to use
    pwr = 1/2 - (1/2 - pMin)**2

    #odds ratio
    OR = a*d/(b*c)
    #adjust the odds ratio
    ORadj = (a+0.1)*(d+0.1)/((b+0.1)*(c+0.1))

    ybp = (ORadj**pwr - 1)/(ORadj**pwr + 1)

    return(ybp)