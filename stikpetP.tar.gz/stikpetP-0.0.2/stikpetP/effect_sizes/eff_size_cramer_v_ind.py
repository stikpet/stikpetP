def es_cramer_v_ind(chi2, n, r, c, cc=None):
    m = min(r, c)
    
    if cc=="bergsma":
        phi2 = chi2/n
        mHat = m - (m - 1)**2/(n - 1)
        df = (r - 1)*(c - 1)
        phi2 = max(0, phi2 - df/(n - 1))
        
        es = (phi2/(mHat - 1))**0.5
    else:
        es = (chi2/(n*min(r-1, c-1)))**0.5
        
    return es