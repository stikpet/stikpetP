from ..effect_sizes.eff_size_eta_sq import es_eta_sq

def es_cohen_f(nomField, scaleField, categories=None, useRanks=False):
    
    eta2 = es_eta_sq(nomField, scaleField, categories, useRanks=useRanks)
    
    f2 = eta2 / (1 - eta2)
        
    return (f2)**0.5