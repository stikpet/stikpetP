import pandas as pd
from ..other.table_cross import tab_cross

def es_cole_c5(field1, field2, categories1=None, categories2=None):
    '''
    Cole C5
    -------
    A measure of association between two binary variables.
    
    This is actually an adjustment of the contingency coefficient, by dividing it over \\(\\sqrt{\\frac{1}{2}}\\), which is the maximum value in 2x2 tables.
    
    Parameters
    ----------
    field1 : pandas series
        data with categories for the rows
    field2 : pandas series
        data with categories for the columns
    categories1 : list or dictionary, optional
        the two categories to use from field1. If not set the first two found will be used
    categories2 : list or dictionary, optional
        the two categories to use from field2. If not set the first two found will be used

    Returns
    -------
    Cole C5
        
    Notes
    -----    
    The formula used (Cole, 1949, p. 416):
    $$C_5 = \\frac{\sqrt{2}\\times\\left(a\\times d - b\\times c\\right)}{\\sqrt{\\left(a\\times d - b\\times c\\right)^2 + R_1\\times R_2\\times C_1\\times C_2}}}
    
    *Symbols used:*
    
    * \\(a\\) the count in the top-left cell of the cross table
    * \\(b\\) the count in the top-right cell of the cross table 
    * \\(c\\) the count in the bottom-left cell of the cross table 
    * \\(d\\) the count in the bottom-right cell of the cross table
    * \\(R_i\\) the sum of counts in the i-th row 
    * \\(C_i\\) the sum of counts in the i-th column
    
    Note that Cole C2 is the phi coefficient, Cole C3 is McEwen-Michael coefficient, Cole C4 is Yule Q, and Cole C6 is Yule r.
    
    References
    ----------
    Cole, L. C. (1949). The measurement of interspecific associaton. *Ecology, 30*(4), 411–424. https://doi.org/10.2307/1932444
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> pd.set_option('display.width',1000)
    >>> pd.set_option('display.max_columns', 1000)
    >>> file1 = "https://peterstatistics.com/Packages/ExampleData/GSS2012a.csv"
    >>> df1 = pd.read_csv(file1, sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> es_cole_c5(df1['mar1'], df1['sex'], categories1=["WIDOWED", "DIVORCED"])
    0.18141108373218823
    
    '''
    # determine sample cross table
    tab = tab_cross(field1, field2, order1=categories1, order2=categories2, percent=None, totals="exclude")
    
    # cell values of sample cross table
    a = tab.iloc[0,0]
    b = tab.iloc[0,1]
    c = tab.iloc[1,0]
    d = tab.iloc[1,1]
    
    #row and column totals
    R1 = a+b
    R2 = c+d
    C1 = a+c
    C2 = b+d
    
    c5 = (2)**0.5 * (a*d-b*c)/((a*d - b*c)**2 + R1*R2*C1*C2)**0.5
    
    return(c5)