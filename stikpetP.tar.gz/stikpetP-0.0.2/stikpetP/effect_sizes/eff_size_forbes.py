import math
import pandas as pd
from ..other.table_cross import tab_cross

def es_forbes(field1, field2, categories1=None, categories2=None):
    '''
    Forbes Coefficient
    ------------------
    
    An effect size measure for two binary variables.
    
    A measure for the association between two binary variables. If all values are equal in the cross table, there is no association. Forbes uses that if all values are the same, then:
    $$1 = \\frac{\\left(a+b\\right)\\times\\left(a+c\\right)}{n}$$
    
    While the above equation would result in 0 or 2 if there is a perfect association (i.e. b or c is 0).
    
    Parameters
    ----------
    field1 : pandas series
        data with categories for the rows
    field2 : pandas series
        data with categories for the columns
    categories1 : list or dictionary, optional
        the two categories to use from field1. If not set the first two found will be used
    categories2 : list or dictionary, optional
        the two categories to use from field2. If not set the first two found will be used

    Returns
    -------
    Forbes Coefficient
        
    Notes
    -----    
    The formula used (Forbes, 1907, p. 279):
    $$F = \\frac{n\\times\\min\\left(a, d\\right)}{C_1\\times R_1}$$
    
    *Symbols used:*
    
    * \\(a\\) the count in the top-left cell of the cross table
    * \\(b\\) the count in the top-right cell of the cross table 
    * \\(c\\) the count in the bottom-left cell of the cross table 
    * \\(d\\) the count in the bottom-right cell of the cross table 
    * \\(R_1\\) the sum of counts in the 1st row 
    * \\(C_1\\) the sum of counts in the 1st column 
    
    References
    ----------
    Forbes, S. A. (1907). On the local distribution of certain Illinois fishes: An essay in statistical ecology. *Illinois Natural History Survey Bulletin, 7*(8), 273–303.
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> pd.set_option('display.width',1000)
    >>> pd.set_option('display.max_columns', 1000)
    >>> file1 = "https://peterstatistics.com/Packages/ExampleData/GSS2012a.csv"
    >>> df1 = pd.read_csv(file1, sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> es_forbes(df1['mar1'], df1['sex'], categories1=["WIDOWED", "DIVORCED"])
    1.140275306676655
    
    '''
    # determine sample cross table
    tab = tab_cross(field1, field2, order1=categories1, order2=categories2, percent=None, totals="exclude")
    
    # cell values of sample cross table
    a = tab.iloc[0,0]
    b = tab.iloc[0,1]
    c = tab.iloc[1,0]
    d = tab.iloc[1,1]
    
    n = a + b + c + d
    f = n*min(a, d)/((a+c)*(a+b))
  
    return(f)