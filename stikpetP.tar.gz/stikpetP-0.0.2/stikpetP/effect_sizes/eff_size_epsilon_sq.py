import pandas as pd
from ..other.table_cross import tab_cross
from ..effect_sizes.eff_size_eta_sq import es_eta_sq

def es_epsilon_sq(catField, ordField, categories=None, levels=None, useRanks=False):
    #create the cross table    
    ct = tab_cross(ordField, catField, order1=levels, order2=categories, totals="include")
    
    #basic counts
    k = ct.shape[1]-1
    nlvl = ct.shape[0]-1
    n = ct.iloc[nlvl, k]
    
    lvlRank = pd.Series(dtype="object")
    cf = 0
    for i in range(0, nlvl):
        if useRanks:
            lvlRank.at[i] = (2 * cf + ct.iloc[i, k] + 1) / 2
            cf = cf + ct.iloc[i, k]
        else:
            lvlRank.at[i] = ct.index[i]
    
    #sum of ranks per category
    srj = pd.Series(dtype="object")
    mrj = pd.Series(dtype="object")
    n = 0
    mr = 0
    for j in range(0, k):
        sr = 0
        for i in range(0, nlvl):
             sr = sr + ct.iloc[i, j] * lvlRank.iloc[i]
        srj.at[j] = sr
        mrj.at[j] = sr / ct.iloc[nlvl, j]
        mr = mr + sr
        n = n + ct.iloc[nlvl, j]
    
    mr = mr / n
    
    #ss between
    ssb = 0
    for j in range(0, k):
        ssb = ssb + ct.iloc[nlvl, j] * (mrj.iloc[j] - mr)**2
    
    #ss total
    sst = 0
    for i in range(0, nlvl):
        for j in range(0, k):
            sst = sst + ct.iloc[i, j] * (lvlRank.iloc[i] - mr)**2
    
    ssw = sst - ssb
    msw = ssw / (n - k + 1)
    eps = (ssb - (k - 1) * msw) / sst
    
    e2 = es_eta_sq(catField, ordField, categories, levels, useRanks)
    
    eps = (n * e2 - k + (1 - e2)) / (n - k)

    return eps