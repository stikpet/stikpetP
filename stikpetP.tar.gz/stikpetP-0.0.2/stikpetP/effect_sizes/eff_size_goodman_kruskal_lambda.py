import pandas as pd
from statistics import NormalDist
from random import random
from ..other.table_cross import tab_cross

def es_goodman_kruskal_lambda(field1, field2, categories1=None, categories2=None, ties="first"):
    #The average method only averages column and row maximums (rm and cm),
    #it uses "first" for ties in fim and fmj.
    
    #create the cross table
    ct = tab_cross(field1, field2, categories1, categories2, totals="include")
    
    
    #basic counts
    nrows = ct.shape[0]-1
    ncols =  ct.shape[1]-1
    n = ct.iloc[nrows, ncols]
    
    #the margin totals
    rs = ct.iloc[0:nrows, ncols]
    cs = ct.iloc[nrows, 0:ncols]
    
    rm = max(rs)
    cm = max(cs)
    
    rowMaxColIndex = [0]*nrows
    rowTotalsMaxRowIndex = 0
    fim = [0]*nrows
    rowMaxFreq = [0]*nrows
    rowTotalsMaxRowFreq = 0
    for i in range(0, nrows):
        rowMax = 0
        for j in range(0, ncols):
            if ties=="first" and ct.iloc[i, j] > rowMax:
                rowMaxColIndex[i] = j
                rowMax = ct.iloc[i, j]
                fim[i] = rowMax
            elif ties=="last" and ct.iloc[i, j] >= rowMax:
                rowMaxColIndex[i] = j
                rowMax = ct.iloc[i, j]
                fim[i] = rowMax
            elif ties=="average" and ct.iloc[i, j] >= rowMax:
                if ct.iloc[i, j] > rowMax:
                    rowMaxFreq[i] = 1
                    rowMax = ct.iloc[i, j]
                    fim[i] = rowMax
                elif ct.iloc[i, j] == rowMax:
                    rowMaxFreq[i] = rowMaxFreq[i] + 1
                
            elif ties=="random":
                if ct.iloc[i, j] > rowMax:
                    rowMaxColIndex[i] = j
                    rowMax = ct.iloc[i, j]
                    fim[i] = rowMax
                    rowMaxFreq[i] = 1
                elif ct.iloc[i, j] == rowMax:
                    rowMaxFreq[i] = rowMaxFreq[i] + 1
                    if random() < (1 / rowMaxFreq[i]):
                        rowMaxColIndex[i] = j
                    
        if rs[i]==rm:
            if ties=="last":
                rowTotalsMaxRowIndex = i
            elif ties=="first":
                if rowTotalsMaxRowFreq==0:
                    rowTotalsMaxRowIndex = i
            elif ties=="random":
                if rowTotalsMaxRowFreq==0:
                    rowTotalsMaxRowIndex = i
                else:
                    if random() < (1 / rowTotalsMaxRowFreq):
                        rowTotalsMaxRowIndex = i
                        
            #ties = average is not needed since it does not use the rowTotalsMaxRowIndex
            rowTotalsMaxRowFreq = rowTotalsMaxRowFreq + 1
    
    #same for the columns
    colMaxRowIndex = [0]*ncols
    colTotalsMaxColIndex = 0
    fmj = [0]*ncols
    colMaxFreq = [0]*ncols
    colTotalsMaxColFreq = 0
    for j in range(0, ncols):
        colMax = 0
        for i in range(0, nrows):    
            if ties=="first" and ct.iloc[i, j] > colMax:
                colMaxRowIndex[j] = i
                colMax = ct.iloc[i, j]
                fmj[j] = colMax
            elif ties=="last" and ct.iloc[i, j] >= colMax:
                colMaxRowIndex[j] = i
                colMax = ct.iloc[i, j]
                fmj[j] = colMax
            elif ties=="average" and ct.iloc[i, j] >= colMax:
                if ct.iloc[i, j] > colMax:
                    colMaxFreq[j] = 1
                    colMax = ct.iloc[i, j]
                    fmj[j] = colMax
                elif ct.iloc[i, j] == colMax:
                    colMaxFreq[j] = colMaxFreq[j] + 1
                
            elif ties=="random":
                if ct.iloc[i, j] > colMax:
                    colMaxRowIndex[j] = i
                    colMax = ct.iloc[i, j]
                    fmj[j] = colMax
                    colMaxFreq[j] = 1
                elif ct.iloc[i, j] == colMax:
                    colMaxFreq[j] = colMaxFreq[j] + 1
                    if random() < (1 / colMaxFreq[j]):
                        colMaxRowIndex[j] = i
                    
        if cs[j]==cm:
            if ties=="last":
                colTotalsMaxColIndex = j
            elif ties=="first":
                if colTotalsMaxColFreq==0:
                    colTotalsMaxColIndex = j
            elif ties=="random":
                if colTotalsMaxColFreq==0:
                    colTotalsMaxColIndex = j
                else:
                    if random() < (1 / colTotalsMaxColFreq):
                        colTotalsMaxColIndex = j
                        
            #ties = average is not needed since it does not use the rowTotalsMaxRowIndex
            colTotalsMaxColFreq = colTotalsMaxColFreq + 1
    
    dijc = pd.DataFrame()
    for i in range(0, nrows):
        for j in range(0, ncols):
            if ties=="average":
                if ct.iloc[i, j]==fim[i]:
                    dijc.at[i, j] = 1 / rowMaxFreq[i]
                else:
                    dijc.at[i, j] = 0
            else:
                if j==rowMaxColIndex[i]:
                    dijc.at[i, j] = 1
                else:
                    dijc.at[i, j] = 0
    
    djc = [0]*ncols
    for j in range(0, ncols):
        if cs[j]==cm:
            if ties=="average":
                djc[j] = 1 / colTotalsMaxColFreq
            elif colTotalsMaxColIndex==j:
                djc[j] = 1
        else:
            djc[j] = 0
    
    
    dijr = pd.DataFrame()
    for j in range(0, ncols):
        for i in range(0, nrows):
            if ties=="average":
                if ct.iloc[i, j]==fmj[j]:
                    dijr.at[i, j] = 1 / colMaxFreq[j]
                else:
                    dijr.at[i, j] = 0
            else:
                if i==colMaxRowIndex[j]:
                    dijr.at[i, j] = 1
                else:
                    dijr.at[i, j] = 0
    
    dirr = [0]*nrows
    for i in range(0, nrows):
        if rs[i]==rm:
            if ties=="average":
                dirr[i] = 1 / rowTotalsMaxRowFreq
            elif rowTotalsMaxRowIndex==i:
                dirr[i] = 1
        else:
            dirr[i] = 0
            
    #ase calculations
    sfim = 0
    for i in range(0, nrows):
        sfim = sfim + fim[i]
    
    sfmj = 0
    for j in range(0, ncols):
        sfmj = sfmj + fmj[j]
    
    lambdyx = (sfim - cm) / (n - cm)
    lambdxy = (sfmj - rm) / (n - rm)
    lambd = (sfim + sfmj - cm - rm) / (2 * n - rm - cm)
    
    #aseyx0 and aseyx1
    ase0yx = 0
    ase1yx = 0
    for i in range(0, nrows):
        for j in range(0, ncols):
            ase0yx = ase0yx + ct.iloc[i, j] * (dijc.iloc[i, j] - djc[j])**2
            ase1yx = ase1yx + ct.iloc[i, j] * dijc.iloc[i, j] * djc[j]
    
    ase0yx = (ase0yx - (sfim - cm)**2 / n)**0.5 / (n - cm)
    ase1yx = (((n - sfim) * (sfim + cm - 2 * ase1yx)) / ((n - cm)**3))**0.5
    
    #asexy0 and asexy1
    ase0xy = 0
    ase1xy = 0
    for j in range(0, ncols):
        for i in range(0, nrows):
            ase0xy = ase0xy + ct.iloc[i, j] * (dijr.iloc[i, j] - dirr[i])**2
            ase1xy = ase1xy + ct.iloc[i, j] * dijr.iloc[i, j] * dirr[i]
    
    ase0xy = (ase0xy - (sfmj - rm)**2 / n)**0.5 / (n - rm)
    ase1xy = (((n - sfmj) * (sfmj + rm - 2 * ase1xy)) / ((n - rm)**3))**0.5
    
    #ase0 and ase1
    ase0 = 0
    ase1 = 0
    for i in range(0, nrows):
        for j in range(0, ncols):
            ase0 = ase0 + ct.iloc[i, j] * (dijc.iloc[i, j] + dijr.iloc[i, j] - djc[j] - dirr[i])**2
            ase1 = ase1 + ct.iloc[i, j] * (dijc.iloc[i, j] + dijr.iloc[i, j] - djc[j] - dirr[i] + lambd * (djc[j] + dirr[i]))**2
    ase0 = (ase0 - (sfim + sfmj - cm - rm)**2 / n)**0.5 / (2 * n - rm - cm)
    ase1 = (ase1 - 4 * n * lambd**2)**0.5 / (2 * n - rm - cm)
    
    Z = lambd / ase0
    Zyx = lambdyx / ase0yx
    Zxy = lambdxy / ase0xy
    
    p = 2 * (1 - NormalDist().cdf(abs(Z))) 
    pyx = 2 * (1 - NormalDist().cdf(abs(Zyx)))
    pxy = 2 * (1 - NormalDist().cdf(abs(Zxy)))
    
    #the results
    ver = ["symmetric", "field1", "field2"]
    ns = [n, n, n]
    ls = [lambd, lambdxy, lambdyx]
    ase0s = [ase0, ase0xy, ase0yx]
    ase1s = [ase1, ase1xy, ase1yx]
    zs = [Z, Zxy, Zyx]
    pvalues = [p, pxy, pyx]
    
    colNames = ["dependent", "value", "n", "ASE_0", "ASE_1", "statistic", "p-value"]
    results = pd.DataFrame(list(zip(ver, ls, ns, ase0s, ase1s, zs, pvalues)), columns=colNames)
    
    return results