import pandas as pd
from ..other.table_cross import tab_cross

def es_yule_y(field1, field2, categories1=None, categories2=None):
    '''
    Yule Y / Coefficient of Colligation
    ------------------
    
    A measure of association between two binary variables. This method is based on the Odds Ratio. It converts the sample data cross table to a similar one but having the diagonal values the same, while keeping the same odds ratio as the original.
    
    Parameters
    ----------
    field1 : pandas series
        data with categories for the rows
    field2 : pandas series
        data with categories for the columns
    categories1 : list or dictionary, optional
        the two categories to use from field1. If not set the first two found will be used
    categories2 : list or dictionary, optional
        the two categories to use from field2. If not set the first two found will be used

    Returns
    -------
    Yule Y
        
    Notes
    -----    
    The formula used (Yule, 1912, p. 592):
    $$Y = \\frac{\\sqrt{a\\times d} - \\sqrt{b\\times c}}{\\sqrt{a\\times d} + \\sqrt{b\\times c}}$$
    
    *Symbols used:*
    
    * \\(a\\) the count in the top-left cell of the cross table
    * \\(b\\) the count in the top-right cell of the cross table 
    * \\(c\\) the count in the bottom-left cell of the cross table 
    * \\(d\\) the count in the bottom-right cell of the cross table 
    
    Yule Y can be converted to Yule Q for which rules-of-thumb (*th_yule_q(q)*) can be used, or converted to an Odds Ratio using also with rules of thumb available via *th_odds_ratio(or)*
    
    See Also
    --------    
    stikpetP.other.convert_es.es_convert : to convert Yule Y to Yule Q or an Odds Ratio.
    
    References
    ----------
    Yule, G. U. (1912). On the methods of measuring association between two attributes. *Journal of the Royal Statistical Society, 75*(6), 579–652. https://doi.org/10.2307/2340126
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> pd.set_option('display.width',1000)
    >>> pd.set_option('display.max_columns', 1000)
    >>> file1 = "https://peterstatistics.com/Packages/ExampleData/GSS2012a.csv"
    >>> df1 = pd.read_csv(file1, sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> es_yule_y(df1['mar1'], df1['sex'], categories1=["WIDOWED", "DIVORCED"])
    0.13911057168098245
    
    '''
    # determine sample cross table
    tab = tab_cross(field1, field2, order1=categories1, order2=categories2, percent=None, totals="exclude")
    
    # cell values of sample cross table
    a = tab.iloc[0,0]
    b = tab.iloc[0,1]
    c = tab.iloc[1,0]
    d = tab.iloc[1,1]
    
    y = ((a*d)**0.5 - (b*c)**0.5) / ((a*d)**0.5 + (b*c)**0.5)
  
    return(y)