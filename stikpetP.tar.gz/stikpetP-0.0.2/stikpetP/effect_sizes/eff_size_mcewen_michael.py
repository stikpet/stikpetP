import pandas as pd
from ..other.table_cross import tab_cross

def es_mcewen_michael(field1, field2, categories1=None, categories2=None):
    '''
    McEwen-Michael Coefficient / Cole C3
    ------------------------------------
    
    A measure of association between two binary variables.
    
    A problem with measures that use the Forbes coefficient or Odds Ratio is that if only one cell is very large compared to the others, or 0, the association will be quite large (close to -1 or 1). Michael and McEwen attempted to overcome this by adding a correction.
    
    Note that Cole (1949, p. 415) refers to this as C3. Cole (1949, p. 417) critized this approach and proposed some alternatives himself.
    
    Parameters
    ----------
    field1 : pandas series
        data with categories for the rows
    field2 : pandas series
        data with categories for the columns
    categories1 : list or dictionary, optional
        the two categories to use from field1. If not set the first two found will be used
    categories2 : list or dictionary, optional
        the two categories to use from field2. If not set the first two found will be used

    Returns
    -------
    McEwen-Michael Coefficient
        
    Notes
    -----    
    The formula used (Michael, 1920, p. 57)):
    $$\\frac{a\\times d - b\\times c}{\\left(\\frac{a + d}{2}\\right)^2 + \\left(\\frac{b + c}{2}\\right)^2}$$
    
    *Symbols used:*
    
    * \\(a\\) the count in the top-left cell of the cross table
    * \\(b\\) the count in the top-right cell of the cross table 
    * \\(c\\) the count in the bottom-left cell of the cross table 
    * \\(d\\) the count in the bottom-right cell of the cross table 
    
    References
    ----------
    Cole, L. C. (1949). The measurement of interspecific associaton. *Ecology, 30*(4), 411–424. https://doi.org/10.2307/1932444
    
    Michael, E. L. (1920). Marine Ecology and the coefficient of association: A plea in behalf of quantitative biology. *Journal of Ecology, 8*(1), 54–59. https://doi.org/10.2307/2255213
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> pd.set_option('display.width',1000)
    >>> pd.set_option('display.max_columns', 1000)
    >>> file1 = "https://peterstatistics.com/Packages/ExampleData/GSS2012a.csv"
    >>> df1 = pd.read_csv(file1, sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> es_mcewen_michael(df1['mar1'], df1['sex'], categories1=["WIDOWED", "DIVORCED"])
    0.24332994923857867
    
    '''
    # determine sample cross table
    tab = tab_cross(field1, field2, order1=categories1, order2=categories2, percent=None, totals="exclude")
    
    # cell values of sample cross table
    a = tab.iloc[0,0]
    b = tab.iloc[0,1]
    c = tab.iloc[1,0]
    d = tab.iloc[1,1]
    
    mm = (a*d - b*c)/(((a+d)/2)**2 + ((b+c)/2)**2)
    
    return(mm)