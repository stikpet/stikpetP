import math
import pandas as pd
from ..other.table_cross import tab_cross

def es_bonett_price_r(field1, field2, categories1=None, categories2=None, version=2):
    '''
    Bonett and Price rho
    --------------------
    An approximation for the tetrachoric correlation coefficient.
    
    Parameters
    ----------
    field1 : pandas series
        data with categories for the rows
    field2 : pandas series
        data with categories for the columns
    categories1 : list or dictionary, optional
        the two categories to use from field1. If not set the first two found will be used
    categories2 : list or dictionary, optional
        the two categories to use from field2. If not set the first two found will be used
    version : {2, 1}, optional
        version of the rho to determine (see notes)
    
    Returns
    -------
    Bonett and Price r
    
    Notes
    -----
    An approximation for the tetrachoric correlation coefficient.
    
    Formula for version 1 is (Bonett & Price, 2005, p. 216):
    $$\\rho^* = \\cos\\left(\\frac{\\pi}{1+\\omega^c}\\right)$$
    
    With:
    $$\\omega = OR = \\frac{a\\times d}{b\\times c}$$
    $$c = \\frac{1-\\frac{\\left|R_1-C_1\\right|}{5\\times n} - \\left(\\frac{1}{2}-p_{min}\\right)^2}{2}$$
    $$p_{min} = \\frac{\\text{MIN}\\left(R_1, R_2, C_1, C_2\\right)}{n}$$
    
    Formula for version 2 is  (Bonett & Price, 2005, p. 216):
    $$\\hat{\\rho}^* = \\cos\\left(\\frac{\\pi}{1+\\hat{\\omega}^{\\hat{c}}}\\right)$$
    
    with:
    $$\\hat{\\omega} = \\frac{\\left(a+\\frac{1}{2}\\right)\\times \\left(d+\\frac{1}{2}\\right)}{\\left(b+\\frac{1}{2}\\right)\\times \\left(c+\\frac{1}{2}\\right)}$$
    $$\\hat{c} = \\frac{1-\\frac{\\left|R_1-C_1\\right|}{5\\times \\left(n+2\\right)} - \\left(\\frac{1}{2}-\\hat{p}_{min}\\right)^2}{2}$$
    $$\\hat{p}_{min} = \\frac{\\text{MIN}\\left(R_1, R_2, C_1, C_2\\right)+1}{n+2}$$
    
    *Symbols used:*
    
    * \(a\) the count in the top-left cell of the cross table
    * \(b\) the count in the top-right cell of the cross table 
    * \(c\) the count in the bottom-left cell of the cross table 
    * \(d\) the count in the bottom-right cell of the cross table
    * \(R_i\) the sum of counts in the i-th row
    * \(C_i\) the sum of counts in the i-th column
    
    References
    ----------
    Bonett, D. G., & Price, R. M. (2005). Inferential methods for the tetrachoric correlation coefficient. *Journal of Educational and Behavioral Statistics, 30*(2), 213–225. https://doi.org/10.3102/10769986030002213
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> file1 = "https://peterstatistics.com/Packages/ExampleData/GSS2012a.csv"
    >>> df1 = pd.read_csv(file1, sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> es_bonett_price_r(df1['mar1'], df1['sex'], categories1=["WIDOWED", "DIVORCED"])
    0.20192854636081123
    
    >>> es_bonett_price_r(df1['mar1'], df1['sex'], categories1=["WIDOWED", "DIVORCED"], version=1)
    0.20324426100323137
    
    '''
    
    # determine sample cross table
    tab = tab_cross(field1, field2, order1=categories1, order2=categories2, percent=None, totals="exclude")
    
    # cell values of sample cross table
    a = tab.iloc[0,0]
    b = tab.iloc[0,1]
    c = tab.iloc[1,0]
    d = tab.iloc[1,1]
    
    #The totals
    R1 = a + b
    R2 = c + d
    C1 = a + c
    C2 = b + d
    n = R1 + R2
    
    if(version==1):
        pMin = min(min(R1, R2),  min(C1, C2))/n
        cBP = (1 - abs(R1 - C1)/(5*n) - (0.5 - pMin)**2)/2
        omg = a*d/(b*c)
        r = math.cos(math.pi / (1 + omg**cBP))
    elif(version==2):
        pMin2 = (min(min(R1, R2),  min(C1, C2)) + 1)/(n+2)
        cBP2 = (1 - abs(R1 - C1)/(5*(n+2)) - (0.5 - pMin2)**2)/2
        omg2 = (a+0.5)*(d+0.5)/((b+0.5)*(c+0.5)) 
        r = math.cos(math.pi  / (1 + omg2**cBP2))
        
    return(r)