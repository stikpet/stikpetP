import pandas as pd
from ..other.table_cross import tab_cross

def es_alroy_f(field1, field2, categories1=None, categories2=None):
    '''
    Alroy's Forbes Adjustment
    -------------------------
    A measure of association between two binary variables.
    
    An adjustment to the Forbes coefficient.
    
    Parameters
    ----------
    field1 : pandas series
        data with categories for the rows
    field2 : pandas series
        data with categories for the columns
    categories1 : list or dictionary, optional
        the two categories to use from field1. If not set the first two found will be used
    categories2 : list or dictionary, optional
        the two categories to use from field2. If not set the first two found will be used

    Returns
    -------
    Alroy F
        
    Notes
    -----    
    The formula used (Alroy, 2015):
    $$F' = \\frac{a\\times\\left(n' + \\sqrt{n'}\\right)}{a\\times\\left(n' + \\sqrt{n'}\\right) + \\frac{3}{2}\\times b\\times c}$$
    
    With:
    $$n' = a + b + c$$
    
    *Symbols used:*
    
    * \\(a\\) the count in the top-left cell of the cross table
    * \\(b\\) the count in the top-right cell of the cross table 
    * \\(c\\) the count in the bottom-left cell of the cross table 
    
    References
    ----------
    Alroy, J. (2015). A new twist on a very old binary similarity coefficient. *Ecology, 96*(2), 575–586. https://doi.org/10.1890/14-0471.1
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> pd.set_option('display.width',1000)
    >>> pd.set_option('display.max_columns', 1000)
    >>> file1 = "https://peterstatistics.com/Packages/ExampleData/GSS2012a.csv"
    >>> df1 = pd.read_csv(file1, sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> es_alroy_f(df1['mar1'], df1['sex'], categories1=["WIDOWED", "DIVORCED"])
    0.7534515798088762
    
    '''
    # determine sample cross table
    tab = tab_cross(field1, field2, order1=categories1, order2=categories2, percent=None, totals="exclude")
    
    # cell values of sample cross table
    a = tab.iloc[0,0]
    b = tab.iloc[0,1]
    c = tab.iloc[1,0]
    d = tab.iloc[1,1]
    
    nAdj = a + b + c
    
    fadj = a*(nAdj + (nAdj)**0.5)/(a*(nAdj + (nAdj)**0.5) + 3/2*b*c)

    return(fadj)