from ..tests.test_fisher_owa import ts_fisher_owa

def es_omega_sq(nomField, scaleField, categories=None):

    #Anova table
    aTab = ts_fisher_owa(nomField, scaleField, categories)
    
    f = aTab.iloc[0, 4]
    dfb = aTab.iloc[0, 2]
    n = aTab.iloc[2, 2] + 1
    
    om2 = (f - 1) * dfb / (dfb * (f - 1) + n)
    
    return om2