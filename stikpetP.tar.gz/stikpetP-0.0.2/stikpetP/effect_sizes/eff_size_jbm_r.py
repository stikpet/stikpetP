import pandas as pd
from scipy.special import comb

def es_jbm_r(data, success=None):
    
    #Remove rows with missing values and reset index
    data = data.dropna()    
    data = data.reset_index(drop=True)
    
    n = len(data)
    k = len(data.columns)
    
    if success is None:
        suc = data.iloc[0,0]
    else:
        suc = success
    
    isSuc = data == suc
    cj = isSuc.sum()
    ri = isSuc.sum(axis=1)
    ns = cj.sum()
    
    pi = ri/k
    
    delta = 1/(k*comb(n, 2)) * (cj*(n - cj)).sum()
    mu = 2/(n*(n - 1)) * (pi.sum()*(n - pi.sum()) - (pi*(1 - pi)).sum())
    r = 1 - delta/mu
    
    return r