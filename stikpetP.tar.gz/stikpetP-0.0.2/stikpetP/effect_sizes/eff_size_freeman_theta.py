import pandas as pd
from ..other.table_cross import tab_cross

def es_freeman_theta(catField, ordField, categories=None, levels=None, useRanks=False):
    #create the cross table    
    ct = tab_cross(catField, ordField, order1=categories, order2=levels, totals="include")
    
    #basic counts
    k = ct.shape[0]-1
    nlvl = ct.shape[1]-1
    
    d = 0
    t = 0
    for x in range(0, k - 1):
        for y in range(x + 1, k):
            fb = 0
            for i in range(1, nlvl):
                fs = 0
                for j in range(0, i):
                    fs = fs + ct.iloc[y, j] 
                fb = fb + ct.iloc[x, i] * fs
            
            fa = 0
            for i in range(0, nlvl - 1):
                fs = 0
                for j in range(i + 1, nlvl):
                    fs = fs + ct.iloc[y, j]
                fa = fa + ct.iloc[x, i] * fs
            
            d = d + abs(fa - fb)
            t = t + ct.iloc[x, nlvl] * ct.iloc[y, nlvl]

    theta = d / t
    
    return theta