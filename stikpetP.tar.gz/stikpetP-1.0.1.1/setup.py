from setuptools import setup, find_packages

setup(
    name='stikpetP',
    version='1.0.1.1',
    author='Peter Stikker',
    description='A package for statistical calculations',
    packages=find_packages(),
    install_requires=[
        'pandas',
        'scipy'
    ],
)
