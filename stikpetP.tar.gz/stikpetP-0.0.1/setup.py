from setuptools import setup, find_packages

setup(
    name='stikpetP',
    version='0.0.1',
    author='Peter Stikker',
    description='A package for statistical calculations',
    packages=find_packages(),
    install_requires=[
        'pandas',
        'scipy'
    ],
)
