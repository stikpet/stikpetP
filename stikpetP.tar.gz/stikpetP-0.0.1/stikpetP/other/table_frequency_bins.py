import pandas as pd
from .table_nbins import tab_nbins

def tab_frequency_bins(data, nbins="sturges", bins=None, incl_lower=True, adjust=1):
    '''
    Binned Frequency Table 
    ----------------------
    
    Bins data and creates a frequency table with frequency density.
    
    Parameters
    ----------
    data : list or pandas series
        the data
    nbins : int or string, optional
        either the number of bins to create, or a specific method from the *tab_nbins()* function. Default is "sturges"
    bins : list of tuples, optional
    incl_lower : boolean, optional
        to include the lower bound, otherwise the upper bound is included. Default is True
    adjust : float, optional
        value to add  or subtract to guarantee all scores will fit in a bin
        
    Returns
    -------
    tab : pandas dataframe with the following fields
    
    * *lower bound* 
    * *upper bound*
    * *frequency* 
    * *frequency density*
    
    See Also
    --------
    stikpetP.other.table_nbins.tab_nbins : to determine the number of bins
    
    Author
    ------
    Made by P. Stikker
    
    Please visit: https://PeterStatistics.com
    
    YouTube channel: https://www.youtube.com/stikpet
    
    '''
    
    if type(data) is list:
        data = pd.Series(data)
    
    #remove missing values
    data = data.dropna()
    
    if bins is None:
        
        if isinstance(nbins, int):
            k = nbins
        else:
            k = tab_nbins(data, method="sturges")

        #determine minimum and maximum
        mx = max(data)
        mn = min(data)

        #increase maximimum if to include the lower bound
        if incl_lower:
            mx = mx + adjust
        #decrease minimum if to include the upper bound
        else:
            mn = min(data) - adjust

        #determine range and width
        r = mx - mn
        h = r/k

        #create the bins
    
        bins=[]
        i = 0
        while i < k:
            lb = mn + i*h
            ub = lb + h
            bins.append((lb, ub))
            i = i+1    
    
    tab = pd.DataFrame(columns = ["lower bound", "upper bound", "frequency", "frequency density"])
    cf = 0
    for i in bins:
        lb = i[0]
        ub = i[1]
        if incl_lower:
            cfn = sum(data <=i[1])
        else:
            cfn = sum(data < i[1])
        f =  cfn - cf
        cf = cfn
        fd = f / (ub - lb)
        tab.loc[len(tab)] = [lb, ub, f, fd]
    
    return tab