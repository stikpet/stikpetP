import pandas as pd
import numpy as np

def me_consensus(data, levels=None):
    '''
    Consensus
    ---------
    
    The Consensus is a measure of agreement or dispersion for ordinal data. If there is no agreement the value is 0, and with full agreement 1.
    
    Parameters
    ----------
    data : list or pandas series 
    levels : dictionary, optional
        with coding to use
    
    Returns
    -------
    Cns : the consensus score
    
    Notes
    -----
    The formula used (Tastle et al., 2005, p. 98):
    $$\\text{Cns}\\left(X\\right) = 1 + \\sum_{i=1}^k p_i \\log_2\\left(1 - \\frac{\\left|i - \\mu_X\\right|}{d_X}\\right)$$
    
    With:
    $$\\mu_X = \\frac{\\sum_{i=1}^k i\\times F_i}{n}$$
    $$d_X = k - 1$$
    $$p_i = \\frac{F_i}{n}$$
    
    *Symbols used:*
    
    * $F_i$ the frequency (count) of the i-th category (after they have been sorted)
    * $n$ the sample size
    * $k$ the number of categories.
    
    References 
    ----------
    Tastle, W. J., & Wierman, M. J. (2007). Consensus and dissention: A measure of ordinal dispersion. *International Journal of Approximate Reasoning, 45*(3), 531–545. doi:10.1016/j.ijar.2006.06.024
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076

    Examples
    --------
    Example 1: Text Pandas Series
    >>> import pandas as pd
    >>> student_df = pd.read_csv('https://peterstatistics.com/Packages/ExampleData/StudentStatistics.csv', sep=';', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> ex1 = student_df['Teach_Motivate']
    >>> order = {"Fully Disagree":1, "Disagree":2, "Neither disagree nor agree":3, "Agree":4, "Fully agree":5}
    >>> me_consensus(ex1, levels=order)
    0.42896860013343563
    
    Example 2: Numeric data
    >>> ex2 = [1, 1, 1, 2, 2, 2, 3, 3, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5]
    >>> me_consensus(ex2)
    0.3340394927779964
    
    Example 3: Text data
    >>> ex3 = ["a", "b", "f", "d", "e", "c"]
    >>> order = {"a":1, "b":2, "c":3, "d":4, "e":5, "f":6}
    >>> me_consensus(ex3, levels=order)
    0.4444745779083972
    
    '''
    
    if type(data) is list:
        data = pd.Series(data)
        
    data = data.dropna()
    if levels is not None:
        dataN = data.replace(levels).infer_objects(copy=False)
        dataN = pd.to_numeric(dataN)
    else:
        dataN = pd.to_numeric(data)
    
    dataN = dataN.sort_values()
    
    F = list(dataN.value_counts().sort_index())
    k = len(F)
    n = sum(F)
    
    P = [i/n for i in F]

    mu_x = sum([i*F[i-1] for i in range(1, k + 1)]) / n
    d_x = k - 1
    
    Cns = 1 + sum([P[i]*np.log2(1 - abs(i + 1 - mu_x)/d_x)  for i in range(k)])
    
    return Cns