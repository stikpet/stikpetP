import pandas as pd
import matplotlib.pyplot as plt
from numpy import diff, allclose
from ..other.table_frequency_bins import tab_frequency_bins

def vi_histogram_b2b(catField, scaleField, categories=None, bins=None, show='count', density='auto', xlbl=None, rotate=True, colors=['orange', 'blue'], figsize=(9, 6), **kwargs):
    '''
    Back-to-Back Histogram (Pyramid chart)
    ---------------------------------------

    This function creates a simple back-to-back histogram. This is sometimes also referred to as a Pyramid chart or a Dual-Sided histogram (Jelen, 2005). 

    The back-to-back histogram together with back-to-back stem-and-leaf and split box-plots are described as effective ways to compare two distributions by Lane and Sándor (2009).

    The function is shown in this [YouTube video](https://youtu.be/PQjmzf4-8I0) and the visualisation is also described at [PeterStatistics.com](https://peterstatistics.com/Terms/Visualisations/histogram.html)

    Parameters
    ----------
    catField : list or dataframe 
        the categories
    scaleField : list or dataframe 
        the scores
    categories : list or dictionary, optional
        the two categories to use from bin_field. If not set the first two found will be used
    bins : list or dictionary, optional
        list of tuples to use as bins, or dictionary with parameters to pass to tab_frequency_bins().
    show : {'count', 'relative'}, optional
        show either counts or relative count on vertical scale
    density : {'auto', False, True}, optional
        show (relative) frequency or use (relative) frequency density.
    rotate : bool, optional
        rotate the bars so they appear horizontal. Default is True
    xlbl : string, optional 
        label for the horizontal axis
    colors : list, optional
        list with two colors, one for each category to use
    figsize : tuple, optional
        tuple for the figure size. Default is (9, 6)
    kwargs : other parameters for use in pyplot hist function
        
    Returns
    -------
    back-to-back histogram

    Alternatives
    ------------
    To display the results of a binary and scale variable, alternative visualisations include: [overlaid histogram](../visualisations/vis_histogram_overlay.html), [back-to-back stem-and-leaf display](../visualisations/vis_stem_and_leaf_b2b.html), [split histogram](../visualisations/vis_histogram_split.html), [split box-plot](../visualisations/vis_boxplot_split.html), [butterfly chart/pyramid chart](../visualisations/vis_butterfly_bin.html)

    Next
    ----
    After visualizing the data, you might want to run a test: [Student t](../tests/test_student_t_is.html), [Welch t](../tests/test_welch_t_is.html), [Trimmed means](../tests/test_trimmed_mean_is.html), [Yuen-Welch](../tests/test_trimmed_mean_is.html), [Z test](../tests/test_z_is.html)

    References
    ----------
    Jelen, B. (2005, December 24). Dual Sided Histogram in Excel. MrExcel. https://www.mrexcel.com/tech-tv/dual-sided-histogram-in-excel/
    
    Lane, D. M., & Sándor, A. (2009). Designing better graphs by including distributional information and integrating words, numbers, and images. *Psychological Methods, 14*(3), 239–257. doi:10.1037/a0016620
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076

    Examples
    --------
    >>> import pandas as pd
    >>> file1 = "https://peterstatistics.com/Packages/ExampleData/StudentStatistics.csv"
    >>> df = pd.read_csv(file1, sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> vi_histogram_b2b(df['Gen_Gender'], df['Over_Grade'], edgecolor='blue')
    '''

    #convert to pandas series if needed
    if type(catField) is list:
        catField = pd.Series(catField)
    
    if type(scaleField) is list:
        scaleField = pd.Series(scaleField)
    
    #combine as one dataframe
    df = pd.concat([catField, scaleField], axis=1)
    df = df.dropna()
    
    #the two categories
    if categories is not None:
        cat1 = categories[0]
        cat2 = categories[1]
    else:
        cat1 = df.iloc[:,0].value_counts().index[0]
        cat2 = df.iloc[:,0].value_counts().index[1]
    
    #seperate the scores for each category
    X = list(df.iloc[:,1][df.iloc[:,0] == cat1])
    Y = list(df.iloc[:,1][df.iloc[:,0] == cat2])
    
    #make sure they are floats
    X = [float(x) for x in X]
    Y = [float(y) for y in Y]

    if bins is None:
       bins={} 
    if isinstance(bins, dict):
        scores_table = tab_frequency_bins(X + Y, **bins)
        bins = [(scores_table.iloc[i,0], scores_table.iloc[i,1]) for i in range(len(scores_table))]
        
    if density=='auto':
        bin_widths = diff(bins)

        if allclose(bin_widths, bin_widths[0]):
            density=False
        else:
            density=True

    # create stage for the plots
    if rotate:
        fig, axes = plt.subplots(ncols=2, sharey=True, figsize=figsize)
    else:
        fig, axes = plt.subplots(nrows=2, sharex=True, figsize=figsize)

    # set the orientation
    if rotate:
        orientation = 'horizontal'
    else:
        orientation = 'vertical'
        
    # the first category histogram
    n_X, bins, patchesX = axes[0].hist(X, color=colors[0], orientation=orientation, bins=bins, density=density, **kwargs)
    
    # the second category histogram
    n_Y, bins, patchesY = axes[1].hist(Y, color=colors[1], orientation=orientation, bins=bins, density=density, **kwargs)
    
    # the label for the score axis
    if xlbl is None:
        xlbl = df.iloc[:,1].name

    if rotate:
        axes[0].set(title=cat1, ylabel=xlbl)   
        axes[1].set(title=cat2)
        axes[0].invert_xaxis()
    else:
        axes[1].invert_yaxis()
        
    # no gap between the two plots
    plt.subplots_adjust(wspace=0, hspace=0)

    if (show=="count" and density==False) or (show=="relative" and density==True):
        
        if (show=="count" and density==False):
            # regular count
            ylbl = 'frequency'
        
        elif (show=="relative" and density==True):
            # regular count
            ylbl = 'probability density'
            
    else:
        N_X = len(X)
        N_Y = len(Y)
        
        if (show=="count" and density==True):
            # regular frequency density
            ylbl = 'frequency density'
            # Convert probability density to frequency density
            n_X *= N_X
            n_Y *= N_Y

        elif (show=="relative" and density==False):
            # regular count
            ylbl = 'percent'
            # Convert counts to percentages
            n_X /= N_X
            n_X *= 100
            n_Y /= N_Y
            n_Y *= 100
            
        for rectX, sizeX in zip(patchesX, n_X):
            if rotate:
                rectX.set_width(sizeX)
            else:
                rectX.set_height(sizeX)
        
        for rectY, sizeY in zip(patchesY, n_Y):
            if rotate:
                rectY.set_width(sizeY)
            else:
                rectY.set_height(sizeY)
        
    # set horizontal axis for each side equal
    xLim = max(list(n_X) + list(n_Y))
    if not(density):
        xLim = xLim + 0.5
        
    if rotate:
        axes[0].set_xlim([xLim,0])
        axes[1].set_xlim([0,xLim])
        plt.xlabel(ylbl)
        axes[0].set_ylabel(xlbl)
    else:
        axes[1].set_ylim([xLim,0])
        axes[0].set_ylim([0,xLim])
        plt.xlabel(xlbl)
        axes[0].set_ylabel(cat1 + ' - ' + ylbl)
        axes[1].set_ylabel(cat2 + ' - ' + ylbl)
        
    plt.show()
    
    return