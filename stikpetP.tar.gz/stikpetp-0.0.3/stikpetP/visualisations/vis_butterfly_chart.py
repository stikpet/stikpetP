import matplotlib.pyplot as plt
import pandas as pd
from ..other.table_cross import tab_cross

def vi_butterfly_chart(field, bin_field, field_categories=None, bin_categories=None, variation='butterfly', 
                       show='count', rotate=True, xlbl=None, colors=['orange', 'blue'], figsize=(9, 6), show_grid=False):
    '''
    Butterfly Chart / Tornado Chart / Pyramid Chart
    -----------------------------------------------
    A special case of diverging bar charts when only comparing two categories. 
    
    Depending on the ordering of the results different names exist. I've chosen to use 'butterfly' if no ordering is done, 'pyramid' if they are ordered from small to large, and 'tornado' when going from large to small.

    This function is shown in this [YouTube video](https://youtu.be/f_5dTS5gb-4) and the diagram is also discussed at [PeterStatistics.com](https://peterstatistics.com/Terms/Visualisations/PyramidChart.html)
    
    Parameters
    ----------
    field : pandas series
        data with categories for the rows
    bin_field : pandas series
        data to split the data on
    field_categories : list or dictionary, optional
        the categories to use from field. 
    bin_categories : list or dictionary, optional
        the two categories to use from bin_field.
    variation : {"butterfly", "tornado", "pyramid"}, optional
        order of the bars
    show : {'count', 'bin-percent', 'field-percent', 'overall-percent'}, optional
        show either counts or percentage
    rotate : bool, optional
        rotate the bars so they appear horizontal. Default is True
    xlbl : string, optional 
        label for the field axis, if not set the name of the field is used.
    colors : list, optional
        list with two colors, one for each category to use
    figsize : tuple, optional
        tuple for the figure size. Default is (9, 6)
    show_grid : bool, optional
        show a grid on the chart. Default is False
        
    Returns
    -------
    plot
    
    Notes
    -----
    The term *butterfly chart* can for example be found in Hwang and Yoon (2021, p. 25). 
    
    The term *tornado diagrom* can be found in the guide from the Project Management Institute (2013, p. 338). The term *funnel chart* is also sometimes used (for example Jamsa (2020, p. 135)), but this is also a term sometimes used for a more analytical scatterplot used for some specific analysis.
    
    The term *pyramid chart* can for example be found in Schwabish (2021, p. 185). It is very often used for comparing age distributions.
    
    References
    ----------
    Hwang, J., & Yoon, Y. (2021). Data analytics and visualization in quality analysis using Tableau. CRC Press.
    
    Jamsa, K. (2020). Introduction to data mining and analytics: With machine learning in R and Python. Jones & Bartlett Learning.
    
    Project Management Institute (Ed.). (2013). A guide to the project management body of knowledge (5th ed.). Project Management Institute, Inc.
    
    Schwabish, J. (2021). Better data visualizations: A guide for scholars, researchers, and wonks. Columbia University Press.
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> file1 = "https://peterstatistics.com/Packages/ExampleData/GSS2012a.csv"
    >>> df1 = pd.read_csv(file1, sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> vi_butterfly_chart(df1['mar1'], df1['sex'])
    
    >>> vi_butterfly_chart(df1['mar1'], df1['sex'], variation="pyramid")
    
    >>> vi_butterfly_chart(df1['mar1'], df1['sex'], variation="tornado")
    
    '''
    if show=='count':
        percent = None
    elif show=='bin-percent':
        percent='column'
    elif show=='field-percent':
        percent='row'
    elif show=='overall-percent':
        percent='all'

    ct = tab_cross(field, bin_field, order1=field_categories, order2=bin_categories, percent=percent, totals="exclude")
    k = len(ct.index)
        
    if variation=='tornado':
        ct = tab_cross(field, bin_field, order1=field_categories, order2=bin_categories, percent=percent, totals="include")
        ct = ct.sort_values(by=['Total'])
        ct = ct.iloc[0:k, 0:2]
    
    if variation=='pyramid':
        ct = tab_cross(field, bin_field, order1=field_categories, order2=bin_categories, percent=percent, totals="include")
        ct = ct.sort_values(by=['Total'], ascending=False)
        ct = ct.iloc[1:1+k, 0:2]
        
    y = ct.index       
    scores1 = ct.iloc[:,0]
    scores2 = ct.iloc[:,1]
    maxCount = max(ct.max(axis=1))
    xLim = maxCount + 0.5

    if show=='count':
        ylbl = 'frequency'
    elif show=='bin-percent':
        ylbl = 'percent of ' + ct.columns.name
    elif show=='field-percent':
        ylbl = 'percent of ' + ct.index.name
    elif show=='overall-percent':
        ylbl = 'percent of overall'
        
    if xlbl is None:
        xlbl = ct.index.name
        
    if rotate:
        fig, axes = plt.subplots(ncols=2, sharey=True, figsize=figsize)

        axes[0].barh(y, scores1, align='center', color=colors[0])
        axes[0].set(title=ct.columns[0])
        axes[1].barh(y, scores2, align='center', color=colors[1])
        axes[1].set(title=ct.columns[1])
        axes[0].invert_xaxis()
        axes[0].set_xlim([xLim,0])
        axes[1].set_xlim([0,xLim])
        plt.subplots_adjust(wspace=0, hspace=0)
        axes[0].set_ylabel(xlbl)    
        
    else:
        fig, axes = plt.subplots(nrows=2, sharex=True, figsize=figsize)

        axes[0].bar(y, scores1, align='center', color=colors[0])
        axes[1].bar(y, scores2, align='center', color=colors[1])
        axes[0].invert_yaxis()
        axes[0].set_ylim([0, xLim])
        axes[1].set_ylim([xLim,0])
        axes[0].set_ylabel(ct.columns[0] + ' - '+ ylbl) 
        axes[1].set_ylabel(ct.columns[1] + ' - '+ ylbl) 

    if show_grid:
        axes[0].grid()
        axes[1].grid()
        
    plt.subplots_adjust(wspace=0, hspace=0)

    plt.xlabel(xlbl)
    
    plt.show()