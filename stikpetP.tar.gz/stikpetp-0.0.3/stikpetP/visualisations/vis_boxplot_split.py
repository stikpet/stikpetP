import pandas as pd
import seaborn as sns

def vi_boxplot_split(catField, scaleField, categories=None, **kwargs):
    '''
    Split Box-Plot
    ---------------
    Based on a categorical field the scores for each category are plotted in a separate boxplot and each of them is placed underneath each other.
    
    See **vi_boxplot_single()** for more details on box-plots.
    
    Parameters
    ----------
    catField : list or dataframe 
        the categories
    scaleField : list or dataframe
        the scores
    categories : list, optional
        categories to use
    kwargs : other parameters for use in seaborn's boxplot function
    
    Returns
    -------
    The split box-plot

    Alternatives
    ------------
    In case of a binary-scale situation: [overlaid histogram](../visualisations/vis_histogram_overlay.html), [back-to-back histogram](../visualisations/vis_histogram_b2b.html), [back-to-back stem-and-leaf display](../visualisations/vis_stem_and_leaf_b2b.html), [butterfly chart/pyramid chart](../visualisations/vis_butterfly_bin.html)

    In case of a nominal-scale situation: [split histogram](../visualisations/vis_histogram_split.html)

    Next
    ----
    After visualizing the data, you might want to run a test. In case of a binary-scale situation: [Student t](../tests/test_student_t_is.html), [Welch t](../tests/test_welch_t_is.html), [Trimmed means](../tests/test_trimmed_mean_is.html), [Yuen-Welch](../tests/test_trimmed_mean_is.html), [Z test](../tests/test_z_is.html)
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    if type(catField) is list:
        catField = pd.Series(catField)        
        catName = ""
    else:
        catName = catField.name        
        
    if type(scaleField) is list:
        scaleField = pd.Series(scaleField)
        scaleName = ""        
    else:
        scaleName = scaleField.name
    
    #combine as one dataframe
    df = pd.concat([catField, scaleField], axis=1)
    df = df.dropna()    
    df.columns=["category", "score"]
    if categories is not None:
        df = df[df["category"].isin(categories)]

    myClusters = df.iloc[:,0]
    myScale = df.iloc[:,1]
    sns.boxplot(x="score", y="category", data = df, orient="h", **kwargs).set(xlabel=scaleName, ylabel=catName)
