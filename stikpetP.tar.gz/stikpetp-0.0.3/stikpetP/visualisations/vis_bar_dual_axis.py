import pandas as pd
import matplotlib.pyplot as plt
from ..other.table_frequency import tab_frequency

def vi_bar_dual_axis(data, varname=None, order=None):
    '''
    Dual-Axis Bar Chart
    -------------------
    
    A dual axis bar-chart is a bar-chart with two vertical axis. In this function it will show both the count and cumulative proportion. 
    
    This chart could be used with a single ordinal variable.

    This function is shown in this [YouTube video]() and the visualisation is also described at [PeterStatistics.com](https://peterstatistics.com/Terms/Visualisations/bar-chart.html)
    
    Parameters
    ----------
    data : list or pandas series 
        the data
    varname : string, optional 
        label for the horizontal axis. Default is series name
    order : list or dictionary, optional 
        the order of the categories
    
    Returns
    -------
    plt : pyplot with the chart
    
    Notes
    -----
    Uses pyplot **bar()** for the chart

    See Also
    --------
    Before the visualisation you might first want to get an impression using a frequency table:
    * [tab_frequency](../other/table_frequency.html#tab_frequency)

    After visualisation you might want some descriptive measures:
    * [me_consensus](../measures/meas_consensus.html#me_consensus) for the Consensus
    * [me_hodges_lehmann_os](../measures/meas_hodges_lehmann_os.html#me_hodges_lehmann_os) for the Hodges-Lehmann Estimate (One-Sample)
    * [me_median](../measures/meas_median.html#me_median) for the Median
    * [me_quantiles](../measures/meas_quantiles.html#me_quantiles) for Quantiles
    * [me_quartiles](../measures/meas_quartiles.html#me_quantiles) for Quartiles / Hinges
    * [me_quartile_range](../measures/meas_quartile_range.html#me_quartile_range) for Interquartile Range, Semi-Interquartile Range and Mid-Quartile Range
    
    or perform a test:
    * [ts_sign_os](../tests/test_sign_os.html#ts_sign_os) for One-Sample Sign Test
    * [ts_trinomial_os](../tests/test_trinomial_os.html#ts_trinomial_os) for One-Sample Trinomial Test
    * [ts_wilcoxon_os](../tests/test_wilcoxon_os.html#ts_wilcoxon_os) for Wilcoxon Signed Rank Test (One-Sample)
    
    Alternatives for this visualisation could be:
    * [vi_bar_stacked_single](../visualisations/vis_bar_stacked_single.html#vi_bar_stacked_single) for Single Stacked Bar-Chart    
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076

    Examples
    --------
    >>> df1 = pd.read_csv('https://peterstatistics.com/Packages/ExampleData/GSS2012a.csv', sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> ex1 = df1['mar1']
    >>> vi_bar_dual_axis(ex1);
    >>> vi_bar_dual_axis(ex1, varname="marital status");

    '''
    
    if type(data) is list:
        field = data.name
    else:
        field = ""
    
    myFreqTable = tab_frequency(data=data, order=order)
    
    if varname is None:
        xlab = field
    else:
        xlab = varname

    fig,ax=plt.subplots()
    ax.set_xlabel(xlab)
    ax.bar(myFreqTable.index, 'Frequency', data = myFreqTable)
    ax.set_ylabel("frequency")
    ax.set_ylim(ymin=0)

    ax2=ax.twinx()
    ax2.plot(myFreqTable.index, 'Cumulative Percent', data = myFreqTable, marker='o', color='red')
    ax2.set_ylabel("cumulative percent")
    ax2.set_ylim(ymin=0)
    
    plt.show()
    
    return