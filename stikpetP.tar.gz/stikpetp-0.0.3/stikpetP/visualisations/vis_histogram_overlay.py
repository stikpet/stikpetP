import pandas as pd
import matplotlib.pyplot as plt
from numpy import diff, allclose

def vi_histogram_overlay(catField, scaleField, categories=None, bins=None, 
                         show='count', density='auto', title=None, xlbl=None, 
                         colors=['blue', 'orange'], **kwargs):
    '''
    Overlaid Histogram
    ------------------
    This function will create an overlaid histogram of the scores from two categories (independent samples).

    The visualisation is also described at [PeterStatistics.com](https://peterstatistics.com/Terms/Visualisations/histogram.html)

    Parameters
    ----------
    catField : list or dataframe 
        the categories
    scaleField : list or dataframe 
        the scores
    categories : list or dictionary, optional
        the two categories to use from bin_field. If not set the first two found will be used
    bins : list or dictionary, optional
        list of tuples to use as bins, or dictionary with parameters to pass to tab_frequency_bins().
    show : {'count', 'relative'}, optional
        show either counts or relative count on vertical scale
    density : {'auto', False, True}, optional
        show (relative) frequency or use (relative) frequency density.
    rotate : bool, optional
        rotate the bars so they appear horizontal. Default is True
    title : string, optional 
        label for the chart
    xlbl : string, optional 
        label for the horizontal axis
    colors : list, optional
        list with two colors, one for each category to use
    figsize : tuple, optional
        tuple for the figure size. Default is (9, 6)
    kwargs : other parameters for use in pyplot hist function
        
    Returns
    -------
    overlaid histogram

    Alternatives
    ------------
    To display the results of a binary and scale variable, alternative visualisations include: [overlaid histogram](../visualisations/vis_histogram_overlay.html), [back-to-back histogram](../visualisations/vis_histogram_b2b.html), [back-to-back stem-and-leaf display](../visualisations/vis_stem_and_leaf_b2b.html), [split histogram](../visualisations/vis_histogram_split.html), [split box-plot](../visualisations/vis_boxplot_split.html), [butterfly chart/pyramid chart](../visualisations/vis_butterfly_bin.html)

    Next
    ----
    After visualizing the data, you might want to run a test: [Student t](../tests/test_student_t_is.html), [Welch t](../tests/test_welch_t_is.html), [Trimmed means](../tests/test_trimmed_mean_is.html), [Yuen-Welch](../tests/test_trimmed_mean_is.html), [Z test](../tests/test_z_is.html)
        
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076

    Examples
    --------
    >>> import pandas as pd
    >>> file1 = "https://peterstatistics.com/Packages/ExampleData/StudentStatistics.csv"
    >>> df = pd.read_csv(file1, sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> vi_histogram_overlay(df['Gen_Gender'], df['Over_Grade'], edgecolor='blue')
    
    '''
    #convert to pandas series if needed
    if type(catField) is list:
        catField = pd.Series(catField)
    
    if type(scaleField) is list:
        scaleField = pd.Series(scaleField)
    
    #combine as one dataframe
    df = pd.concat([catField, scaleField], axis=1)
    df = df.dropna()
    
    #the two categories
    if categories is not None:
        cat1 = categories[0]
        cat2 = categories[1]
    else:
        cat1 = df.iloc[:,0].value_counts().index[0]
        cat2 = df.iloc[:,0].value_counts().index[1]
    
    #seperate the scores for each category
    X = list(df.iloc[:,1][df.iloc[:,0] == cat1])
    Y = list(df.iloc[:,1][df.iloc[:,0] == cat2])
    
    #make sure they are floats
    X = [float(x) for x in X]
    Y = [float(y) for y in Y]

    if bins is None:
        scores_table = tab_frequency_bins(X + Y)
        bins = list(scores_table['lower bound'])
        bins.append(max(scores_table['upper bound']))
    if isinstance(bins, dict):
        scores_table = tab_frequency_bins(X + Y, **bins)
        bins = list(scores_table['lower bound'])
        bins.append(max(scores_table['upper bound']))
        
    if density=='auto':
        bin_widths = diff(bins)

        if allclose(bin_widths, bin_widths[0]):
            density=False
        else:
            density=True

    n_X, bins, patchesX = plt.hist(X, density=density, color=colors[0], alpha=0.5, bins=bins, label=cat1, **kwargs)
    n_Y, bins, patchesY = plt.hist(Y, density=density, color=colors[1], alpha=0.5, bins=bins, label=cat2, **kwargs)

    if (show=="count" and density==False) or (show=="relative" and density==True):
        
        if (show=="count" and density==False):
            # regular count
            ylbl = 'frequency'
        
        elif (show=="relative" and density==True):
            # regular count
            ylbl = 'probability density'
            
    else:
        N_X = len(X)
        N_Y = len(Y)
        
        if (show=="count" and density==True):
            # regular frequency density
            ylbl = 'frequency density'
            # Convert probability density to frequency density
            n_X *= N_X
            n_Y *= N_Y

        elif (show=="relative" and density==False):
            # regular count
            ylbl = 'percent'
            # Convert counts to percentages
            n_X /= N_X
            n_X *= 100
            n_Y /= N_Y
            n_Y *= 100
            
        for rectX, sizeX in zip(patchesX, n_X):
            rectX.set_height(sizeX)
        
        for rectY, sizeY in zip(patchesY, n_Y):
            rectY.set_height(sizeY)
        
    # set horizontal axis for each side equal
    xLim = max(list(n_X) + list(n_Y))
    if not(density):
        xLim = xLim + 0.5
        
    plt.ylim(0, xLim)
    plt.legend(loc='upper right')
    if xlbl is None:
        xlbl = df.iloc[:,1].name
    plt.xlabel(xlbl)
    plt.ylabel(ylbl)
    plt.title(title)
    plt.show()