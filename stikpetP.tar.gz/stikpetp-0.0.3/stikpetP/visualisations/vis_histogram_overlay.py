import pandas as pd
import matplotlib.pyplot as plt

def vi_histogram_overlay(catField, scaleField, categories=None, bins=None, show='count', **kwargs):
    '''
    Overlaid Histogram
    ------------------
    This function will create an overlaid histogram of the scores from two categories (independent samples).

    The visualisation is also described at [PeterStatistics.com](https://peterstatistics.com/Terms/Visualisations/histogram.html)

    Parameters
    ----------
    catField : list or dataframe 
        the categories
    scaleField : list or dataframe 
        the scores
    categories : list or dictionary, optional
        the two categories to use from bin_field. If not set the first two found will be used
    bins : list, optional
        upper bounds of bins to be used, or any of the pre-set options from pyplot.hist() bins.
    show : {'count', 'percent'}, optional
        what to show on vertical axis
    kwargs : other parameters from pandas plot()
        
    Returns
    -------
    overlaid histogram

    Alternatives
    ------------
    To display the results of a binary and scale variable, alternative visualisations include: [overlaid histogram](../visualisations/vis_histogram_overlay.html), [back-to-back histogram](../visualisations/vis_histogram_b2b.html), [back-to-back stem-and-leaf display](../visualisations/vis_stem_and_leaf_b2b.html), [split histogram](../visualisations/vis_histogram_split.html), [split box-plot](../visualisations/vis_boxplot_split.html), [butterfly chart/pyramid chart](../visualisations/vis_butterfly_bin.html)

    Next
    ----
    After visualizing the data, you might want to run a test: [Student t](../tests/test_student_t_is.html), [Welch t](../tests/test_welch_t_is.html), [Trimmed means](../tests/test_trimmed_mean_is.html), [Yuen-Welch](../tests/test_trimmed_mean_is.html), [Z test](../tests/test_z_is.html)
        
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076

    Examples
    --------
    >>> import pandas as pd
    >>> file1 = "https://peterstatistics.com/Packages/ExampleData/StudentStatistics.csv"
    >>> df = pd.read_csv(file1, sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> vi_histogram_overlay(df['Gen_Gender'], df['Over_Grade'], edgecolor='blue')
    
    '''
    #convert to pandas series if needed
    if type(catField) is list:
        catField = pd.Series(catField)
    
    if type(scaleField) is list:
        scaleField = pd.Series(scaleField)
    
    #combine as one dataframe
    df = pd.concat([catField, scaleField], axis=1)
    df = df.dropna()
    
    #the two categories
    if categories is not None:
        cat1 = categories[0]
        cat2 = categories[1]
    else:
        cat1 = df.iloc[:,0].value_counts().index[0]
        cat2 = df.iloc[:,0].value_counts().index[1]

    var_name = df.iloc[:,1].name
    
    #seperate the scores for each category
    X = list(df.iloc[:,1][df.iloc[:,0] == cat1])
    Y = list(df.iloc[:,1][df.iloc[:,0] == cat2])
    
    #make sure they are floats
    X = [float(x) for x in X]
    Y = [float(y) for y in Y]

    if bins is None:
        (n, bins, patches) = plt.hist(X+Y)
        plt.close()

    if show=='percent':
        cat1Weights = [1/len(X)*100]*len(X)
        cat2Weights = [1/len(Y)*100]*len(Y)
        y_label = 'percent'
    else:
        cat1Weights = [1]*len(X)
        cat2Weights = [1]*len(Y)
        y_label = 'count'
        
    plt.hist(X, alpha=0.5, bins=bins, label=cat1, weights=cat1Weights, **kwargs)
    plt.hist(Y, alpha=0.5, bins=bins, label=cat2, weights=cat2Weights, **kwargs)
    plt.legend(loc='upper right')
    plt.xlabel(var_name)
    plt.ylabel(y_label)
    plt.show()