import pandas as pd
import matplotlib.pyplot as plt
from numpy import diff, allclose
from ..other.table_frequency_bins import tab_frequency_bins

def vi_histogram_split(catField, scaleField, categories=None, bins=None, 
                       show='count', density='auto', shareY=True, figsize=(8,8), **kwargs):
    '''
    Split Histogram
    ---------------
    Based on a categorical field the scores for each category are plotted in a separate histogram and each of the histograms is placed underneath each other.
    
    See **vi_histogram()** for more details on histograms.
    
    Parameters
    ----------
    catField : list or dataframe 
        the categories
    scaleField : list or dataframe
        the scores
    categories : list, optional
        categories to use
    bins : list or dictionary, optional
        list of tuples to use as bins, or dictionary with parameters to pass to tab_frequency_bins().
    show : {'count', 'relative'}, optional
        show either counts or relative count on vertical scale
    density : {'auto', False, True}, optional
        show (relative) frequency or use (relative) frequency density.
    shareY : {True, False}, optional
        use same vertical axis range for each category
    figsize : tuple, optional
        tuple for the figure size. Default is (8, 8)
    kwargs : other parameters for use in pyplot hist function
    
    Returns
    -------
    The split histogram

    Alternatives
    ------------
    In case of a binary-scale situation: [overlaid histogram](../visualisations/vis_histogram_overlay.html), [back-to-back histogram](../visualisations/vis_histogram_b2b.html), [back-to-back stem-and-leaf display](../visualisations/vis_stem_and_leaf_b2b.html), [butterfly chart/pyramid chart](../visualisations/vis_butterfly_bin.html)

    In case of a nominal-scale situation: [split box-plot](../visualisations/vis_boxplot_split.html)

    Next
    ----
    After visualizing the data, you might want to run a test. In case of a binary-scale situation: [Student t](../tests/test_student_t_is.html), [Welch t](../tests/test_welch_t_is.html), [Trimmed means](../tests/test_trimmed_mean_is.html), [Yuen-Welch](../tests/test_trimmed_mean_is.html), [Z test](../tests/test_z_is.html)

    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    if type(catField) is list:
        catField = pd.Series(catField)
    
    if type(scaleField) is list:
        scaleField = pd.Series(scaleField)
    
    #combine as one dataframe
    df = pd.concat([catField, scaleField], axis=1)
    df = df.dropna()
    
    myClusters = df.iloc[:,0]
    myScale = df.iloc[:,1]
    
    if categories != None:
        myCats = categories
    else:
        myCats = myClusters.unique()
    
    myList = []
    for i in myCats:
        myCatScores = myScale[myClusters == i].dropna()
        myList.append(myCatScores)
        
    k = len(myCats)

    if bins is None:
        scores_table = tab_frequency_bins(myScale)
        bins = list(scores_table['lower bound'])
        bins.append(max(scores_table['upper bound']))
    if isinstance(bins, dict):
        scores_table = tab_frequency_bins(myScale, **bins)
        bins = list(scores_table['lower bound'])
        bins.append(max(scores_table['upper bound']))

    if density=='auto':
        bin_widths = diff(bins)
        if allclose(bin_widths, bin_widths[0]):
            density=False
        else:
            density=True

    if shareY:
        n_loops=2
    else:
        n_loops = 1
    for j in range(n_loops):
        if shareY and j==0:
            maxY = 0
        plt.figure(1, figsize=figsize)
        plt.subplots_adjust(hspace=0.5)    
        for i in range(len(myCats)):
            plt.subplot(k,1,i+1)
            n_X, bins, patchesX = plt.hist(myList[i], bins=bins, density=density, **kwargs) 
            N_X = len(myList[i])        
            if (show=="count" and density==True):
                # regular frequency density
                ylbl = 'frequency density'
                # Convert probability density to frequency density
                n_X *= N_X
                
            elif (show=="relative" and density==False):
                # regular count
                ylbl = 'percent'
                # Convert counts to percentages
                n_X /= N_X
                n_X *= 100
            elif (show=="count" and density==False):
                # regular count
                ylbl = 'frequency'
            
            elif (show=="relative" and density==True):
                # regular count
                ylbl = 'probability density'   
            xLim = max(list(n_X))

            if shareY and j==0:
                if max(list(n_X)) > maxY:
                    maxY = max(list(n_X))
            elif shareY==False:
                maxY = max(list(n_X))
            else:
                for rectX, sizeX in zip(patchesX, n_X):
                    rectX.set_height(sizeX)
                plt.ylim(0, maxY)
                plt.xlim(min(myScale), max(myScale))
                plt.xlabel(myCats[i])
                plt.ylabel(ylbl)
                
        if shareY and j==0:
            plt.close()
        else:
            plt.show()