import pandas as pd
import matplotlib.pyplot as plt

def vi_histogram_split(catField, scaleField, categories=None, **kwargs):
    '''
    Split Histogram
    ---------------
    Based on a categorical field the scores for each category are plotted in a separate histogram and each of the histograms is placed underneath each other.
    
    See **vi_histogram()** for more details on histograms.
    
    Parameters
    ----------
    catField : list or dataframe 
        the categories
    scaleField : list or dataframe
        the scores
    categories : list, optional
        categories to use
    kwargs : other parameters for use in pyplot hist function
    
    Returns
    -------
    The split histogram
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    if type(catField) is list:
        catField = pd.Series(catField)
    
    if type(scaleField) is list:
        scaleField = pd.Series(scaleField)
    
    #combine as one dataframe
    df = pd.concat([catField, scaleField], axis=1)
    df = df.dropna()
    
    myClusters = df.iloc[:,0]
    myScale = df.iloc[:,1]
    
    if categories != None:
        myCats = categories
    else:
        myCats = myClusters.unique()
    
    myList = []
    for i in myCats:
        myCatScores = myScale[myClusters == i].dropna()
        myList.append(myCatScores)
        
    k = len(myCats)
    
    plt.figure(1, figsize=(8,8))
    plt.subplots_adjust(hspace=0.5)
    
    for i in range(len(myCats)):
        plt.subplot(k,1,i+1)
        plt.hist(myList[i], **kwargs)            
        plt.xlim(min(myScale), max(myScale))
        plt.xlabel(myCats[i])
        plt.ylabel('Frequency')
        
    plt.show()