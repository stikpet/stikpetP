import pandas as pd
from math import gamma
from ..correlations.cor_pearson import r_pearson

def es_hedges_g_ps(field1, field2, dmu = 0, appr=None, within=True):
    '''
    Hedges g (Paired Samples)
    -------------------------
    Effect size measure for paired samples. This is very similar as Hedges g for independent samples.
    
    Parameters
    ----------
    field1 : pandas series
        the ordinal or scale scores of the first variable
    field2 : pandas series
        the ordinal or scale scores of the second variable
    dmu : float, optional 
        difference according to null hypothesis
    appr : {None, 'exact', 'hedges', 'durlak', 'xue'}, optional 
        approximation to use. None is default 
    within : boolean, optional 
        Use within correlation correction. Default is True
    
    Returns
    -------
    res : dataframe
    
    With:
    
    * *g*, the g value
    * *version*, description of the specific version used
    
    Notes
    -----
    The formula used is the same as for Cohen d<sub>z</sub>. 
    
    The same corrections can then be applied as for the independent samples version. See es_hedges_g_is() for details.
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    if type(field1) == list:
        field1 = pd.Series(field1)
        
    if type(field2) == list:
        field2 = pd.Series(field2)
    
    data = pd.concat([field1, field2], axis=1)
    data.columns = ["field1", "field2"]
    #Remove rows with missing values and reset index
    data = data.dropna()    
    data.reset_index()
    
    #overall n
    n = len(data["field1"])
    
    data["diffs"] = data["field1"] - data["field2"]
    S = data["diffs"].std()
    
    Comment = ""
    if within:
        rres = r_pearson(field1, field2)
        r = rres.iloc[0,0]
        S = S / (2 * (1 - r))**0.5
        Comment = ", with correlation correction"
    
    davg = data["diffs"].mean()
    dz = (davg - dmu)/S
    df = n - 1
    m = df/2
    
    #check if exact chosen and can be calculated
    if appr is None and m > 171:
        #Exact method could not be computed due to large sample size, Hedges approximation used instead
        appr = "hedges"
    
    if appr is None and m < 172:
        # Hedges g (exact)
        g = dz * gamma(m) / (gamma(m - 0.5) * (m**0.5))
        Comment = "exact" + Comment
    elif appr == "hedges":
        #Hedges approximation
        g = dz * (1 - 3 / (4 * df - 1))
        Comment = "Hedges approximation" + Comment
    elif appr == "durlak":
        #Durlak (2009, p. 927) approximation:
        g = dz * (n - 3) / (n - 2.25) * ((n - 2) / n)**0.5
        Comment = "Durlak approximation" + Comment
    elif appr == "xue":
        #Xue (2020, p. 3) approximation:
        g = dz * (1 - 9 / df + 69 / (2 * df**2) - 72 / (df**3) + 687 / (8 * df**4) - 441 / (8 * df**5) + 247 / (16 * df**6))**(1 / 12)
        Comment = "Xue approximation" + Comment
    
    res = pd.DataFrame([[g, Comment]])
    res.columns = ["g", "version"]
    
    return res