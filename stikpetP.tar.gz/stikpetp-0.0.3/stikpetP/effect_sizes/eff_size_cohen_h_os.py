import math
import pandas as pd

def es_cohen_h_os(data, codes=None, p0=0.5):
    '''
    Cohen's h'
    ----------
     
    An adaptation of Cohen h for a one-sample case. It is an effect size measure that could be accompanying a one-sample binomial, score or Wald test.

    If codes are provided, the first code is assumed to be the category for the p0, if no codes are used p0 is assumed to be for the category closest matching the p0 value (i.e. if p0 is above 0.5 the category with the highest count is assumed to be used for p0)
    
    See also https://youtu.be/ddWe94VKX_8, a video on Cohen h'.

    This function is shown in this [YouTube video](https://youtu.be/CHFPfThJ4aY) and the effect size is also described at     [PeterStatistics.com](https://peterstatistics.com/Terms/EffectSizes/CohenH.html)
    
    Parameters
    ----------
    data : list or pandas data series 
        the data
    codes : list, optional 
        list with the two codes to use
    p0 : float, optional 
        probability for first category (the default is 0.5)
        
    Returns
    -------
    results : dataframe
        Cohen's h' value and a comment on which category for p0 was used.
   
    Notes
    -----
    Formula used (Cohen, 1988, p. 202):
    $$h'=\\phi_{1}-\\phi_{h_0}$$
    
    With:
    $$\\phi_{i}=2\\times\\text{arcsin}\\sqrt{p_{i}}$$
    $$p_i = \\frac{F_i}{n}$$
    $$n = \\sum_{i=1}^k F_i$$
    
    *Symbols used*:
    
    * $F_i$, is the (absolute) frequency (count) of category i
    * $n$, is the sample size, i.e. the sum of all frequencies
    * $p_i$, the proportion of cases in category i
    * $p_{h_0}$, the expected proportion (i.e. the proportion according to the null hypothesis)
    
    See Also
    --------
    Before this effect size you might first want to perform a test:
    * [ts_binomial_os](../tests/test_binomial_os.html#ts_binomial_os) for a One-Sample Binomial Test
    * [ts_score_os](../tests/test_score_os.html#ts_score_os) for One-Sample Score Test
    * [ts_wald_os](../tests/test_wald_os.html#ts_wald_os) for One-Sample Wald Test

    After this, you might want a rule-of-thumb or first convert this to a 'regular' Cohen h:
    * [es_convert](../effect_sizes/convert_es.html#es_convert) to convert Cohen h' to Cohen h, use fr="cohenhos" and to=cohenh
    * [th_cohen_h](../other.thumb/cohen_h.html#th_cohen_h) for rules-of-thumb for Cohen h

    Alternatives could be:
    * [es_cohen_g](../effect_sizes/eff_size_cohen_g.html#es_cohen_g) for Cohen g
    * [es_alt_ratio](../effect_sizes/eff_size_alt_ratio.html#es_alt_ratio) for Alternative Ratio
    * [r_rosenthal](../correlations/cor_rosenthal.html#r_rosenthal) for Rosenthal Correlation if a z-value is available
    
    References
    ----------
    Cohen, J. (1988). *Statistical power analysis for the behavioral sciences* (2nd ed.). L. Erlbaum Associates.
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    Example 1: Numeric list
    >>> ex1 = [1, 1, 2, 1, 2, 1, 2, 1]
    >>> es_cohen_h_os(ex1)
    0.2526802551420786
    >>> es_cohen_h_os(ex1, p0=0.3)
    0.6641971012095669
    
    Example 2: pandas Series
    >>> import pandas as pd
    >>> df1 = pd.read_csv('https://peterstatistics.com/Packages/ExampleData/GSS2012a.csv', sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> es_cohen_h_os(df1['sex'])
    0.10250973241574934
    >>> es_cohen_h_os(df1['mar1'], codes=["DIVORCED", "NEVER MARRIED"])
    -0.11449540934184599
    
    '''
    
    if type(data) is list:
        data = pd.Series(data)

    #remove missing values
    data = data.dropna()
        
    #Determine number of successes, failures, and total sample size
    if codes is None:
        freq = data.value_counts()
        n = sum(freq.values)
        n1 = freq.values[0]
        n2 = n - n1

        #determine p0 was for which category
        p0_cat = freq.index[0]
        if p0 > 0.5 and n1 < n2:
            n3=n2
            n2 = n1
            n1 = n3
            p0_cat = freq.index[1]
        cat_used =  "assuming p0 for " + str(p0_cat)
    
    else:        
        n1 = sum(data==codes[0])
        n2 = sum(data==codes[1])
        n = n1 + n2
        cat_used =  "with p0 for " + str(codes[0])
        
    p1 = n1/n
    
    phi1 = 2 * math.asin(p1**0.5)
    phic = 2 * math.asin(p0**0.5)
    
    h2 = phi1 - phic

    results = pd.DataFrame([[h2, cat_used]], columns=["Cohen h'", "comment"])
    
    return (results)