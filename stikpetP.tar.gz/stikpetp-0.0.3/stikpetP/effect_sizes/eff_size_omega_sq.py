from ..tests.test_fisher_owa import ts_fisher_owa

def es_omega_sq(nomField, scaleField, categories=None):
    '''
    Omega Squared
    -------------
    An effect size measure for a one-way ANOVA. It indicates the the strength of the categories on the scale field. A 0 would indicate no influence, and 1 a perfect relationship.
    
    Although a popular belief is that \\(\\omega^2\\) is preferred over \\(\\epsilon^2\\) (Keselman, 1975), a later study actually showed that \\(\\epsilon^2\\) might be preferred (Okada, 2013).
    
    Parameters
    ----------
    nomField : pandas series
        data with categories
    scaleField : pandas series
        data with the scores
    categories : list or dictionary, optional
        the categories to use from catField
        
    Returns
    -------
    om2 : float
        the omega squared value
    
    Notes
    -----
    The formula used (Kirk, 1996, p. 751):
    $$\\omega^2 = \\frac{\\left(F - 1\\right)\\times df_b}{df_b\\times\\left(F-1\\right)+n}$$
    
    There are quite some variations on the formula above, all giving the same final result. 
    
    Hays (1973, p. 486) and Albers and Lakens (2018, p. 194):
    $$\\omega^2 = \\frac{F - 1}{\\frac{df_w + 1}{df_b} + F}$$
    
    Caroll and Nordholm (1975, p. 547)
    $$\\omega^2 = \\frac{F - 1}{\\frac{N - k + 1}{k - 1} + F}$$
    
    Hays (1973, p. 485):
    $$\\omega^2 = \\frac{SS_b - \\left(k - 1\\right)\\times MS_w}{SS_t + MS_w}$$
    
    Olejnik and Algina (2003, p. 435):
    $$\\omega^2 = \\frac{SS_b - df_b\\times MS_w}{SS_b + \\left(n - df_b\\right)\\times MS_w}$$
    
    With:
    $$MS_b = \\frac{SS_b}{df_b}$$
    $$MS_w = \\frac{SS_w}{df_w}$$
    $$SS_b = \\sum_{j=1}^k n_j\\times\\left(\\bar{x}_j - \\bar{x}\\right)^2$$
    $$SS_w = \\sum_{j=1}^k \\sum_{i=1}^{n_j} \\left(x_{i,j} - \\bar{x}_j\\right)^2$$
    $$\\bar{x}_j = \\frac{\\sum_{i=1}^{n_j} x_{i,j}}{n_j}$$
    $$\\bar{x} = \\frac{\\sum_{j=1}^k n_j \\times \\bar{x}_j}{n} = \\frac{\\sum_{j=1}^k \\sum_{i=1}^{n_j} x_{i,j}}{n}$$
    $$n = \\sum_{j=1}^k n_j$$
    
    *Symbols used:*
    
    * \\(x_{i,j}\\), the i-th score in category j
    * \\(n\\), the total sample size
    * \\(n_j\\), the number of scores in category j
    * \\(k\\), the number of categories
    * \\(\\bar{x}_j\\), the mean of the scores in category j
    * \\(MS_i\\), the mean square of i
    * \\(SS_i\\), the sum of squares of i (sum of squared deviation of the mean)
    * \\(df_i\\), the degrees of freedom of i
    * \\(b\\), is between = factor = treatment = model
    * \\(w\\), is within = error (the variability within the groups)
    
    References
    ----------
    Albers, C., & Lakens, D. (2018). When power analyses based on pilot data are biased: Inaccurate effect size estimators and follow-up bias. *Journal of Experimental Social Psychology, 74*, 187–195. doi:10.1016/j.jesp.2017.09.004
    
    Carroll, R. M., & Nordholm, L. A. (1975). Sampling characteristics of Kelley’s ε and Hays’ ω. *Educational and Psychological Measurement, 35*(3), 541–554. doi:10.1177/001316447503500304
    
    Hays, W. L. (1973). *Statistics for the social sciences* (2nd ed.). Holt, Rinehart and Winston.
    
    Keselman, H. J. (1975). A Monte Carlo investigation of three estimates of treatment magnitude: Epsilon squared, eta squared, and omega squared. *Canadian Psychological Review / Psychologie Canadienne, 16*(1), 44–48. doi:10.1037/h0081789
    
    Kirk, R. E. (1996). Practical significance: A concept whose time has come. *Educational and Psychological Measurement, 56*(5), 746–759. doi:10.1177/0013164496056005002
    
    Okada, K. (2013). Is omega squared less biased? A comparison of three major effect size indices in one-way anova. *Behaviormetrika, 40*(2), 129–147. doi:10.2333/bhmk.40.129
    
    Olejnik, S., & Algina, J. (2003). Generalized eta and omega squared statistics: Measures of effect size for some common research designs. *Psychological Methods, 8*(4), 434–447. doi:10.1037/1082-989X.8.4.434
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''

    #Anova table
    aTab = ts_fisher_owa(nomField, scaleField, categories)
    
    f = aTab.iloc[0, 4]
    dfb = aTab.iloc[0, 2]
    n = aTab.iloc[2, 2] + 1
    
    om2 = (f - 1) * dfb / (dfb * (f - 1) + n)
    
    return om2