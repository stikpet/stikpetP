from math import log
import pandas as pd

def es_fei(chi2, n, minExp):
    '''
    Fei
    -----------------------
     
    An effect size measure that could be used with a chi-square test of goodness-of-fit.
    
    Parameters
    ----------
    chi2 : float
        the chi-square test statistic
    n : int
        the sample size
    minExp: float
        the minimum expected count
        
    Returns
    -------
    f : float
        the value of Fei
   
    Notes
    -----
    The formula used (Ben-Shachar et al., 2023, p. 6):
    $$Fei = \\sqrt{\\frac{\\chi_{GoF}^2}{n\\times\\left(\\frac{1}{\\min\\left(p_E\\right)}-1\\right)}}$$
    
    *Symbols*
    
    * $\\chi_{GoF}^2$, the chi-square value of the goodness-of-fit chi-square test
    * $n$, the sample size
    * $p_E$, the expected proportions
    
    *Classification*
    
    A qualification rule-of-thumb could be obtained by converting this to Cohen's w (use **es_convert(Fei, fr="fei", to="cohenw", ex1=minExp/n)**)
    
    See Also
    --------
    stikpetP.effect_sizes.convert_es.es_convert : to convert Fei to Cohen w, use fr="jbme", to="cohenw", and ex1=minExp/n
    stikpetP.other.thumb_cohen_w.th_cohen_w : rules-of-thumb for Cohen w
    
    References
    ----------
    Ben-Shachar, M. S., Patil, I., Thériault, R., Wiernik, B. M., & Lüdecke, D. (2023). Phi, fei, fo, fum: Effect sizes for categorical data that use the chi-squared statistic. *Mathematics, 11*(1982), 1–10. doi:10.3390/math11091982
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076

    Example
    --------
    >>> chi2 = 23.5
    >>> n = 53
    >>> minExp = 14
    >>> es_fei(chi2=chi2, n=n, minExp=minExp)
    0.39895848925547156
    
    '''
    pe = minExp/n
    f = (chi2/(n*(1/pe - 1)))**0.5
    return f