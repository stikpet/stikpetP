import pandas as pd

def es_cohen_w(chi2, n):
    '''
    Cohen's w
    ---------
     
    An effect size measure that could be used with a chi-square test. It has no upper limit, but can be compared to Cohen's rules-of-thumb. 

    This function is shown in this [YouTube video]() and the measure is also described at [PeterStatistics.com](https://peterstatistics.com/Terms/EffectSizes/CohenW.html)
    
    Parameters
    ----------
    chi2 : float
        the chi-square test statistic
    n : int
        the sample size
        
    Returns
    -------
    w : float
        value of Cohen's w
   
    Notes
    -----
    The formula used is (Cohen, 1988, p. 216):
    $$w = \\sqrt\\frac{\\chi_{GoF}^{2}}{n}$$
    
    *Symbols used*:
    
    * $\\chi_{GoF}^{2}$, the Pearson chi-square goodness-of-fit value 
    * $n$, the sample size, i.e. the sum of all frequencies
    
    See Also
    --------
    Before this you will need a chi-square value. From either:
    * [ts_pearson_gof](../tests/test_pearson_gof.html#ts_pearson_gof) for Pearson Chi-Square Goodness-of-Fit Test
    * [ts_freeman_tukey_gof](../tests/test_freeman_tukey_gof.html#ts_freeman_tukey_gof) for Freeman-Tukey Test of Goodness-of-Fit
    * [ts_freeman_tukey_read](../tests/test_freeman_tukey_read.html#ts_freeman_tukey_read) for Freeman-Tukey-Read Test of Goodness-of-Fit
    * [ts_g_gof](../tests/test_g_gof.html#ts_g_gof) for G (Likelihood Ratio) Goodness-of-Fit Test
    * [ts_mod_log_likelihood_gof](../tests/test_mod_log_likelihood_gof.html#ts_mod_log_likelihood_gof) for Mod-Log Likelihood Test of Goodness-of-Fit
    * [ts_neyman_gof](../tests/test_neyman_gof.html#ts_neyman_gof) for Neyman Test of Goodness-of-Fit
    * [ts_powerdivergence_gof](../tests/test_powerdivergence_gof.html#ts_powerdivergence_gof) for Power Divergence GoF Test
    * [ph_pairwise_gof](../other/poho_pairwise_gof.html#ph_pairwise_gof) for Pairwise Goodness-of-Fit Tests
    * [ph_residual_gof_gof](../other/poho_residual_gof_gof.html#ph_residual_gof_gof) for Residuals Using Goodness-of-Fit Tests

    After this you might want to use some rule-of-thumb for the interpretation:
    * [th_cohen_w](../other/thumb_cohen_w.html#th_cohen_w) for various rules-of-thumb for Cohen w

    Alternative effect sizes that use a chi-square value:
    * [es_cramer_v_gof](../effect_sizes/eff_size_cramer_v_gof.html#es_cramer_v_gof) for Cramer's V for Goodness-of-Fit
    * [es_jbm_e](../effect_sizes/eff_size_jbm_e.html#es_jbm_e) for Johnston-Berry-Mielke E
    * [es_fei](../effect_sizes/eff_size_fei.html#es_fei) for Fei
    
    References 
    ----------
    Cohen, J. (1988). *Statistical power analysis for the behavioral sciences* (2nd ed.). L. Erlbaum Associates.

    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> chi2 = 3.106
    >>> n = 19
    >>> es_cohen_w(chi2, n)
    0.40431879032581
    
    
    '''
    
    w = (chi2 / n)**0.5
    
    return w
