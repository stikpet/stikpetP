from statistics import NormalDist

def es_cohen_u(d, version='u3'):
    '''
    Cohen U
    -----------------------------------------------
    Cohen (1988, p. 23) provided three measures that relate to Cohen's d.
    
    * \\(U_1\\), is (supposedly) the proportion of non-overlap between distributions
    * \\(U_2\\), is (supposedly) the proportion of overlap between distributions
    * \\(U_3\\), is (supposedly) the proportion of one group's scores below the mean of another group
    
    \\(U_1\\) and \\(U_2\\) are probably the least used of these three, since most likeley Cohen was wrong in his calculation (Grice & Barrett, 2014). A nice interactive visualisation of the relation between Cohen \\(U_3\\) and the Common Language Effect size, can be found at <a href="https://rpsychologist.com/therapist-effects/" target="new">rpsychologist</a>. It actually correct's Cohen U. 
    
    By converting each back to Cohen's d, the rule-of-thumb from Cohen d could be used as classification.

    The measure is also described at [PeterStatistics.com](https://peterstatistics.com/Terms/EffectSizes/CohenU.html)
    
    Parameters
    ----------
    d : float 
        the Cohen d value
    version : {"u3", "u2", "u1"}
        the version of Cohen U to determine

    Returns
    -------
    The Cohen U value
    
    Notes
    ------
    The following formulas are used (Cohen, 1988, p. 23):
    $$U_3 = \\Phi\\left(d\\right)$$
    $$U_2 = \\Phi\\left(\\frac{d}{2}\\right)$$
    $$U_1 = \\Phi\\left(\\frac{2\\times U_2 - 1}{U_2}\\right)$$
    
    *Symbols used:*
    
    * \\(d\\), Cohen's d value
    * \\(\\Phi\\left(\\dots\\right)\\) the cumulative density function of the standard normal distribution.

    Before, After and Alternatives
    ------------------------------
    Before the effect size you might want to run a test. Various options include [ts_student_t_os](../tests/test_student_t_os.html#ts_student_t_os) for One-Sample Student t-Test, [ts_trimmed_mean_os](../tests/test_trimmed_mean_os.html#ts_trimmed_mean_os) for One-Sample Trimmed (Yuen or Yuen-Welch) Mean Test, or [ts_z_os](../tests/test_z_os.html#ts_z_os) for One-Sample Z Test.

    To get some rule-of-thumb convert Cohen U to Cohen d with [es_convert()](../effect_sizes/convert_es.html) function, and set `fr="cohenu1", to="cohend"`, of course replace *cohenu1* with the appropriate version of Cohen U used.

    After the conversion use [th_cohen_d()](../other/thumb_cohen_d.html) for the rule-of-thumb.
    
    Alternative effect sizes include: [Common Language](../effect_sizes/eff_size_common_language_is.html), [Cohen d_s](../effect_sizes/eff_size_hedges_g_is.html), [Cohen U](../effect_sizes/eff_size_cohen_u.html), [Hedges g](../effect_sizes/eff_size_hedges_g_is.html), [Glass delta](../effect_sizes/eff_size_glass_delta.html)
    
    or the correlation coefficients: [biserial](../correlations/cor_biserial.html), [point-biserial](../effect_sizes/cor_point_biserial.html)    
    
    References
    ----------
    Cohen, J. (1988). *Statistical power analysis for the behavioral sciences* (2nd ed.). L. Erlbaum Associates.

    Grice, J. W., & Barrett, P. T. (2014). A note on Cohen’s overlapping proportions of normal distributions. *Psychological Reports, 115*(3), 741–747. https://doi.org/10.2466/03.pr0.115c29z4
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    if version=='u3':
        u = NormalDist().cdf(d)
    elif version=='u2' or version=='u1':
        u = NormalDist().cdf(d/2)
        if version=='u1':
            u = (2*u - 1)/u
    
    return (u)