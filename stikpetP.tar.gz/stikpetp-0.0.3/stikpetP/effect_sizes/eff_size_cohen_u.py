from statistics import NormalDist

def es_cohen_u(d, version='u3'):
    '''
    Cohen U
    -----------------------------------------------
    Cohen (1988, p. 23) provided three measures that relate to Cohen's d.
    
    * \\(U_1\\), is the proportion of non-overlap between distributions
    * \\(U_2\\), is the proportion of overlap between distributions
    * \\(U_3\\), is the proportion of one group's scores below the mean of another group
    
    \\(U_1\\) and \\(U_2\\) are probably the least used of these three.
    
    By converting each back to Cohen's d, the rule-of-thumb from Cohen d could be used as classification.
    
    A nice interactive visualisation of the relation between Cohen $U_3$ and the Common Language Effect size, can be found at https://rpsychologist.com/therapist-effects/. 
    
    Parameters
    ----------
    d : float 
        the Cohen d value
    version : {"u3", "u2", "u1"}
        the version of Cohen U to determine

    Returns
    -------
    The Cohen U value
    
    Notes
    ------
    The following formulas are used (Cohen, 1988, p. 23):
    $$U_3 = \\Phi\\left(d\\right)$$
    $$U_2 = \\Phi\\left(\\frac{d}{2}\\right)$$
    $$U_1 = \\Phi\\left(\\frac{2\\times U_2 - 1}{U_2}\\right)$$
    
    *Symbols used:*
    
    * \\(d\\), Cohen's d value
    * \\(\\Phi\\left(\\dots\\right)\\) the cumulative density function of the standard normal distribution

    See Also
    --------
    stikpetP.effect_sizes.convert_es.es_convert : to convert an U to Cohen d use `fr="cohenu.", to="cohend"`. 
    
    References
    ----------
    Cohen, J. (1988). *Statistical power analysis for the behavioral sciences* (2nd ed.). L. Erlbaum Associates.
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    if version=='u3':
        u = NormalDist().cdf(d)
    elif version=='u2' or version=='u1':
        u = NormalDist().cdf(d/2)
        if version=='u1':
            u = (2*u - 1)/u
    
    return (u)