import pandas as pd

def es_cramer_v_gof(chi2, n, k, bergsma=False):
    r'''
    Cramer's V for Goodness-of-Fit
    ------------------------------
     
    Cramer's V is one possible effect size when using a chi-square test. This measure is actually designed for the chi-square test for independence but can be adjusted for the goodness-of-fit test (Kelley & Preacher, 2012, p. 145; Mangiafico, 2016, p. 474). 
    
    It gives an estimate of how well the data then fits the expected values, where 0 would indicate that they are exactly equal. If you use the equal distributed expected values the maximum value would be 1, otherwise it could actually also exceed 1.
    
    As for a classification Cramer's V can be converted to Cohen w, for which Cohen provides rules of thumb.
    
    A Bergsma correction is also possible.

    A general explanation can also be found in this [YouTube video](https://youtu.be/FZcnk4EYpek). The function is shown in this [YouTube video]() and the test is also described at [PeterStatistics.com](https://peterstatistics.com/Terms/EffectSizes/CramerV.html).
    
    Parameters
    ----------
    chi2 : float
        the chi-square test statistic        
    n : int
        the sample size        
    k : int
        the number of categories        
    bergsma : boolean, optional 
        to indicate the use of the Bergsma correction (default is False)
        
    Returns
    -------
    v : float
        Cramer's V value
    
    Notes
    -----
    The formula used is:  
    $$V = \\sqrt{ \\frac{ \\chi_{GoF}^{2} }{ n \\times \\left(k - 1\\right) }}$$
    
    *Symbols used*:
    
    * $k$, the number of categories
    * $n$, the sample size, i.e. the sum of all frequencies
    * $\\chi_{GoF}^{2}$, the chi-square value of a Goodness-of-Fit test
    
    The Bergsma correction uses a different formula.
    $$\\tilde{V} = \\sqrt{\\frac{\\tilde{\\varphi}^2}{\\tilde{k} - 1}}$$
    
    With:
    $$\\tilde{\\varphi}^2 = max\\left(0,\\varphi^2 - \\frac{k - 1}{n - 1}\\right)$$
    $$\\tilde{k} = k - \\frac{\\left(k - 1\\right)^2}{n - 1}$$
    $$\\varphi^2 = \\frac{\\chi_{GoF}^{2}}{n}$$
    
    Cramer described V (1946, p. 282) for use with a test of independence. Others (e.g. K. Kelley & Preacher, 2012, p. 145; Mangiafico, 2016a, p. 474) added that this can also be use for goodness-of-fit tests.
    
    For the Bergsma (2013, pp. 324-325) correction the same thing applies.
    
    *Classification*
    
    Either convert Cramer's V to Cohen w (using **es_convert(v, fr="cramervgof", to="cohenw", ex1=k)**, or use the **th_cramer_v()** function.
    
    Before, After and Alternatives
    ------------------------------
    Before this you will need a chi-square value. From either:
    * [ts_pearson_gof](../tests/test_pearson_gof.html#ts_pearson_gof) for Pearson Chi-Square Goodness-of-Fit Test
    * [ts_freeman_tukey_gof](../tests/test_freeman_tukey_gof.html#ts_freeman_tukey_gof) for Freeman-Tukey Test of Goodness-of-Fit
    * [ts_freeman_tukey_read](../tests/test_freeman_tukey_read.html#ts_freeman_tukey_read) for Freeman-Tukey-Read Test of Goodness-of-Fit
    * [ts_g_gof](../tests/test_g_gof.html#ts_g_gof) for G (Likelihood Ratio) Goodness-of-Fit Test
    * [ts_mod_log_likelihood_gof](../tests/test_mod_log_likelihood_gof.html#ts_mod_log_likelihood_gof) for Mod-Log Likelihood Test of Goodness-of-Fit
    * [ts_neyman_gof](../tests/test_neyman_gof.html#ts_neyman_gof) for Neyman Test of Goodness-of-Fit
    * [ts_powerdivergence_gof](../tests/test_powerdivergence_gof.html#ts_powerdivergence_gof) for Power Divergence GoF Test
    * [ph_pairwise_gof](../other/poho_pairwise_gof.html#ph_pairwise_gof) for Pairwise Goodness-of-Fit Tests
    * [ph_residual_gof_gof](../other/poho_residual_gof_gof.html#ph_residual_gof_gof) for Residuals Using Goodness-of-Fit Tests

    After this you might want to use some rule-of-thumb for the interpretation:
    * [th_cramer_v](../other/thumb_cramer_v.html#th_cramer_v) for various rules-of-thumb for Cramer V

    or convert to Cohen w:
    * [es_convert](../effect_sizes/convert_es.html#es_convert) to convert Cramer's V to Cohen w (using fr="cramervgof", to="cohenw", ex1=k)
    * [th_cohen_w](../other/thumb_cohen_w.html#th_cohen_w) for various rules-of-thumb for Cohen w

    Alternative effect sizes that use a chi-square value:
    * [es_cohen_w](../effect_sizes/eff_size_cohen_w.html#es_cohen_w) for Cohen's w
    * [es_jbm_e](../effect_sizes/eff_size_jbm_e.html#es_jbm_e) for Johnston-Berry-Mielke E
    * [es_fei](../effect_sizes/eff_size_fei.html#es_fei) for Fei
    
    References
    ----------
    Bergsma, W. (2013). A bias-correction for Cramer’s and Tschuprow’s. *Journal of the Korean Statistical Society, 42*(3), 323–328. doi:10.1016/j.jkss.2012.10.002
    
    Cramer, H. (1946). *Mathematical methods of statistics*. Princeton University Press.
    
    Kelley, K., & Preacher, K. J. (2012). On effect size. *Psychological Methods, 17*(2), 137–152. doi:10.1037/a0028086
    
    Mangiafico, S. S. (2016). *Summary and analysis of extension program evaluation in R* (1.13.5). Rutger Cooperative Extension.

    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> chi2Value = 3.106
    >>> n = 19
    >>> k = 3
    >>> es_cramer_v_gof(chi2Value, n, k)
    0.2858965584005221
    >>> es_cramer_v_gof(chi2Value, n, k, bergsma=True)
    0.17162152361641894
    
    '''
    
    df = k - 1
    
    if bergsma:
        kAvg = k - df**2/(n - 1)
        phi2 = chi2/n
        phi2Avg = max(0, phi2 - df/(n - 1))
        v = (phi2Avg/(kAvg - 1))**0.5
    else:
        v = (chi2/(n * df))**0.5
    
    return v    