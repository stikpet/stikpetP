from statistics import mean, stdev
import pandas as pd

def es_cohen_d_os(data, mu=None):
    '''
    Cohen d'
    --------
     
    This function will calculate Cohen d' (one-sample). An effect size measure that can be used with a test for a single mean (for example a one-sample Student t-test).

    The measure is also described at [PeterStatistics.com](https://peterstatistics.com/Terms/EffectSizes/CohenD.html)
    
    Parameters
    ----------
    data : list or pandas series 
        the numeric scores
    mu : float, optional 
        the hypothesized mean. If not used the midrange is used
        
    Returns
    -------
    dos : Cohen d' value
   
    Notes
    -----
    The formula used (Cohen, 1988, p. 46):
    $$d'=\\frac{\\bar{x}-\\mu_{H_{0}}}{s}$$
    With:
    $$s = \\sqrt{\\frac{\\sum_{i=1}^n \\left(x_i - \\bar{x}\\right)^2}{n - 1}}$$
    $$\\bar{x} = \\frac{\\sum_{i=1}^n x_i}{n}$$
    
    *Symbols used:*
    
    * $\\bar{x}$ the sample mean
    * $\\mu_{H_0}$ the hypothesized mean in the population
    * $n$ the sample size (i.e. the number of scores)
    * $s$ the unbiased sample standard deviation
    * $x_i$ the i-th score
    
    *Classification*
    
    Cohen d' can be converted to a 'regular' Cohen d and then rules of thumb for the interpertation could be used. 
    
    Before, After and Alternatives
    ------------------------------
    Before this you might want to perform a test:
    * [ts_student_t_os](../tests/test_student_t_os.html#ts_student_t_os) for One-Sample Student t-Test
    * [ts_trimmed_mean_os](../tests/test_trimmed_mean_os.html#ts_trimmed_mean_os) for One-Sample Trimmed (Yuen or Yuen-Welch) Mean Test
    * [ts_z_os](../tests/test_z_os.html#ts_z_os) for One-Sample Z Test

    After this you might want a rule-of-thumb for the effect size, first convert to regular Cohen d:
    * [es_convert](../effect_sizes/convert_es.html#es_convert) to convert Cohen's d one-sample to Cohen d, use *fr = "cohendos"* and *to = "cohend"*
    * [th_cohen_d](../other/thumb_cohen_d.html#th_cohen_d) for rules-of-thumb for Cohen d
    
    Alternative Effect Sizes:
    * [es_hedges_g_os](../effect_sizes/eff_size_hedges_g_os.html#es_hedges_g_os) for Hedges g
    * [es_common_language_os](../eff_size_common_language_os/meas_variation.html#es_common_language_os) for the Common Language Effect Size
    
    References
    ----------
    Cohen, J. (1988). *Statistical power analysis for the behavioral sciences* (2nd ed.). L. Erlbaum Associates.
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    Example 1: Numeric Pandas Series
    >>> import pandas as pd
    >>> df2 = pd.read_csv('https://peterstatistics.com/Packages/ExampleData/StudentStatistics.csv', sep=';', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> ex1 = df2['Gen_Age']
    >>> es_cohen_d_os(ex1)
    -2.9082571798993557
    
    Example 2: Numeric list
    >>> ex2 = [1, 1, 1, 2, 2, 2, 3, 3, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5]
    >>> es_cohen_d_os(ex2)
    0.28127524771945256
    
    '''
    #data as a pandas series
    if type(data) is list:
        data = pd.Series(data)
    
    #remove missing values
    data = data.dropna()
    
    #set hypothesized median to mid range if not provided
    if (mu is None):
        mu = (min(data) + max(data)) / 2
        
    xBar = mean(data)
    s = stdev(data)
    dos = (xBar - mu)/s
    
    return dos