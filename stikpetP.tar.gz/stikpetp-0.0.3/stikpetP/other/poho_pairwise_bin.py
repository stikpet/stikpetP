import pandas as pd
from ..tests.test_binomial_os import ts_binomial_os
from ..tests.test_wald_os import ts_wald_os
from ..tests.test_score_os import ts_score_os
from ..other.p_adjustments import p_adjust

def ph_pairwise_bin(data, test="binomial", expCount=None, mtc='bonferroni', **kwargs):
    '''
    Pairwise Binary Test for Post-Hoc Analysis
    --------------------------------------------
    
    This function will perform a one-sample binary test for each possible pair in the data. This could either be a binomial, Wald or score test.

    The unadjusted p-values and Bonferroni adjusted p-values are both determined.
    
    Parameters
    ----------
    data : list or pandas series
    test : {"binomial", "score", "wald"}, optional
        test to use for each pair
    expCount : pandas dataframe, optional 
        categories and expected counts
    mtc : string, optional
        any of the methods available in p_adjust() to correct for multiple tests
    **kwargs : optional
        additional arguments for the specific test that are passed along.
    
    Returns
    -------
    results : pandas dataframe with:
    
    * *category 1*, the label of the first category
    * *category 2*, the label of the second category
    * *n1*, the sample size of the first category
    * *n2*, the sample size of the second category 
    * *obs. prop. 1*, the proportion in the sample of the first category
    * *exp. prop. 1*, the expected proportion for the first category
    * *p-value*, the unadjusted significance
    * *adj. p-value*, the adjusted significance

    See Also
    --------
    stikpetP.tests.test_binomial_os.ts_binomial_os : more info on the one-sample binomial test
    stikpetP.tests.test_wald_os.ts_wald_os : more info on the one-sample Wald test
    stikpetP.tests.test_score_os.ts_score_os : more info on the one-sample score test
    stikpetP.other.p_adjustments.p_adjust
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    if type(data) is list:
        data = pd.Series(data)
        
    freq = data.value_counts()
    
    if expCount is None:
        #assume all to be equal
        n = sum(freq)
        k = len(freq)
        categories = list(freq.index)
        expC = [n/k] * k
        
    else:
        #check if categories match
        nE = 0
        n = 0
        for i in range(0, len(expCount)):
            nE = nE + expCount.iloc[i,1]
            n = n + freq[expCount.iloc[i,0]]
        
        expC = []
        for i in range(0,len(expCount)):
            expC.append(expCount.iloc[i, 1]/nE*n)
            
        k = len(expC)
        categories = list(expCount.iloc[:,0])

    n_pairs = int(k*(k-1)/2)

    results = pd.DataFrame()
    resRow=0
    for i in range(0, k-1):
        for j in range(i+1, k):
            #category names
            results.at[resRow, 0] = categories[i]
            results.at[resRow, 1] = categories[j]
            #category sizes
            n1 = freq[categories[i]]
            n2 = freq[categories[j]]
            results.at[resRow, 2] = n1
            results.at[resRow, 3] = n2
            results.at[resRow, 4] = n1 + n2
    
            #observed and expected proportion
            obP1 = n1/(n1 + n2)
            exP1 = expC[i]/(expC[i]+expC[j])
            results.at[resRow, 5] = obP1
            results.at[resRow, 6] = exP1

            pair = [categories[i], categories[j]]
            
            if test=="binomial":
                # the test statistic
                results.at[resRow, 7] = "n.a."
                
                pair_test_result = ts_binomial_os(data, codes=pair, p0=exP1, **kwargs)
                # the p-value
                results.at[resRow, 8] = pair_test_result.iloc[0, 0]
    
                # the adj. p-value
                #fill something for the adjusted p-values
                results.at[resRow, 9] = results.at[resRow, 8]
                # description of test
                results.at[resRow, 10] = pair_test_result.iloc[0, 1]
    
            else:
                if test=="wald":
                    pair_test_result = ts_wald_os(data, codes=pair, p0=exP1, **kwargs)
                elif test=="score":
                    pair_test_result = ts_score_os(data, codes=pair, p0=exP1, **kwargs)
    
                # the test statistic
                results.at[resRow, 7] = pair_test_result.iloc[0, 1]
                
                # the p-value
                results.at[resRow, 8] = pair_test_result.iloc[0, 2]
                #fill something for the adjusted p-values
                results.at[resRow, 9] = results.at[resRow, 8]
                # description of test
                results.at[resRow, 10] = pair_test_result.iloc[0, 3]
            resRow = resRow + 1

    results.iloc[:,9] = p_adjust(results.iloc[:,8], method=mtc, **kwargs)
    
    results.columns = ["category 1", "category 2", "n1", "n2", "n pair", "obs. prop. 1", "exp. prop. 1", "statistic", "p-value", "adj. p-value", "test"]
    return results