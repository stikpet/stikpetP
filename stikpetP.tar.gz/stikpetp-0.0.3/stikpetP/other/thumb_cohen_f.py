import pandas as pd

def th_cohen_f(f, qual="cohen"):
    '''
    Rules of Thumb for Cohen f
    --------------------------
     
    This function will give a qualification (classification) for Cohen f
    
    Parameters
    ----------
    f : float
        the Cohen f value
    qual : {"cohen"} optional 
        the rule of thumb to be used. Currently only "cohen'.
        
    Returns
    -------
    results : a pandas dataframe with.
    
    * *classification*, the qualification of the effect size
    * *reference*, a reference for the rule of thumb used
   
    Notes
    -----
    The following rules-of-thumb can be used:
    
    *"cohen"* => Uses Cohen (1988, pp. 285-287):
    
    |\\|f\\|| Interpretation|
    |---|----------|
    |0.00 < 0.10 | negligible |
    |0.10 < 0.25 | small |
    |0.25 < 0.40 | medium |
    |0.40 or more | large |
    

    References
    ----------
    Cohen, J. (1988). *Statistical power analysis for the behavioral sciences* (2nd ed.). L. Erlbaum Associates.
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
            
    #Cohen (1988, p. 40).
    if (qual=="cohen"):
        ref = "Cohen (1988, pp. 285-287)"
        if (abs(f) < 0.1):
            qual = "negligible"
        elif (abs(f) < 0.25):
            qual = "small"
        elif (abs(f) < 0.4):
            qual = "medium"
        else:
            qual = "large"
    
    results = pd.DataFrame([[qual, ref]], columns=["classification", "reference"])
    
    return results