import pandas as pd

def th_odds_ratio(odrat, qual="chen"):
    '''
    Rules of Thumb for Odds Ratio
    -----------------------------
     
    This function will give a qualification (classification) for a given Odds Ratio
    
    Parameters
    ----------
    odrat : float
        the odds ratio value
    qual : {"chen", "wuensch", "jones1", "jones2", "hopkins", "rosenthal"}, optional
        rules-of-thumb to use
    
    Returns
    -------
    results : a dataframe with.
    
    * *classification*, the qualification of the effect size
    * *reference*, a reference for the rule of thumb used
    
    Notes
    -----
    For the rules-of-thumb if the odds ratio is less than 1 the inverse is used:
    
    $$OR^{\\ast} = \\begin{cases} OR & \\text{ if } OR\\geq =1 \\\\ \\frac{1}{OR} & \\text{ if } OR< 1  \\end{cases}$$
    
    The following rules-of-thumb can be used:
    
    "chen" => Chen et al. (2010, p. 864)
    
    |\\(OR^{\\ast}\\)| Interpretation|
    |---|----------|
    |1.00 < 1.68 | negligible |
    |1.68 < 3.47 | small |
    |3.47 < 6.71 | medium |
    |6.71 or more | large |
    
    "hopkins" => Hopkins (1997, tbl. 1)
    
    |\\(OR^{\\ast}\\)| Interpretation|
    |---|----------|
    |1.00 < 1.50 | trivial |
    |1.50 < 3.50 | small |
    |3.50 < 9.00 | moderate |
    |9.00 < 32.0 | large |
    |32.0 < 360 | very large |
    |360 or more | nearly perfect |
    
    "jones1" => Jones (2014)
    
    |\\(OR^{\\ast}\\)| Interpretation|
    |---|----------|
    |1.00 < 1.50 | negligible |
    |1.50 < 2.50 | small |
    |2.50 < 4.30 | medium |
    |4.30 or more | large |
    
    "jones2" => Jones (2014)
    
    |\\(OR^{\\ast}\\)| Interpretation|
    |---|----------|
    |1.00 < 1.50 | negligible |
    |1.50 < 3.50 | small |
    |3.50 < 9.00 | medium |
    |9.00 or more | large |
    
    "wuensch" => Wuensch (2009, p. 2)
    
    |\\(OR^{\\ast}\\)| Interpretation|
    |---|----------|
    |1.00 < 1.49 | negligible |
    |1.49 < 3.45 | small |
    |3.45 < 9.00 | medium |
    |9.00 or more | large |
    
    "rosenthal" => Rosenthal (1996, p. 51)
    
    |\\(OR^{\\ast}\\)| Interpretation|
    |---|----------|
    |1.00 < 1.5 | negligible |
    |1.50 < 2.50 | weak association or small effect size |
    |2.50 < 4.00 | moderate association or medium effect size |
    |4.00 < 10 | strong association or large effect size|
    |10 or more| very strong association or very large effect size|
    
    See Also
    --------
    stikpetP.effect_sizes.eff_size_odds_ratio.es_odds_ratio : to determine the odds ratio.
    
    References
    ----------
    Chen, H., Cohen, P., & Chen, S. (2010). How big is a big Odds Ratio? Interpreting the magnitudes of Odds Ratios in epidemiological studies. *Communications in Statistics - Simulation and Computation, 39*(4), 860–864. https://doi.org/10.1080/03610911003650383
    
    Hopkins, W. G. (2006, August 7). New view of statistics: Effect magnitudes. http://www.sportsci.org/resource/stats/effectmag.html
    
    Jones, K. (2014, June 5). How do you interpret the odds ratio (OR)? ResearchGate. https://www.researchgate.net/post/How_do_you_interpret_the_odds_ratio_OR

    Rosenthal, J. A. (1996). Qualitative descriptors of strength of association and effect size. *Journal of Social Service Research, 21*(4), 37–59. https://doi.org/10.1300/J079v21n04_02
    
    Wuensch, K. (2009). Cohen’s conventions for small, medium, and large effects. https://imaging.mrc-cbu.cam.ac.uk/statswiki/FAQ/effectSize?action=AttachFile&do=get&target=esize.doc
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> th_odds_ratio(5.23)
      classification                   reference
    0       moderate  Chen et al. (2010, p. 862)

    '''
    if (odrat < 1):
        odrat = 1/odrat
        
    #Chen et al. (2010, p. 862).
    if (qual=="chen"):
        src = "Chen et al. (2010, p. 862)"
        if (abs(odrat) < 1.68): qual = "negligible"
        elif (abs(odrat) < 3.47): qual = "weak"
        elif (abs(odrat) < 6.71): qual = "moderate"
        else: qual = "strong"
    
    #Hopkins (2006, tbl. 1).
    elif (qual=="hopkins"):
        src = "Hopkins (2006, tbl. 1)"
        if (abs(odrat) < 1.5) : qual = "trivial"
        elif (abs(odrat) < 3.5): qual = "small"
        elif (abs(odrat) < 9): qual = "moderate"
        elif (abs(odrat) < 32): qual = "large"
        elif (abs(odrat) < 360): qual = "very large"
        else: qual = "nearly perfect"
    
    #Jones (2014)
    elif (qual=="jones1"):
        src = "Jones (2014)"
        if (abs(odrat) < 1.5): qual = "negligible"
        elif (abs(odrat) < 2.5): qual = "small"
        elif (abs(odrat) < 4.3): qual = "medium"
        else: qual = "large"
    
    #Jones (2014)
    elif (qual=="jones2"):
        src = "Jones (2014)"
        if (abs(odrat) < 1.5): qual = "negligible"
        elif (abs(odrat) < 3.5): qual = "small"
        elif (abs(odrat) < 9): qual = "medium"
        else: qual = "large"
    
    #Wuensch (2009, p. 2).
    elif (qual=="wuensch"):
        src = "Wuensch (2009, p. 2)"
        if (abs(odrat) < 1.49) : qual = "negligible"
        elif (abs(odrat) < 3.45): qual = "small"
        elif (abs(odrat) < 9): qual = "medium"
        else: qual = "large"

    #Rosenthal (1996, p. 51).
    elif (qual=="rosenthal"):
        src = "Rosenthal (1996, p. 51)"
        if (abs(odrat) < 1.50) : qual = "negligible"
        elif (abs(odrat) < 2.5): qual = "small"
        elif (abs(odrat) < 4): qual = "medium"
        elif (abs(odrat) < 10): qual = "large"
        else: qual = "very large"
        
    results = pd.DataFrame([[qual, src]], columns=["classification", "reference"])
    
    return(results)

    
    
    
    