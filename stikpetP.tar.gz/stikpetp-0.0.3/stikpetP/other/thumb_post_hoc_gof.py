import pandas as pd
from ..other.thumb_cohen_g import th_cohen_g
from ..other.thumb_cohen_h import th_cohen_h
from ..other.thumb_cohen_w import th_cohen_w
from ..other.thumb_cramer_v import th_cramer_v
from ..other.thumb_pearson_r import th_pearson_r
from ..effect_sizes.convert_es import es_convert

def th_post_hoc_gof(eff_sizes, convert=False, ph_results=None, **kwargs):
    '''
    Post-Hoc Goodness-of-Fit Rules-of-Thumb
    ---------------------------------------
    This function will add a classification to the results of **es_post_hoc_gof()** using a rules-of-thumb. This is frowned upon by some, and the rule-of-thumb can vary per discipline.
    
    Parameters
    ----------
    eff_sizes : dataframe
        the dataframe from es_post_hoc_gof()
    convert : boolean, optional
        convert the effect size to use the rule-of-thumb from another, see details
    ph_results : dataframe, optional 
        the post-hoc analysis results, required for JBM-E and Fei.
    **kwargs : optional
        additional arguments for the specific rule-of-thumb that are passed along. Most common 'qual=...' for a specific set of rules-of-thumb.

    Returns
    -------
    pandas.DataFrame
        A dataframe with the following columns:
    
        * The same dataframe as the provided *eff_sizes*, but added:
        * *qualification*, the qualification using the rule-of-thumb.
        * *reference*, a reference to the source for the rule-of-thumb.
        
        * If a conversion was done or needed:
        * *conversion description*, the value of the converted measure

    Notes
    -----
    For Johnston-Berry-Mielke E and Fei, a conversion is always done to Cramér V, when setting *convert=True* it will convert it again to Cohen w.
    Other possible conversions are Cohen h' to Cohen h, and Cramér V to Cohen w.

    See the separate documentation for each of the rules-of-thumb, or conversion.
    
    Before, After and Alternatives
    ------------------------------
    Before using this the post-hoc effect sizes need to be made:
    * [es_post_hoc_gof](../effect_sizes/eff_size_post_hoc_gof.html#es_post_hoc_gof) to obtain post-hoc effect sizes
    
    Depending on the measure, the function will use the rules of thumb for:
    * [th_cohen_g](../other/thumb_cohen_g.html#th_cohen_g) for Cohen g
    * [th_cohen_h](../other/thumb_cohen_h.html#th_cohen_h) for Cohen h
    * [th_cohen_w](../other/thumb_cohen_w.html#th_cohen_w) for Cohen w
    * [th_cramer_v](../other/thumb_cramer_v.html#th_cramer_v) for Cramer V
    * [th_pearson_r](../other/thumb_pearson_r.html#th_pearson_r) for Pearson r

    It can also convert using:
    * [es_convert](../effect_sizes/convert_es.html#es_convert) to convert various effect sizes
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    df = eff_sizes
    qs = []
    rs = []
    conv = []

    if 'Cohen h' in df.columns and convert:
        conv_lbl = 'Cohen h_2 to Cohen h'
    elif 'Cohen w' in df.columns and convert:
        conv_lbl = 'Cohen w to Cramér V'
    elif 'Cramér V' in df.columns and convert:
        conv_lbl = 'Cramér V to Cohen w'
    elif 'Johnston-Berry-Mielke E' in df.columns:
        if convert:
            conv_lbl = 'JBM-E to Cramér V'
        else:
            conv_lbl = 'JBM-E to Cohen w'
    elif 'Fei' in df.columns:
        if convert:
            conv_lbl = 'Fei to Cramér V'
        else:
            conv_lbl = 'Fei to Cohen w'
    else:
        conv_lbl="none"
        
    if df.iloc[0, len(df.columns)-1] == 'not possible with this post-hoc test':
        df = 'no effect size values found'
    else:
        for i in range(0, len(df)):
        
            if 'Cohen g' in df.columns:
                q = th_cohen_g(df['Cohen g'][i], **kwargs)
                
            elif 'Cohen h' in df.columns:
                if convert:
                    cohenH = es_convert(df['Cohen h'][i], fr= "cohenhos", to = "cohenh")
                    q = th_cohen_h(cohenH, **kwargs)
                    conv_val = cohenH
                else:
                    q = th_cohen_h(df['Cohen h'][i], **kwargs)
                
            elif 'Cohen w' in df.columns:
                if convert:
                    cramerV = es_convert(df['Cohen w'][i], fr="cohenw", to="cramervgof", ex1=2)
                    q = th_cramer_v(cramerV, **kwargs)
                    conv_val = cramerV                
                else:
                    q = th_cohen_w(df['Cohen w'][i], **kwargs)
                    
            elif 'Cramér V' in df.columns:
                if convert:
                    cohenW = es_convert(df['Cramér V'][i], fr="cramervgof", to="cohenw", ex1=2)
                    q = th_cohen_w(cohenW, **kwargs)
                    conv_val = cohenW                
                else:
                    q = th_cramer_v(df['Cramér V'][i], **kwargs)
                    
            elif 'Johnston-Berry-Mielke E' in df.columns:
                if ph_results is None:
                    q = 'need post-hoc resulst'
                else:
                    if 'n1' in ph_results.columns:
                        n = ph_results['n1'][i] + ph_results['n2'][i]
                    else:
                        n = sum(ph_results['obs. count'])
                    cohenW = es_convert(df['Johnston-Berry-Mielke E'][i], fr="jbme", to="cohenw", ex1=ph_results.iloc[i,7]/n)
                    if convert:
                        cramerV = es_convert(cohenW, fr="cohenw", to="cramervgof", ex1=2)
                        q = th_cramer_v(cramerV, **kwargs)
                        conv_val = cramerV                    
                    else:
                        q = th_cohen_w(cohenW, **kwargs)
                        conv_val = cohenW
            elif 'Fei' in df.columns:
                if ph_results is None:
                    q = 'need post-hoc resulst'
                else:
                    if 'n1' in ph_results.columns:
                        n = ph_results['n1'][i] + ph_results['n2'][i]
                    else:
                        n = sum(ph_results['obs. count'])
                        
                    cohenW = es_convert(df['Fei'][i], fr="fei", to="cohenw", ex1=ph_results.iloc[i,7]/n)
                    
                    if convert:
                        cramerV = es_convert(cohenW, fr="cohenw", to="cramervgof", ex1=2)
                        q = th_cramer_v(cramerV, **kwargs)
                        conv_val = cramerV                    
                    else:
                        q = th_cohen_w(cohenW, **kwargs)
                        conv_val = cohenW
                    
            elif 'Rosenthal correlation' in df.columns:
                q = th_pearson_r(df['Rosenthal correlation'][i], **kwargs)
                
            elif 'alternative ratio' in df.columns:
                q = 'no rules-of-thumb available'
    
            if isinstance(q, pd.DataFrame):
                qs.append(q.iloc[0,0])
                rs.append(q.iloc[0,1])
                if conv_lbl != "none":
                    conv.append(conv_val)
            else:
                qs.append(q)
                rs.append('n.a.')
                conv.append('n.a.')
    
        if conv_lbl != "none":
            df[conv_lbl] = conv
        df['qualification'] = qs
        df['reference'] = rs
    
    
    return df