import pandas as pd
from statistics import NormalDist
from ..tests.test_binomial_os import ts_binomial_os
from ..tests.test_wald_os import ts_wald_os
from ..tests.test_score_os import ts_score_os
from ..other.p_adjustments import p_adjust

def ph_residual_gof_bin(data, test="std-residual", expCount=None, mtc='bonferroni', **kwargs):
    '''
    Post-Hoc Residuals Goodness-of-Fit Test
    ----------------------------------------
    
    This function will perform a residuals post-hoc test for each of the categories in a nominal field. This could either be a z-test using the standardized residuals, the adjusted residuals, or any of the one-sample binary tests.

    The unadjusted p-values and Bonferroni adjusted p-values are both determined.
    
    Parameters
    ----------
    data : list or pandas series
    test : {"adj-residual", "std-residual", "binomial", "wald", "score"}, optional 
        test to use
    expCount : pandas dataframe, optional 
        categories and expected counts
    mtc : string, optional
        any of the methods available in p_adjust() to correct for multiple tests
    **kwargs : optional
        additional arguments for the specific test that are passed along.
    
    Returns
    -------
    results : pandas dataframe with:
    
    * *category*, the label of the category
    * *obs. count*, the observed count
    * *exp. count*, the expected count
    * *z-statistic*, the standardized residuals
    * *p-value*, the unadjusted significance
    * *adj. p-value*, the adjusted significance
    * *test*, description of the test used.

    Notes
    -----
    The formula used is for the adjusted residual test:
    $$z = \\frac{F_i - E_i}{\\sqrt{E_i\\times\\left(1 - \\frac{E_i}{n}\\right)}}$$
    $$sig = 2\\times\\left(1 - \\Phi\\left(\\left|z\\right|\\right)\\right)$$
    
    The formula used is for the standardized residual test:
    $$z = \\frac{F_i - E_i}{\\sqrt{E_i}}$$
    $$sig = 2\\times\\left(1 - \\Phi\\left(\\left|z\\right|\\right)\\right)$$
    
    With:
    * $F_i$, the observed count for category $i$
    * $E_i$, the expected count for category $i$
    * $\\Phi\\left(\\dots\\right)$, the cumulative distribution function of the standard normal distribution

    If no expected counts are provide it is assumed they are all equal for each category, i.e. $E_i = \\frac{n}{k}$
    
    The Bonferroni adjustment is calculated using:
    $$p_{adj} = \\min \\left(p \\times k, 1\\right)$$

    The other tests use the formula from the one-sample test variant, using the expected count/n as the expected proportion.

    The adjusted residuals will gave the same result as using a one-sample score test. Some sources will also call these adjusted residuals as standardized residuals (Agresti, 2007, p. 38), and the standardized residuals used in this function as Pearson residuals (R, n.d.). Haberman (1973, p. 205) and Sharpe (2015, p. 3) are sources for the terminology used in this function. 

    See Also
    --------
    stikpetP.tests.test_binomial_os.ts_binomial_os : more info on the one-sample binomial test
    stikpetP.tests.test_wald_os.ts_wald_os : more info on the one-sample Wald test
    stikpetP.tests.test_score_os.ts_score_os : more info on the one-sample score test
    stikpetP.other.p_adjustments.p_adjust
    
    References
    ----------
    Agresti, A. (2007). *An introduction to categorical data analysis* (2nd ed.). Wiley-Interscience.
    Haberman, S. J. (1973). The analysis of residuals in cross-classified tables. *Biometrics, 29*(1), 205–220. doi:10.2307/2529686
    R. (n.d.). Chisq.test [Computer software]. https://stat.ethz.ch/R-manual/R-devel/library/stats/html/chisq.test.html
    Sharpe, D. (2015). Your chi-square test is statistically significant: Now what? Practical Assessment, *Research & Evaluation, 20*(8), 1–10.
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    if type(data) is list:
        data = pd.Series(data)
            
    freq = data.value_counts()
        
    if expCount is None:
        #assume all to be equal
        n = sum(freq)
        k = len(freq)
        categories = list(freq.index)
        expC = [n/k] * k
        
    else:
        #check if categories match
        nE = 0
        n = 0
        for i in range(0, len(expCount)):
            nE = nE + expCount.iloc[i,1]
            n = n + freq[expCount.iloc[i,0]]
        
        expC = []
        for i in range(0,len(expCount)):
            expC.append(expCount.iloc[i, 1]/nE*n)
            
        k = len(expC)
        categories = list(expCount.iloc[:,0])
    
    results = pd.DataFrame()
    resRow=0
    for i in range(0, k):
        cat = categories[i]
        n1 = freq[categories[i]]
        e1 = expC[i]
        if test=="std-residual":
            statistic = (n1 - e1)/(e1**0.5)
            sig = 2 * (1 - NormalDist().cdf(abs(statistic))) 
            test_description = "standardized residuals z-test"
        elif test=="adj-residual":
            statistic = (n1 - e1)/((e1*(1 - e1/n))**0.5)
            sig = 2 * (1 - NormalDist().cdf(abs(statistic))) 
            test_description = "adjusted residuals z-test"
        else:
            tempA = ['A']*n1
            tempB = ['B']*(n - n1)
            temp_data = tempA + tempB
            if test=="binomial":
                test_result = ts_binomial_os(temp_data, codes=['A', 'B'], p0=e1/n, **kwargs)
                statistic = "n.a."
                sig = test_result.iloc[0, 0]
                test_description = test_result.iloc[0, 1]
            else:
                if test=="wald":
                    test_result = ts_wald_os(temp_data, codes=['A', 'B'], p0=e1/n, **kwargs)
                elif test=="score":
                    test_result = ts_score_os(temp_data, codes=['A', 'B'], p0=e1/n, **kwargs)
    
                statistic = test_result.iloc[0, 1]
                sig = test_result.iloc[0, 2]
                test_description = test_result.iloc[0, 3]
        
                
        results.at[i, 0] = cat
        results.at[i, 1] = n1
        results.at[i, 2] = e1
        results.at[i, 3] = statistic
        results.at[i, 4] = sig
        results.at[i, 5] = sig
        results.at[i, 6] = test_description

    results.iloc[:,5] = p_adjust(results.iloc[:,4], method=mtc, **kwargs)
    results.columns = ["category", "obs. count", "exp. count", "z-statistic", "p-value", "adj. p-value", "test"]
    
    return results