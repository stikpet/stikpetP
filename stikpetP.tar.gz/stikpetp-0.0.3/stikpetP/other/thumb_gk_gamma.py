import pandas as pd

def th_gk_gamma(g, qual="blaikie"):
    '''
    Rules of Thumb for Goodman-Kruskal gamma
    --------------------------
     
    This function will give a qualification (classification) for Goodman-Kruskal gamma
    
    Parameters
    ----------
    g : float
        the Goodman-Kruskal gamma value
    qual : {"blaikie", "rea-parker", "metsamuuronen"} optional 
        the rule of thumb to be used. Default is "blaikie"
        
    Returns
    -------
    pandas.DataFrame
        A dataframe with the following columns:
    
        * *classification*, the qualification of the effect size
        * *reference*, a reference for the rule of thumb used
   
    Notes
    -----
    The following rules-of-thumb can be used:
    
    *"blaikie"* => Uses Blaikie (2003, p. 100):
    
    |\\|g\\|| Interpretation|
    |---|----------|
    |0.00 < 0.10 | negligible |
    |0.10 < 0.30 | weak |
    |0.30 < 0.60 | moderate |
    |0.60 < 0.75 | strong |
    |0.75 or more | very strong |

    *"rea-parker"* => Rea and Parker (2014, p. 229):
    
    |\\|g\\|| Interpretation|
    |---|----------|
    |0.00 < 0.10 | negligible |
    |0.10 < 0.30 | low |
    |0.30 < 0.60 | moderate |
    |0.60 < 0.75 | strong |
    |0.75 or more | very strong |
    
    *"metsamuuronen"* => Metsämuuronen (2023, p. 17):
    
    |\\|g\\|| Interpretation|
    |---|----------|
    |0.00 < 0.14 | negligible |
    |0.14 < 0.31 | small |
    |0.31 < 0.45 | medium |
    |0.45 < 0.62 | large |
    |0.62 < 0.84 | very large |
    |0.84 or more | huge |
        
    References
    ----------
    Blaikie, N. W. H. (2003). *Analyzing quantitative data: From description to explanation*. Sage Publications Ltd.
    
    Metsämuuronen, J. (2023). Somers’ delta as a basis for nonparametric effect sizes: Grissom-Kim PS, Cliff’s d, and Vargha-Delaney A as specific cases of Somers delta. doi:10.13140/RG.2.2.36002.09925
    
    Rea, L. M., & Parker, R. A. (2014). *Designing and conducting survey research: A comprehensive guide* (4th ed.). Jossey-Bass, a Wiley brand.
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
            
    #Blaikie (2003, p. 100)
    if (qual=="blaikie"):
        ref = "Blaikie (2003, p. 100)"
        if (abs(g) < 0.1):
            qual = "negligible"
        elif (abs(g) < 0.3):
            qual = "weak"
        elif (abs(g) < 0.6):
            qual = "moderate"
        elif (abs(g) < 0.75):
            qual = "strong"
        else:
            qual = "very strong"

    elif (qual=="rea-parker"):
        ref = "Rea and Parker (2014, p. 229)"
        if (abs(g) < 0.1):
            qual = "negligible"
        elif (abs(g) < 0.3):
            qual = "low"
        elif (abs(g) < 0.6):
            qual = "moderate"
        elif (abs(g) < 0.75):
            qual = "strong"
        else:
            qual = "very strong"
            
    #Metsämuuronen (2023, p. 17).
    elif (qual=="metsamuuronen"):
        ref = "Metsämuuronen (2023, p. 17)"
        if (abs(g) < 0.14):
            qual = "negligible"
        elif (abs(g) < 0.31):
            qual = "small"
        elif (abs(g) < 0.45):
            qual = "medium"
        elif (abs(g) < 0.62):
            qual = "large"
        elif (abs(g) < 0.84):
            qual = "very large"
        else:
            qual = "huge"
    
    results = pd.DataFrame([[qual, ref]], columns=["classification", "reference"])
    
    return results