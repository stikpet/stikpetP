import pandas as pd
from statistics import NormalDist

def ph_residual_gof(data, expCount=None):
    '''
    Post-Hoc Residuals Goodness-of-Fit Test
    ----------------------------------------
    
    This function will perform a standardized residuals post-hoc test for each of the categories in a nominal field.

    The unadjusted p-values and Bonferroni adjusted p-values are both determined.
    
    Parameters
    ----------
    data : list or pandas series
    expCount : pandas dataframe, optional 
        categories and expected counts
    
    Returns
    -------
    results : pandas dataframe with:
    
    * *category*, the label of the category
    * *z-statistic*, the standardized residuals
    * *p-value*, the unadjusted significance
    * *adj. p-value*, the adjusted significance

    Notes
    -----
    The formula used is:
    $$z = \\frac{F_i - E_i}{\\sqrt{E_i}}$$
    $$sig = 2\\times\\left(1 - \\Phi\\left(\\left|z\\right|\\right)\\right)$$
    
    With:
    * $F_i$, the observed count for category $i$
    * $E_i$, the expected count for category $i$
    * $\\Phi\\left(\\dots\\right)$, the cumulative distribution function of the standard normal distribution

    If no expected counts are provide it is assumed they are all equal for each category, i.e. $E_i = \\frac{n}{k}$
    
    The Bonferroni adjustment is calculated using:
    $$p_{adj} = \\min \\left(p \\times k, 1\\right)$$
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    if type(data) is list:
        data = pd.Series(data)
            
    freq = data.value_counts()
        
    if expCount is None:
        #assume all to be equal
        n = sum(freq)
        k = len(freq)
        categories = list(freq.index)
        expC = [n/k] * k
        
    else:
        #check if categories match
        nE = 0
        n = 0
        for i in range(0, len(expCount)):
            nE = nE + expCount.iloc[i,1]
            n = n + freq[expCount.iloc[i,0]]
        
        expC = []
        for i in range(0,len(expCount)):
            expC.append(expCount.iloc[i, 1]/nE*n)
            
        k = len(expC)
        categories = list(expCount.iloc[:,0])
    
    results = pd.DataFrame()
    resRow=0
    for i in range(0, k):
        z = (freq[categories[i]] - expC[i])/(expC[i]**0.5)
        sig = 2 * (1 - NormalDist().cdf(abs(z))) 
        adj_sig = min(sig*k, 1)
        results.at[i, 0] = categories[i]
        results.at[i, 1] = z
        results.at[i, 2] = sig
        results.at[i, 3] = adj_sig
        
    results.columns = ["category", "z-statistic", "p-value", "adj. p-value"]
    
    return results