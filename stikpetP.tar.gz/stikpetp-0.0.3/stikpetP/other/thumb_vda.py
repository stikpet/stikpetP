import pandas as pd

def th_vda(a, qual="vargha"):
    '''
    Rules of Thumb for Vargha-Delaney A
    --------------------------
     
    This function will give a qualification (classification) for Vargha-Delaney A
    
    Parameters
    ----------
    a : float
        the Vargha-Delaney A value
    qual : {"vargha"} optional 
        the rule of thumb to be used. Currently only "vargha"
        
    Returns
    -------
    pandas.DataFrame
        A dataframe with the following columns:
    
        * *classification*, the qualification of the effect size
        * *reference*, a reference for the rule of thumb used
   
    Notes
    -----
    The following rules-of-thumb can be used:
    
    *"vargha"* => Uses Vargha and Delaney (2000, p. 106):
    
    |\\|0.5 - A\\|| Interpretation|
    |---|----------|
    |0.00 < 0.06 | negligible |
    |0.06 < 0.14 | small |
    |0.14 < 0.21 | medium |
    |0.21 or more | large |
    
    References
    ----------
    Vargha, A., & Delaney, H. D. (2000). A critique and improvement of the CL common language effect size statistics of McGraw and Wong. *Journal of Educational and Behavioral Statistics, 25*(2), 101–132. doi:10.3102/10769986025002101
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
            
    #Vargha and Delaney (2000, p. 106)
    if (qual=="vargha"):
        ref = "Vargha and Delaney (2000, p. 106)"
        if (abs(0.5 - a) < 0.06):
            qual = "negligible"
        elif (abs(0.5 - a) < 0.14):
            qual = "small"
        elif (abs(0.5 - a) < 0.21):
            qual = "medium"
        else:
            qual = "large"
    
    results = pd.DataFrame([[qual, ref]], columns=["classification", "reference"])
    
    return results