import pandas as pd
from ..effect_sizes.convert_es import es_convert
from ..other.thumb_cohen_d import th_cohen_d
from ..other.thumb_gk_gamma import th_gk_gamma
from ..other.thumb_somers_d import th_somers_d
from ..other.thumb_cliff_delta import th_cliff_delta

def th_rank_biserial(rb, version="glass", qual=None, convert="no"):
    '''
    Rule of thumb for Rank Biserial Correlation
    --------------------------
    
    Simple function to use a rule-of-thumb for the Rank Biserial Correlation.

    This function is shown in this [YouTube video](https://youtu.be/Tx4wJxuh5AM) and the measure is also described at [PeterStatistics.com](https://peterstatistics.com/Terms/Correlations/RankBiserialCorrelation.html)
    
    Parameters
    ----------
    rb : float
        the rank-biserial correlation value
    version : {"glass", "cureton"}, optional
        version of rank-biserial that was used
    qual : see notes, optional 
        indication which set of rule-of-thumb to use. 
    convert : {"no", "cohen_d", "vda"}, optional
        conversion to use (only for Glass version)
    
    Returns
    -------
    pandas.DataFrame
        A dataframe with the following columns:
    
        * *classification*, the qualification of the effect size
        * *reference*, a reference for the rule of thumb used

    Notes
    -----
    If a Cureton version of rank-biserial was used, the result for independent samples is the same as Goodman-Kruskal gamma, so we can also use those rules-of-thumb.

    If a Glass version is used, then we can either use Cliff Delta, Somers d, or a conversion to either Cohen d, or Vargha-Delaney A.

    See the separate functions on each of these for various rules-of-thumbs.
    
    Before, After and Alternatives
    ------------------------------
    Before this you might want to obtain the measure:
    * [r_rank_biserial_os](../correlations/cor_rank_biserial_os.html#r_rank_biserial_os) to determine a the rank biserial for one-sample
    * [r_rank_biserial_is](../correlations/r_rank_biserial_is.html#r_rank_biserial_is) to determine a the rank biserial for independent samples

    The function uses the convert function and corresponding rules of thumb:
    * [es_convert](../effect_sizes/convert_es.html#es_convert) for the conversions
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076

    '''
    if version == 'cureton':
        if qual is None:
            qual = "blaikie"
        results = th_gk_gamma(rb, qual)

    elif version=='glass':
        if convert == "cohen_d":
            if qual is None:
                qual = "sawilowsky"
            d = es_convert(rb, "rb", "cohend")
            results = th_cohen_d(d, qual)
        elif convert == "vda" or convert == "cles":
            if qual is None:
                qual = "vargha"
            vda = es_convert(rb, "rb", "cle")
            results = th_cle(vda, qual)
        else:
            if qual == "metsamuuronen-somers":
                results = th_somers_d(rb, "metsamuuronen")
            else:
                if qual is None:
                    qual = "romano"
                results = th_cliff_delta(rb, qual)
    
    return(results)