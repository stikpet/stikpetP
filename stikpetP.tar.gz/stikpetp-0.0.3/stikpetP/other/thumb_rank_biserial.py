import pandas as pd
from ..effect_sizes.convert_es import es_convert
from ..other.thumb_cohen_d import th_cohen_d

def th_rank_biserial(rb, qual="cohen"):
    '''
    Rule of thumb for Rank Biserial Correlation
    --------------------------
    
    Simple function to use a rule-of-thumb for the Rank Biserial Correlation.
    
    Parameters
    ----------
    rb : float
        the rank-biserial correlation value
    qual : {"cohen", "vd", "sawilowsky", "cohen-conv", "lovakov", "rosenthal"}, optional 
        indication which set of rule-of-thumb to use. 
    
    Returns
    -------
    results : a pandas dataframe with.
    
    * *classification*, the qualification of the effect size
    * *reference*, a reference for the rule of thumb used
    
    Notes
    -----
    Cohen's rule of thumb for rank biserial (1988, p. 82):
    
    |\\|r_b\\|| Interpretation|
    |---|----------|
    |0.00 < 0.125 | negligible |
    |0.125 < 0.304 | small |
    |0.304 < 0.465 | medium |
    |0.465 or more | large |

    Vargha and Delaney (2000, p. 106):
    
    |\\|r_b\\|| Interpretation|
    |---|----------|
    |0.00 < 0.11 | negligible |
    |0.11 < 0.28 | small |
    |0.28 < 0.43 | medium |
    |0.43 or more | large |

    Other options are available by converting the rank biserial to Cohen d.
    
    
    See Also
    --------
    stikpetP.correlations.cor_rank_biserial_is.r_rank_biserial_is : to determine a the rank biserial for independent samples
    
    stikpetP.correlations.cor_rank_biserial_os.r_rank_biserial_os : to determine a the rank biserial for one-sample
    
    stikpetP.effect_sizes.convert_es.es_convert : to convert this to Cohen d

    stikpetP.other.thumb_cohen_d.th_cohen_d : rules of thumb for Cohen d
    
    References
    ----------
    Cohen, J. (1988). *Statistical power analysis for the behavioral sciences* (2nd ed.). L. Erlbaum Associates.

    Vargha, A., & Delaney, H. D. (2000). A critique and improvement of the CL common language effect size statistics of McGraw and Wong. *Journal of Educational and Behavioral Statistics, 25*(2), 101–132. doi:10.3102/10769986025002101
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    
    if (qual=="cohen"):
        ref = "Cohen (1988, p. 82)"
    
        if (abs(rb)<0.125):
            qual = "negligible"
        elif (abs(rb)<0.304):
            qual = "small"
        elif (abs(rb)<0.465):
            qual = "medium"
        else:
            qual = "large"

    elif (qual=="vd"):
        ref = "Vargha and Delaney (2000, p. 106)"
    
        if (abs(rb)<0.11):
            qual = "negligible"
        elif (abs(rb)<0.28):
            qual = "small"
        elif (abs(rb)<0.43):
            qual = "medium"
        else:
            qual = "large"

    elif (qual in ["sawilowsky", "cohen-conv", "lovakov", "rosenthal"]):
        if qual=="cohen-conv":
            qual="cohen"
        #convert to Cohen's d
        d = es_convert(rb, fr="rb", to="cohend")

        res = th_cohen_d(d, qual)
        qual = res["classification"][0]
        ref = res["reference"][0]
    
    results = pd.DataFrame([[qual, ref]], columns=["classification", "reference"])
    
    return(results)