import pandas as pd
from ..effect_sizes.convert_es import es_convert
from ..other.thumb_cohen_d import th_cohen_d

def th_rank_biserial(rb, qual="cohen"):
    '''
    Rule of thumb for Rank Biserial Correlation
    --------------------------
    
    Simple function to use a rule-of-thumb for the Rank Biserial Correlation.

    This function is shown in this [YouTube video](https://youtu.be/Tx4wJxuh5AM) and the measure is also described at [PeterStatistics.com](https://peterstatistics.com/Terms/Correlations/RankBiserialCorrelation.html)
    
    Parameters
    ----------
    rb : float
        the rank-biserial correlation value
    qual : {"cohen", "vd", "sawilowsky", "cohen-conv", "lovakov", "rosenthal", "brydges"}, optional 
        indication which set of rule-of-thumb to use. 
    
    Returns
    -------
    pandas.DataFrame
        A dataframe with the following columns:
    
        * *classification*, the qualification of the effect size
        * *reference*, a reference for the rule of thumb used
    
    Notes
    -----
    Cohen's rule of thumb for rank biserial (1988, p. 82):
    
    |\\|r_b\\|| Interpretation|
    |---|----------|
    |0.00 < 0.125 | negligible |
    |0.125 < 0.304 | small |
    |0.304 < 0.465 | medium |
    |0.465 or more | large |

    Vargha and Delaney (2000, p. 106):
    
    |\\|r_b\\|| Interpretation|
    |---|----------|
    |0.00 < 0.11 | negligible |
    |0.11 < 0.28 | small |
    |0.28 < 0.43 | medium |
    |0.43 or more | large |

    Other options are available by converting the rank biserial to Cohen d.

    Before, After and Alternatives
    ------------------------------
    Before this you might want to obtain the measure:
    * [r_rank_biserial_os](../correlations/cor_rank_biserial_os.html#r_rank_biserial_os) to determine a the rank biserial for one-sample
    * [r_rank_biserial_is](../correlations/r_rank_biserial_is.html#r_rank_biserial_is) to determine a the rank biserial for independent samples

    The function uses the convert function and corresponding rules of thumb:
    * [es_convert](../effect_sizes/convert_es.html#es_convert) for the conversions
    
    References
    ----------
    Cohen, J. (1988). *Statistical power analysis for the behavioral sciences* (2nd ed.). L. Erlbaum Associates.

    Vargha, A., & Delaney, H. D. (2000). A critique and improvement of the CL common language effect size statistics of McGraw and Wong. *Journal of Educational and Behavioral Statistics, 25*(2), 101–132. doi:10.3102/10769986025002101
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076

    Examples
    --------
    Example 1: using Cohen's rules:
    >>> rank_biserial = 0.23
    >>> th_rank_biserial(rank_biserial)
      classification            reference
    0          small  Cohen (1988, p. 82)

    Example 2: Convert to Cohen d, then use Cohen d rules:
    >>> rank_biserial = 0.23
    >>> th_rank_biserial(rank_biserial, qual="cohen-conv")
      classification            reference
    0          small  Cohen (1988, p. 40)

    
    '''
    
    if (qual=="cohen"):
        ref = "Cohen (1988, p. 82)"
    
        if (abs(rb)<0.125):
            qual = "negligible"
        elif (abs(rb)<0.304):
            qual = "small"
        elif (abs(rb)<0.465):
            qual = "medium"
        else:
            qual = "large"

    elif (qual=="vd"):
        ref = "Vargha and Delaney (2000, p. 106)"
    
        if (abs(rb)<0.11):
            qual = "negligible"
        elif (abs(rb)<0.28):
            qual = "small"
        elif (abs(rb)<0.43):
            qual = "medium"
        else:
            qual = "large"

    elif (qual in ["sawilowsky", "cohen-conv", "lovakov", "rosenthal", "brydges"]):
        if qual=="cohen-conv":
            qual="cohen"
        #convert to Cohen's d
        d = es_convert(rb, fr="rb", to="cohend")

        res = th_cohen_d(d, qual)
        qual = res["classification"][0]
        ref = res["reference"][0]
    
    results = pd.DataFrame([[qual, ref]], columns=["classification", "reference"])
    
    return(results)