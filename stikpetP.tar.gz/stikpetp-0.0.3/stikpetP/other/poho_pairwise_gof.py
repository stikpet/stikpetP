import pandas as pd
from ..tests.test_multinomial_gof import ts_multinomial_gof
from ..tests.test_powerdivergence_gof import ts_powerdivergence_gof
from ..tests.test_neyman_gof import ts_neyman_gof
from ..tests.test_mod_log_likelihood_gof import ts_mod_log_likelihood_gof
from ..tests.test_g_gof import ts_g_gof
from ..tests.test_freeman_tukey_read import ts_freeman_tukey_read
from ..tests.test_freeman_tukey_gof import ts_freeman_tukey_gof
from ..tests.test_pearson_gof import ts_pearson_gof
from ..other.p_adjustments import p_adjust


def ph_pairwise_gof(data, test="pearson", expCount=None, mtc='bonferroni', **kwargs):
    '''
    Pairwise Goodness-of-Fit Tests for Post-Hoc Analysis
    --------------------------------------------
    
    This function will perform a goodness-of-fit test for each possible pair in the data. This could be any of the goodness-of-fit tests, e.g. a Pearson chi-square.

    The unadjusted p-values and Bonferroni adjusted p-values are both determined.
    
    Parameters
    ----------
    data : list or pandas series
    test : {"pearson", "freeman-tukey", "freeman-tukey-read", "g", "mod-log-g", "neyman", "powerdivergence", "multinomial"}, optional
        test to use for each pair
    expCount : pandas dataframe, optional 
        categories and expected counts
    mtc : string, optional
        any of the methods available in p_adjust() to correct for multiple tests
    **kwargs : optional
        additional arguments for the specific test that are passed along.
    
    Returns
    -------
    results : pandas dataframe with:
    
    * *category 1*, the label of the first category
    * *category 2*, the label of the second category
    * *n1*, the sample size of the first category
    * *n2*, the sample size of the second category
    * *obs. prop. 1*, the proportion in the sample of the first category
    * *exp. prop. 1*, the expected proportion for the first category

    * *statistic*, the chi-square test statistic
    * *df*, the degrees of freedom or in case
    * *p-value*, the unadjusted significance
    * *adj. p-value*, the adjusted significance
    * *minExp*, the minimum expected count
    * *propBelow5*, the proportion of cells with an expected count below 5
    * *test*, description of the test used

    In case of a multinomial test, the same columns except:
    * *p obs* instead of *statistic*, showing the probability of the observed sample table
    * *n combs.*, instead of *df*, showing the number of possible tables
    * no *minExp* and *propBelow5* column.
    
    See Also
    --------
    stikpetP.tests.test_multinomial_gof.ts_multinomial_gof
    stikpetP.tests.test_powerdivergence_gof.ts_powerdivergence_gof
    stikpetP.tests.test_neyman_gof.ts_neyman_gof
    stikpetP.tests.test_mod_log_likelihood_gof.ts_mod_log_likelihood_gof
    stikpetP.tests.test_g_gof.ts_g_gof
    stikpetP.tests.test_freeman_tukey_read.ts_freeman_tukey_read
    stikpetP.tests.test_freeman_tukey_gof.ts_freeman_tukey_gof
    stikpetP.tests.test_pearson_gof.ts_pearson_gof
    stikpetP.other.p_adjustments.p_adjust
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    if type(data) is list:
        data = pd.Series(data)
            
    freq = data.value_counts()
        
    if expCount is None:
        #assume all to be equal
        n = sum(freq)
        k = len(freq)
        categories = list(freq.index)
        expC = [n/k] * k
        
    else:
        #check if categories match
        nE = 0
        n = 0
        for i in range(0, len(expCount)):
            nE = nE + expCount.iloc[i,1]
            n = n + freq[expCount.iloc[i,0]]
        
        expC = []
        for i in range(0,len(expCount)):
            expC.append(expCount.iloc[i, 1]/nE*n)
            
        k = len(expC)
        categories = list(expCount.iloc[:,0])
    
    n_pairs = int(k*(k-1)/2)

    results = pd.DataFrame()
    resRow=0
    for i in range(0, k-1):
        for j in range(i+1, k):
            #category names
            results.at[resRow, 0] = categories[i]
            results.at[resRow, 1] = categories[j]
            #category sizes
            n1 = freq[categories[i]]
            n2 = freq[categories[j]]
            results.at[resRow, 2] = n1
            results.at[resRow, 3] = n2
    
            #data and expected counts
            expected_proportion_1 = expC[i]/n
            expected_proportion_2 = expC[j]/n
            exp_count_1 = (n1 + n2)*(expected_proportion_1*1/(expected_proportion_1+expected_proportion_2))
            exp_count_2 = (n1 + n2)*(expected_proportion_2*1/(expected_proportion_1+expected_proportion_2))
            exP = pd.DataFrame([[categories[i], exp_count_1], [categories[j], exp_count_2]], columns=['category', 'exp count'])
            results.at[resRow, 4] = n1/(n1 + n2)
            results.at[resRow, 5] = exp_count_1/(n1 + n2)
            pair = [categories[i], categories[j]]
            data_pair = data[data.isin(pair)]
            
            if test=="pearson":                
                pair_test_result = ts_pearson_gof(data_pair, expCounts=exP, **kwargs)
            elif test=="freeman-tukey":
                pair_test_result = ts_freeman_tukey_gof(data_pair, expCounts=exP, **kwargs)
            elif test=="freeman-tukey-read":
                pair_test_result = ts_freeman_tukey_read(data_pair, expCounts=exP, **kwargs)
            elif test=="g":
                pair_test_result = ts_g_gof(data_pair, expCounts=exP, **kwargs)
            elif test=="mod-log-g":
                pair_test_result = ts_mod_log_likelihood_gof(data_pair, expCounts=exP, **kwargs)
            elif test=="neyman":
                pair_test_result = ts_neyman_gof(data_pair, expCounts=exP, **kwargs)
            elif test=="powerdivergence":
                pair_test_result = ts_powerdivergence_gof(data_pair, expCounts=exP, **kwargs)

            if test=="multinomial":
                pair_test_result = ts_multinomial_gof(data_pair, expCounts=exP, **kwargs)
                results.at[resRow, 6] = pair_test_result.iloc[0, 0]
                results.at[resRow, 7] = pair_test_result.iloc[0, 1]
                results.at[resRow, 8] = pair_test_result.iloc[0, 2]
                results.at[resRow, 9] = results.at[resRow, 8]
                results.at[resRow, 10] = pair_test_result.iloc[0, 3]
                
            else:
                results.at[resRow, 6] = pair_test_result.iloc[0, 2]
                results.at[resRow, 7] = pair_test_result.iloc[0, 3]
                results.at[resRow, 8] = pair_test_result.iloc[0, 4]
                results.at[resRow, 9] = results.at[resRow, 8]
                results.at[resRow, 10] = pair_test_result.iloc[0, 5]
                results.at[resRow, 11] = pair_test_result.iloc[0, 6]
                results.at[resRow, 12] = pair_test_result.iloc[0, 7]
              
            resRow = resRow + 1

    results.iloc[:,9] = p_adjust(results.iloc[:,8], method=mtc)
    
    if test == "multinomial":
        # Set columns for multinomial case
        results.columns = [
            "category 1", "category 2", "n1", "n2", "obs. prop. 1", "exp. prop. 1", "p obs", "n combs.",
            "p-value", "adj. p-value", "test"
        ]
    else:
        # Set columns for other cases
        results.columns = [
            "category 1", "category 2", "n1", "n2", "obs. prop. 1", "exp. prop. 1", "statistic", "df", 
            "p-value", "adj. p-value", "minExp", "propBelow5", "test"
        ]
    
    return results