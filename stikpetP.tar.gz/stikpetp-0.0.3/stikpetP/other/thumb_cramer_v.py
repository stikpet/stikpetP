import pandas as pd

def th_cramer_v(v, qual="rea-parker"):
    '''
    Rules of Thumb for Cramér V
    ---------------------------
     
    This function will give a qualification (classification) for Cramér V. Note however that many will actually use the rule-of-thumb for Cohen w and convert Cramér V to Cohen w first.

    The measure is also described at [PeterStatistics.com](https://peterstatistics.com/Terms/EffectSizes/CramerV.html)
    
    Parameters
    ----------
    v : float
        the Cramér V value
    qual : {"rea-parker", "akoglu", "calamba-rustico"} optional 
        the rule of thumb to be used. 
        
    Returns
    -------
    pandas.DataFrame
        A dataframe with the following columns:
    
        * *classification*, the qualification of the effect size
        * *reference*, a reference for the rule of thumb used
   
    Notes
    -----
    The following rules-of-thumb can be used:
    
    *"rea-parker"* => Uses Rea and Parker (1992, p. 203):
    
    |\\|v\\|| Interpretation|
    |---|----------|
    |0.00 < 0.10 | negligible |
    |0.10 < 0.20 | weak |
    |0.20 < 0.40 | moderate |
    |0.40 < 0.60 | relatively strong |
    |0.60 < 0.80 | strong |
    |0.80 or more | very strong |
    
    *"akoglu"* => Uses Akoglu (2018, p. 92):
    
    |\\|v\\|| Interpretation|
    |---|----------|
    |0.00 < 0.05 | very weak |
    |0.05 < 0.10 | weak |
    |0.10 < 0.15 | moderate |
    |0.15 < 0.25 | strong |
    |0.25 or more | very strong |
    
    *"calamba-rustico"* => Uses Calamba and Rustico (2019, p. 7):
    
    |\\|v\\|| Interpretation|
    |---|----------|
    |0.00 < 0.15 | very weak |
    |0.15 < 0.20 | weak |
    |0.20 < 0.25 | moderate |
    |0.25 < 0.30 | moderately strong |
    |0.30 < 0.35 | strong |
    |0.35 < 0.50 | worrisomely strong |    
    |0.50 or more | redundant |
    
    Note that the original source has a gap from 0.40 < 0.50, I added this to the 'worrisomely strong' category.

    Before, After and Alternatives
    ------------------------------
    Before using this function you need to obtain a Cramer v value:
    * [es_cramer_v_gof](../effect_sizes/eff_size_cramer_v_gof.html#es_cramer_v_gof) to obtain Cramer's V for Goodness-of-Fit
        
    References
    ----------
    Akoglu, H. (2018). User’s guide to correlation coefficients. *Turkish Journal of Emergency Medicine, 18*(3), 91–93. doi:10.1016/j.tjem.2018.08.001
    
    Calamba, S. S., & Rustico, E. M. P. (2019). Usefulness of code of ethics for professional accountants in resolving ethical conflicts in the Philippines.

    Rea, L. M., & Parker, R. A. (1992). *Designing and conducting survey research: A comprehensive guide*. Jossey-Bass Publishers.
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
            
    #Rea and Parker (1992, p. 203).
    if (qual=="rea-parker"):
        ref = "Rea and Parker (1992, p. 203)"
        if (abs(v) < 0.1):
            qual = "negligible"
        elif (abs(v) < 0.2):
            qual = "weak"
        elif (abs(v) < 0.4):
            qual = "moderate"
        elif (abs(v) < 0.6):
            qual = "relatively strong"
        elif (abs(v) < 0.8):
            qual = "strong"
        else:
            qual = "very strong"
    
    elif (qual=="akoglu"):
        ref = "Akoglu (2018, p. 92)"
        if (abs(v) < 0.05):
            qual = "very weak"
        elif (abs(v) < 0.1):
            qual = "weak"
        elif (abs(v) < 0.15):
            qual = "moderate"
        elif (abs(v) < 0.25):
            qual = "strong"
        else:
            qual = "very strong"
    
    elif (qual=="calamba-rustico"):
        ref = "Calamba and Rustico (2019, p. 7)"
        if (abs(v) < 0.15):
            qual = "very weak"
        elif (abs(v) < 0.20):
            qual = "weak"
        elif (abs(v) < 0.25):
            qual = "moderate"
        elif (abs(v) < 0.30):
            qual = "moderately strong"
        elif (abs(v) < 0.35):
            qual = "strong"
        elif (abs(v) < 0.50):
            qual = "worrisomely strong"    
        else:
            qual = "redundant"
    
    results = pd.DataFrame([[qual, ref]], columns=["classification", "reference"])
    
    return results