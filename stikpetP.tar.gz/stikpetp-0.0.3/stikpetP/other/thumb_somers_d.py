import pandas as pd

def th_somers_d(d, qual="metsamuuronen"):
    '''
    Rules of Thumb for Somers d
    --------------------------
     
    This function will give a qualification (classification) for Somers d
    
    Parameters
    ----------
    d : float
        the Somers d value
    qual : {"metsamuuronen"} optional 
        the rule of thumb to be used. Currently only "metsamuuronen"
        
    Returns
    -------
    pandas.DataFrame
        A dataframe with the following columns:
    
        * *classification*, the qualification of the effect size
        * *reference*, a reference for the rule of thumb used
   
    Notes
    -----
    The following rules-of-thumb can be used:
    
    *"metsamuuronen"* => Uses Metsämuuronen (2023, p. 17):
    
    |\\|d\\|| Interpretation|
    |---|----------|
    |0.00 < 0.13 | negligible |
    |0.13 < 0.29 | small |
    |0.29 < 0.43 | medium |
    |0.43 < 0.59 | large |
    |0.59 < 0.81 | very large |
    |0.81 or more | huge |
    
    References
    ----------
    Metsämuuronen, J. (2023). Somers’ delta as a basis for nonparametric effect sizes: Grissom-Kim PS, Cliff’s d, and Vargha-Delaney A as specific cases of Somers delta. doi:10.13140/RG.2.2.36002.09925
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
            
    #Metsämuuronen (2023, p. 17)
    if (qual=="metsamuuronen"):
        ref = "Metsämuuronen (2023, p. 17)"
        if (abs(d) < 0.13):
            qual = "negligible"
        elif (abs(d) < 0.29):
            qual = "small"
        elif (abs(d) < 0.43):
            qual = "medium"
        elif (abs(d) < 0.59):
            qual = "large"
        elif (abs(d) < 0.81):
            qual = "very large"
        else:
            qual = "huge"
    
    results = pd.DataFrame([[qual, ref]], columns=["classification", "reference"])
    
    return results