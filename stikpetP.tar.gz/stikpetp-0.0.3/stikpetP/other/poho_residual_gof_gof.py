import pandas as pd
from ..tests.test_multinomial_gof import ts_multinomial_gof
from ..tests.test_powerdivergence_gof import ts_powerdivergence_gof
from ..tests.test_neyman_gof import ts_neyman_gof
from ..tests.test_mod_log_likelihood_gof import ts_mod_log_likelihood_gof
from ..tests.test_g_gof import ts_g_gof
from ..tests.test_freeman_tukey_read import ts_freeman_tukey_read
from ..tests.test_freeman_tukey_gof import ts_freeman_tukey_gof
from ..tests.test_pearson_gof import ts_pearson_gof

def ph_residual_gof_gof(data, test="pearson", expCount=None, **kwargs):
    '''
    Post-Hoc Residuals Using GoF for GoF
    ----------------------------------------
    
    This function will perform a goodness-of-fit test using each category and collapsing the other categories.

    The unadjusted p-values and Bonferroni adjusted p-values are both determined.
    
    Parameters
    ----------
    data : list or pandas series
    test : {"pearson", "freeman-tukey", "freeman-tukey-read", "g", "mod-log-g", "neyman", "powerdivergence", "multinomial"}, optional 
        test to use
    expCount : pandas dataframe, optional 
        categories and expected counts
    **kwargs : optional
        additional arguments for the specific test that are passed along.
    
    Returns
    -------
    results : pandas dataframe with:
    
    * *category*, the label of the category
    * *obs. count*, the observed count
    * *exp. count*, the expected count
    * *statistic*, the chi-square test statistic
    * *df*, the degrees of freedom or in case
    * *p-value*, the unadjusted significance
    * *adj. p-value*, the adjusted significance
    * *minExp*, the minimum expected count
    * *propBelow5*, the proportion of cells with an expected count below 5
    * *test*, description of the test used

    In case of a multinomial test, the same columns except:
    * *p obs* instead of *statistic*, showing the probability of the observed sample table
    * *n combs.*, instead of *df*, showing the number of possible tables
    * no *minExp* and *propBelow5* column.

    See Also
    --------
    stikpetP.tests.test_multinomial_gof.ts_multinomial_gof
    stikpetP.tests.test_powerdivergence_gof.ts_powerdivergence_gof
    stikpetP.tests.test_neyman_gof.ts_neyman_gof
    stikpetP.tests.test_mod_log_likelihood_gof.ts_mod_log_likelihood_gof
    stikpetP.tests.test_g_gof.ts_g_gof
    stikpetP.tests.test_freeman_tukey_read.ts_freeman_tukey_read
    stikpetP.tests.test_freeman_tukey_gof.ts_freeman_tukey_gof
    stikpetP.tests.test_pearson_gof.ts_pearson_gof
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    if type(data) is list:
        data = pd.Series(data)
            
    freq = data.value_counts()
        
    if expCount is None:
        #assume all to be equal
        n = sum(freq)
        k = len(freq)
        categories = list(freq.index)
        expC = [n/k] * k
        
    else:
        #check if categories match
        nE = 0
        n = 0
        for i in range(0, len(expCount)):
            nE = nE + expCount.iloc[i,1]
            n = n + freq[expCount.iloc[i,0]]
        
        expC = []
        for i in range(0,len(expCount)):
            expC.append(expCount.iloc[i, 1]/nE*n)
            
        k = len(expC)
        categories = list(expCount.iloc[:,0])
    
    results = pd.DataFrame()
    resRow=0
    for i in range(0, k):
        cat = categories[i]
        results.at[resRow, 0] = cat
        
        n1 = freq[categories[i]]
        results.at[resRow, 2] = n1
        
        e1 = expC[i]
        results.at[resRow, 3] = e1
        tempA = ['A']*n1
        tempB = ['B']*(n - n1)
        temp_data = tempA + tempB
        exP = pd.DataFrame([['A', e1], ['B', n - e1]], columns=['category', 'exp count'])
        if test=="pearson":                
            pair_test_result = ts_pearson_gof(temp_data, expCounts=exP, **kwargs)
        elif test=="freeman-tukey":
            pair_test_result = ts_freeman_tukey_gof(temp_data, expCounts=exP, **kwargs)
        elif test=="freeman-tukey-read":
            pair_test_result = ts_freeman_tukey_read(temp_data, expCounts=exP, **kwargs)
        elif test=="g":
            pair_test_result = ts_g_gof(temp_data, expCounts=exP, **kwargs)
        elif test=="mod-log-g":
            pair_test_result = ts_mod_log_likelihood_gof(temp_data, expCounts=exP, **kwargs)
        elif test=="neyman":
            pair_test_result = ts_neyman_gof(temp_data, expCounts=exP, **kwargs)
        elif test=="powerdivergence":
            pair_test_result = ts_powerdivergence_gof(temp_data, expCounts=exP, **kwargs)

        if test=="multinomial":
            pair_test_result = ts_multinomial_gof(temp_data, expCounts=exP, **kwargs)
            results.at[resRow, 4] = pair_test_result.iloc[0, 0]
            results.at[resRow, 5] = pair_test_result.iloc[0, 1]
            results.at[resRow, 6] = pair_test_result.iloc[0, 2]
            results.at[resRow, 7] = results.at[resRow, 6]*k
            if results.at[resRow, 7] > 1:
                results.at[resRow, 7] = 1
            results.at[resRow, 8] = pair_test_result.iloc[0, 3]
            
        else:
            results.at[resRow, 4] = pair_test_result.iloc[0, 2]
            results.at[resRow, 5] = pair_test_result.iloc[0, 3]
            results.at[resRow, 6] = pair_test_result.iloc[0, 4]
            results.at[resRow, 7] = results.at[resRow, 6]*k
            if results.at[resRow, 7] > 1:
                results.at[resRow, 7] = 1
            results.at[resRow, 8] = pair_test_result.iloc[0, 5]
            results.at[resRow, 9] = pair_test_result.iloc[0, 6]
            results.at[resRow, 10] = pair_test_result.iloc[0, 7]
          
        resRow = resRow + 1

    if test == "multinomial":
        # Set columns for multinomial case
        results.columns = [
            "category", "obs. count", "exp. count", "p obs", "n combs.",
            "p-value", "adj. p-value", "test used"
        ]
    else:
        # Set columns for other cases
        results.columns = [
            "category", "obs. count", "exp. count", "statistic", "df", 
            "p-value", "adj. p-value", "minExp", "propBelow5", "test used"
        ]
    
    return results