def r_point_biserial(t, df):
    '''
    Point Biserial Correlation Coefficient
    --------------------------------------
    This can be seen as coding a binary variable with the groups into 0 and 1, and then calculates a Pearson correlation coefficient between the those values and the scores.
    
    This gives the same result as the formula used and as input the Student t-test statistic and corresponding degrees of freedom.
    
    Parameters
    ----------
    t : float
        the test statistic value
    df : float
        the degrees of freedom
        
    Returns
    -------
    Point Biserial Correlation Coefficient
    
    Notes
    -----
    The formula used is (Friedman, 1968, p. 245):
    $$r_{pb} = \\sqrt{\\frac{t^2}{t^2 + df}}$$
    
    *Symbols used:*
    \\(t\\) the test statistic of the independent samples Student t-test
    \\(df\\) the degrees of freedom of the independent samples Student t-test
    
    See Also
    --------
    stikpetP.tests.test_student_t_is.ts_student_t_is : Student t-test
    
    References
    ----------
    Friedman, H. (1968). Magnitude of experimental effect and a table for its rapid estimation. *Psychological Bulletin, 70*(4), 245–251. https://doi.org/10.1037/h0026258
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> r_point_biserial(0.9984, 1967)
    0.022505692363979552
    
    '''
    
    r = (t**2/(t**2 + df))**0.5
    return r