import pandas as pd
import matplotlib.pyplot as plt

def vi_bar_stacked_multiple(catField, ordField, levels=None, **kwargs):
    '''
    Multiple Stacked Bar-Chart
    --------------------------
    To visualise an ordinal variable, it often makes sense to stack the results. Stacking the results creates a compound bar chart, or sometimes stacked bar chart (Wilkinson, 2005, p. 157) or component bar chart (Zedeck, 2014, p. 54). It can be defined as: “a bar chart showing multiple bars stacked at each x-axis category, each representing a value of the stacking variable” (Upton & Cook, 2014, p. 88).
    
    Instead of one bar (see **vi_bar_stacked_single()**), we can create two or more (one for each group). This could then be considered a multiple compound bar-chart.
    
    Parameters
    ----------
    catField : list or dataframe 
        the categories
    ordField : list or dataframe 
        the scores
    levels : list or dictionary, optional
        the scores in order
    kwargs : other parameters from pandas plot()
        
    Returns
    -------
    multiple stacked bar-chart
    
    Notes
    -----
    This function is more like a wrapper for the **plot()** from pandas *plot* function.
    
    References
    ----------
    Upton, G., & Cook, I. (2014). *Oxford: Dictionary of statistics* (3rd ed.). Oxford University Press.
    
    Wilkinson, L. (2005). *The grammar of graphics* (2nd ed). Springer.
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    #convert to pandas series if needed
    if type(catField) is list:
        catField = pd.Series(catField)
    
    if type(ordField) is list:
        ordField = pd.Series(ordField)
    
    #replace the ordinal values if levels is provided
    if levels is not None:
        ordField = ordField.replace(levels)
    
    ct = pd.crosstab(catField, ordField)
    pct = ct.div(ct.sum(axis=1), axis=0)*100
    
    if levels is not None:
        pct.plot(kind="barh", stacked=True, **kwargs).legend(levels, bbox_to_anchor=(1.0, 1.0))
    else:
        pct.plot(kind="barh", stacked=True, **kwargs).legend(bbox_to_anchor=(1.0, 1.0))