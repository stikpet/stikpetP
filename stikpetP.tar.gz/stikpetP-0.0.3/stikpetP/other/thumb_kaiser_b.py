import pandas as pd

def th_kaiser_b(b, qual="kaiser"):
    '''
    Rule of thumb for Kaiser b
    --------------------------
    
    Simple function to use a rule-of-thumb for the Kaiser b variation measure.
    
    Parameters
    ----------
    b : float
        the Kaiser b value
    qual : {"kaiser"}, optional 
        indication which set of rule-of-thumb to use. Currently only "kaiser" (default)
    
    Returns
    -------
    results : a pandas dataframe with.
    
    * *classification*, the qualification of the effect size
    * *reference*, a reference for the rule of thumb used
    
    Notes
    -----
    Kaiser's rule of thumb for Kaiser b (1968, p. 212):
    
    |\\|b\\|| Interpretation|
    |---|----------|
    |0.00 < 0.70 | terrible |
    |0.70 < 0.80 | poor |
    |0.80 < 0.90 | fair |
    |0.90 < 0.95 | good |
    |0.95 < 1.00 | excellent |
    
    See Also
    --------
    stikpetP.measures.meas_qv.me_qv : to determine Kaiser b
    
    References
    ----------
    Kaiser, H. F. (1968). A measure of the population quality of legislative apportionment. *American Political Science Review, 62*(1), 208–215. doi:10.2307/1953335
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    
    if (qual=="kaiser"):
        ref = "Kaiser (1968, p. 212)"
    
    if (abs(b)<0.70):
        qual = "terrible"
    elif (abs(b)<0.80):
        qual = "poor"
    elif (abs(b)<0.90):
        qual = "fair"
    elif (abs(b)<0.95):
        qual = "good"
    else:
        qual = "excellent"
        
    results = pd.DataFrame([[qual, ref]], columns=["classification", "reference"])
    
    return(results)