import pandas as pd

def th_rank_biserial(rb, qual="cohen"):
    '''
    Rule of thumb for Rank Biserial Correlation
    --------------------------
    
    Simple function to use a rule-of-thumb for the Rank Biserial Correlation.
    
    Parameters
    ----------
    rb : float
        the rank-biserial correlation value
    qual : {"cohen"}, optional 
        indication which set of rule-of-thumb to use. Currently only "cohen" (default)
    
    Returns
    -------
    results : a pandas dataframe with.
    
    * *classification*, the qualification of the effect size
    * *reference*, a reference for the rule of thumb used
    
    Notes
    -----
    Cohen's rule of thumb for rank biserial (1988, p. 82):
    
    |\\|r_b\\|| Interpretation|
    |---|----------|
    |0.00 < 0.125 | negligible |
    |0.125 < 0.304 | small |
    |0.304 < 0.465 | medium |
    |0.465 or more | large |
    
    See Also
    --------
    stikpetP.correlations.cor_rank_biserial_is.r_rank_biserial_is : to determine a the rank biserial for independent samples
    stikpetP.correlations.cor_rank_biserial_os.r_rank_biserial_os : to determine a the rank biserial for one-sample
    
    References
    ----------
    Cohen, J. (1988). *Statistical power analysis for the behavioral sciences* (2nd ed.). L. Erlbaum Associates.
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    
    if (qual=="cohen"):
        ref = "Cohen (1988, p. 82)"
    
    if (abs(rb)<0.125):
        qual = "negligible"
    elif (abs(rb)<0.304):
        qual = "small"
    elif (abs(rb)<0.465):
        qual = "medium"
    else:
        qual = "large"
        
    results = pd.DataFrame([[qual, ref]], columns=["classification", "reference"])
    
    return(results)