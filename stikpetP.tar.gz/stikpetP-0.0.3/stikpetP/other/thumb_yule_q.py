import pandas as pd

def th_yule_q(q, qual="glen"):
    '''
    Rules of thumb for Yule Q
    -------------------------
    
    Simple function to use a rule-of-thumb for Yule Q effect size.
    
    Parameters
    ----------
    q : float
        the Yule q value
    qual : {"glen"}, optional 
        indication which set of rule-of-thumb to use. Currently only "glen" (default)
            
    Returns
    -------
    results : a pandas dataframe with.
    
    * *classification*, the qualification of the effect size
    * *reference*, a reference for the rule of thumb used
    
    Notes
    -----
    Glen rule of thumb for Yule Q (2017):
    
    |\\|Q\\|| Interpretation|
    |---|----------|
    |0.00 < 0.30 | negligible |
    |0.30 < 0.50 | moderate |
    |0.50 < 0.70 | substantial |
    |0.70 or more | very strong |
    
    See Also
    --------
    stikpetP.effect_sizes.eff_size_bin_bin.es_bin_bin : to determine a Yule Q
    
    References
    ----------
    Glen, S. (2017, August 16). Gamma Coefficient (Goodman and Kruskal’s Gamma) & Yule’s Q. Statistics How To. https://www.statisticshowto.com/gamma-coefficient-goodman-kruskal/
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    >>> es = 0.6
    >>> th_yule_q(es)
      classification    reference
    0    substantial  Glen (2017)
    
    '''
    
    if (qual=="glen"):
        ref = "Glen (2017)"
        if (abs(q)<0.29):
            qual = "very small"
        elif (abs(q)<0.49):
            qual = "moderate"
        elif (abs(q)<0.69):
            qual = "substantial"
        else:
            qual = "very strong"
    
    results = pd.DataFrame([[qual, ref]], columns=["classification", "reference"])
    return(results)
  