import pandas as pd
from ..other.table_cross import tab_cross
from ..tests.test_mood_median import ts_mood_median

def ph_mood_median(catField, ordField, categories=None, levels=None, test="pearson", cc=None, lambd=None):
    '''
    Post-Hoc Pairwise Mood-Median Test
    ----------------------------------
    This can be used as a post-hoc test for a Kruskal-Wallis test (see ts_kruskal_wallis()).
    
    The test compares each possible pair of categories from the catField and their mean rank. The null hypothesis is that these are then equal. A simple Bonferroni adjustment is also made for the multiple testing.
    
    Other post-hoc tests that could be considered are Dunn, Nemenyi, Steel-Dwass, Conover-Iman, or pairwise Mann-Whitney U test.
    
    
    Parameters
    ----------
    catField : pandas series
        data with categories
    ordField : pandas series
        data with the scores
    categories : list or dictionary, optional
        the categories to use from catField
    levels : list or dictionary, optional
        the levels or order used in ordField.
    test : {"pearson", "fisher", "freeman-tukey", "g", "mod-log", "neyman", "power"}, optional
        the test of independence to use. Default is "pearson".
    cc : {None, "yates", "pearson", "williams"}, optional
        method for continuity correction
    lambd : {float, "cressie-read", "likelihood-ratio", "mod-log", "pearson", "freeman-tukey", "neyman"}, optional
        either name of test or specific value. Default is "cressie-read" i.e. lambda of 2/3. Only applies to Power Divergence test.
        
    Returns
    -------
    A dataframe with:
    
    * *category 1*, one of the two categories being compared
    * *category 2*, second of the two categories being compared
    * *statistic*, the test statistic
    * *df*, the degrees of freedom, if applicable
    * *p-value*, the p-value (significance)
    * *adj. p-value*, the Bonferroni adjusted p-value
    
    Notes
    -----
    This function selects each possible pair of categories and then simply runs a Mood-Median test, using only those two categories.
    
    See ts_mood_median() for details of the calculations.
    
    The Bonferroni adjustment is simply:
    $$p_{adj} = \\min \\left(p \\times n_{comp}, 1\\right)$$
    $$n_{comp} = \\frac{k\\times\\left(k-1\\right)}{2}
    
    *Symbols used:*
    
    * \\(n_{comp}\\), number of comparisons (pairs)
    * \\(k\\), number of categories
    
    The R function pairwiseMedianTest from the rcompanion package, as well as the pairwise.mood.medtest function from the RVAideMemoire package, produce the same result, but will apply the Pearson continuity correction.
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
        
    '''
    
    #create the cross table    
    ct = tab_cross(ordField, catField, order1=levels, order2=categories, totals="include")
    
    #basic counts
    k = ct.shape[1]-1
    
    ncomp = (k * (k - 1)) / 2
    res = pd.DataFrame()    
    selCats= pd.Series(dtype="object")
    resRow = 0
    for i in range(0, k-1):
        for j in range(i + 1,k):
            res.at[resRow, 0] = ct.columns[i]
            res.at[resRow, 1] = ct.columns[j]
            
            selCats.at[0] = res.iloc[resRow, 0]
            selCats.at[1] = res.iloc[resRow, 1]
            
            tstRes = ts_mood_median(catField, ordField, selCats, levels, test, cc, lambd)
            
            if test=="fisher":                
                res.at[resRow, 2] = None
                res.at[resRow, 3] = None
                res.at[resRow, 4] = tstRes
                res.at[resRow, 5] = tstRes
                res.at[resRow, 6] = "Fisher exact"
            else:
                res.at[resRow, 2] = tstRes.iloc[0,3]
                res.at[resRow, 3] = tstRes.iloc[0,4]
                res.at[resRow, 4] = tstRes.iloc[0,5]
                res.at[resRow, 5] = tstRes.iloc[0,5]
                res.at[resRow, 6] = tstRes.iloc[0,8]
            
            res.at[resRow, 5] = res.iloc[resRow, 4] * ncomp
            if res.iloc[resRow, 5] > 1:
                res.at[resRow, 5] = 1            
            
            resRow = resRow + 1
    
    colNames = ["category 1","category 2","statistic", "df", "p-value","adj. p-value","test"]
    res.columns=colNames
    
    return res