import pandas as pd
from ..effect_sizes.convert_es import es_convert

def th_vda(a, qual="vd"):
    '''
    Rules of Thumb for Vargha-Delaney A
    --------------------------
     
    This function will give a qualification (classification) for Vargha-Delaney A
    
    Parameters
    ----------
    a : float
        the Vargha-Delaney Avalue
    qual : {"vd", "sawilowsky", "cohen", "lovakov", "rosenthal"} optional 
        the rule of thumb to be used. Default is "vd" (Vargha-Delaney)
        
    Returns
    -------
    results : a pandas dataframe with.
    
    * *classification*, the qualification of the effect size
    * *reference*, a reference for the rule of thumb used
   
    Notes
    -----
    The following rules-of-thumb can be used:
    
    *"vd"* => Uses Vargha and Delaney (2000, p. 106):
    
    |\\|0.5 - a\\|| Interpretation|
    |---|----------|
    |0.00 < 0.06 | negligible |
    |0.06 < 0.14 | small |
    |0.14 < 0.21 | medium |
    |0.21 or more | large |

    "sawilowsky", "cohen", "lovakov", and "rosenthal" will use the rule-of-thumb from Cohen d, by converting VD-A first to a (Glass) Rank Biserial (Cliff delta) then to Cohen d, and use the rule of thumb from Cohen d.
    
    
    See Also
    --------
    stikpetP.effect_sizes.eff_size_vargha_delaney_a.es_vargha_delaney_a : to determine a Vargha-Delaney A
    
    stikpetP.effect_sizes.convert_es.es_convert : to convert this to Cohen d

    stikpetP.other.thumb_cohen_d.th_cohen_d : rules of thumb for Cohen d
    

    References
    ----------
    Vargha, A., & Delaney, H. D. (2000). A critique and improvement of the CL common language effect size statistics of McGraw and Wong. *Journal of Educational and Behavioral Statistics, 25*(2), 101–132. doi:10.3102/10769986025002101
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076

    '''
    if qual=="vd":
        src = "Vargha and Delaney (2000, p. 106)"
        if abs(0.5 - a) < 0.06:
            interpr = "negligible"
        elif abs(0.5 - a) < .14:
            interpr = "small"
        elif abs(0.5 - a) < .21:
            interpr = "medium"
        else:
            interpr = "large"

        res = pd.DataFrame([[interpr, src]], columns=["classification", "reference"])

    else:
        #convert to Cohen's d
        rb = es_convert(a, fr="vda", to="rb")
        d = es_convert(rb, fr="rb", to="cohend")

        res = th_cohen_d(d, qual)

    return res