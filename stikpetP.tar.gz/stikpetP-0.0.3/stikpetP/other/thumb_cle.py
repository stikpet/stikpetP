import pandas as pd

def th_cle(cle, qual="vd", convert=[]):
    '''
    Rules of Thumb for Common Language Effect Size
    ----------------------------------------------
     
    This function will give a qualification (classification) for a Common Language Effect Size (/ Vargha-Delaney A / Probability of Superiority)
    
    Parameters
    ----------
    cle : float
        the common language effect size
    qual : {"vd", "convert"}, optional
        rules-of-thumb to use, currently only 'vd' for Vargha-Delaney, otherwise a converted measure using "convert"
    convert : [], optional list
        in case to use a rule-of-thumb from a converted measure. Use first element as the measure to convert to, the second to indicate which rule-of-thum.
    
    Returns
    -------
    results : a dataframe with.
    
    * *classification*, the qualification of the effect size
    * *reference*, a reference for the rule of thumb used
    
    Notes
    -----
        
    "vd" => Vargha and Delaney (2000, p. 106)
    
    |\\(|0.5 - CLE|\\)| Interpretation|
    |---|----------|
    |0.00 < 0.06 | negligible |
    |0.06 < 0.14 | small |
    |0.14 < 0.21 | medium |
    |0.21 or more | large |

    The CLE can be converted to a Rank Biserial Coefficient using:
    $$r_b = 2\\times CLE - 1$$

    Rules of thumb from the **th_rank_biserial()** function could then be used, by setting:
    qual="convert", convert=["rb", ...]. Where the second element is any of the options in th_rank_biserial()

    This in turn can be converted to Cohen's d using (Marfo & Okyere, 2019, p.4):
    $$d = 2\\times \\phi^{-1}\\left(-\\frac{1}{r_b - 2}\\right)$$
    Rules of thumb from the **th_cohen_d()** function could then be used, by setting:
    qual="convert", convert=["cohen_d", ...]. Where the second element is any of the options in th_cohen_d()

    
    
    See Also
    --------
    stikpetP.effect_sizes.eff_size_common_language_is.es_common_language_is : to determine the CLE.
    
    stikpetP.other.thumb_rank_biserial.th_rank_biserial : for options for rules of thumb when converting to Rank Biserial.
    
    stikpetP.other.thumb_cohen_d.th_cohen_d : for options for rules of thumb when converting to Cohen d.
    
    References
    ----------
    Vargha, A., & Delaney, H. D. (2000). A critique and improvement of the CL common language effect size statistics of McGraw and Wong. *Journal of Educational and Behavioral Statistics, 25*(2), 101–132. doi:10.3102/10769986025002101
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076

    '''

    es = abs(0.5 - cle)
    #Vargha and Delaney (2000, p. 106)
    if (qual=="vd"):
        src = "Vargha and Delaney (2000, p. 106)"
        if (es < 0.06): qual = "negligible"
        elif (es < 0.14): qual = "weak"
        elif (es < 6.21): qual = "moderate"
        else: qual = "strong"

        results = pd.DataFrame([[qual, src]], columns=["classification", "reference"])
    
    elif convert[0]=="rb":
        rb = ps.es_convert(cle ,fr="cle", to="rb")
        results = th_rank_biserial(rb, qual=convert[1])

    elif convert[0]=='cohen_d':
        rb = es_convert(cle ,fr="cle", to="rb")
        d = es_convert(rb ,fr="rb", to="cohend")
        results = th_cohen_d(d, qual=convert[1])
        
    return(results)