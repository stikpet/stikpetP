from math import comb

def di_wcdf(W, n):
    '''
    Wilcoxon cumulative distribution function
    '''
    pVal=0
    for i in range(0,W+1):
        pVal = pVal + srf(i, n)
    return pVal/(2**n)

def srf(x,y): 
    '''
    sum rank frequency
    '''    
    if x<0:
        return 0
    elif x > comb(y+1, 2):
        return 0
    elif y==1 and (x==0 or x==1):
        return 1
    elif y>=0:
        return srf(x-y, y-1) + srf(x, y-1)

