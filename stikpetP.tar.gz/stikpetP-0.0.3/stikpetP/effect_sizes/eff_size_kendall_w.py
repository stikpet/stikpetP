def es_kendall_w(q, n, k):

    return q / (n * (k - 1))