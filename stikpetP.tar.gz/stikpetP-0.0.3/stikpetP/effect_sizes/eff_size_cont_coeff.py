def es_cont_coeff(chi2, n, adj=None, r=None, c=None):
    '''
    (Pearson) Contingency Coefficient
    ---------------------------------
    
    Determines the Pearson Contingency Coefficient value.
    
    Parameters
    ----------
    chi2 : float
        chi-square value
    n : int
        the sample size
    adj : {None, "sakoda"}, optional
        method to adjust the coefficient with
    r : int, optional
        number of rows (categories), only needed if adj="sakoda"
    c : int, optional
        number of rows (categories), only needed if adj="sakoda"
        
    Returns
    -------
    es: the coefficient value
    
    Notes
    -----
    The formula used is (Pearson, 1904, p. 9):
    $$C = \\sqrt{\\frac{\\chi^2}{n + \\chi^2}}$$
    
    The Sakoda adjustment will use (Sakoda, 1977, p. 778):
    $$C_{adj} = \\frac{C}{C_{max}}$$
    
    With:
    $$C_{max} = \\sqrt{\\frac{m - 1}{m}}$$
    $$m = \\min\left(r, c\\right)$$
    
    References
    ----------
    Pearson, K. (1904). *Contributions to the Mathematical Theory of Evolution. XIII. On the theory of contingency and its relation to association and normal correlation*. Dulau and Co.
    
    Sakoda, J. M. (1977). *Measures of Association for Multivariate Contingency Tables*. In Proceedings of the Social Statistics Section of the American Statistical Association: Vol. Part III (pp. 777–780).
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    es = (chi2/(n + chi2))**0.5
    
    if adj=="sakoda":
        m = r
        if (c < r):
            m = c        
        cmax = ((m - 1)/m)**0.5
        es = es/cmax
    
    return es