from statistics import mean, variance, NormalDist
import pandas as pd

def es_common_language_is(catField, scaleField, categories=None, dmu=0, method="appr"):
    '''
    Common Language (CL/CLES) (Independent Samples)
    -----------------------------------------------
    the probability that a randomly selected score from the one population will be greater than a randomly sampled score from the other population.
    
    Parameters
    ----------
    catField : dataframe or list 
        the categorical data
    scaleField : dataframe or list
        the scores
    categories : list, optional 
        to indicate which two categories of catField to use, otherwise first two found will be used.
    dmu : float, optional 
        difference according to null hypothesis (default is 0)
    method : {"appr", "brute"} : optional
        method to use, either approximate or use brute-force.
        
    Returns
    -------
    A dataframe with:
    
    * *CLE cat. 1*, the effect size for the first category
    * *CLE cat. 2*, the effect size for the second category
    
    Notes
    ------
    The formula used is (McGraw & Wong, 1992, p. 361):
    $$CL = \\Phi\\left(z\\right)$$
    
    With:
    $$z = \\frac{\\left|\\bar{x}_1 - \\bar{x}_2\\right|}{\\sqrt{s_1^2 + s_2^2}}$$
    $$s_i^2 = \\frac{\\sum_{j=1}^{n_i} \\left(x_{i,j} - \\bar{x}_i\\right)^2}{n_i - 1}$$
    $$\\bar{x}_i = \\frac{\\sum_{j=1}^{n_i} x_{i,j}}{n_i}$$
    
    *Symbols used:*
    
    * \\(x_{i,j}\\) the j-th score in category i
    * \\(n_i\\) the number of scores in category i
    * \\(\\Phi\\left(\\dots\\right)\\) the cumulative density function of the standard normal distribution
    
    The CLE for the other category is simply 1 - CLE.
    
    If the brute-force method is used, the chance of a value of one category will be higher than a random score of the second category is calculated by counting all possible pairs. In case of ties a half is added.
    
    References
    ----------
    McGraw, K. O., & Wong, S. P. (1992). A common language effect size statistic. *Psychological Bulletin, 111*(2), 361–365. https://doi.org/10.1037/0033-2909.111.2.361
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    Examples
    --------
    Example 1: Dataframe
    >>> file1 = "https://peterstatistics.com/Packages/ExampleData/GSS2012a.csv"
    >>> df1 = pd.read_csv(file1, sep=',', low_memory=False, storage_options={'User-Agent': 'Mozilla/5.0'})
    >>> ex1 = df1['age']
    >>> ex1 = ex1.replace("89 OR OLDER", "90")
    >>> es_common_language_is(df1['sex'], ex1)
       CLE FEMALE  CLE MALE
    0    0.512759  0.487241
    
    Example 2: List
    >>> scores = [20,50,80,15,40,85,30,45,70,60, None, 90,25,40,70,65, None, 70,98,40]
    >>> groups = ["nat.","int.","int.","nat.","int.", "int.","nat.","nat.","int.","int.","int.","int.","int.","int.","nat.", "int." ,None,"nat.","int.","int."]
    >>> es_common_language_is(groups, scores)
       CLE int.  CLE nat.
    0  0.726561  0.273439
    
    '''
    #convert to pandas series if needed
    if type(catField) is list:
        catField = pd.Series(catField)
    
    if type(scaleField) is list:
        scaleField = pd.Series(scaleField)
    
    #combine as one dataframe
    df = pd.concat([catField, scaleField], axis=1)
    df = df.dropna()
    
    #the two categories
    if categories is not None:
        cat1 = categories[0]
        cat2 = categories[1]
    else:
        cat1 = df.iloc[:,0].value_counts().index[0]
        cat2 = df.iloc[:,0].value_counts().index[1]
    
    #seperate the scores for each category
    x1 = list(df.iloc[:,1][df.iloc[:,0] == cat1])
    x2 = list(df.iloc[:,1][df.iloc[:,0] == cat2])
    
    #make sure they are floats
    x1 = [float(x) for x in x1]
    x2 = [float(x) for x in x2]
    
    n1 = len(x1)
    n2 = len(x2)
    n = n1 + n2
    
    var1 = variance(x1)
    var2 = variance(x2)
    m1 = mean(x1)
    m2 = mean(x2)
    
    if method=="appr":
        z = abs(m1 - m2 - dmu)/(var1 + var2)**0.5

        c1 = NormalDist().cdf(z)
        c2 = 1 - c1
    
    elif method=="brute":
        c1 = 0
        for i in x1:
            p = 0
            for j in x2:
                if i>j:
                    p = p + 1
                if i==j:
                    p = p + 0.5
            c1 = c1 + p/n2
        c1 = c1 / n1
        
        c2 = 0
        for i in x2:
            p = 0
            for j in x1:
                if i>j:
                    p = p + 1
                if i==j:
                    p = p + 0.5
            c2 = c2 + p/n1
        c2 = c2 / n2
    
    #the results
    colnames = ["CLE " + cat1, "CLE " + cat2]
    results = pd.DataFrame([[c1, c2]], columns=colnames)
    
    return(results)