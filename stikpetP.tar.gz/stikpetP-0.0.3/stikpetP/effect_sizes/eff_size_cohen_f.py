from ..effect_sizes.eff_size_eta_sq import es_eta_sq

def es_cohen_f(nomField, scaleField, categories=None, useRanks=False):
    '''
    Cohen f
    -------
    An effect size measure for regression analysis or an ANOVA test. It gives roughly the proportion of variance explained by the categorical variable.
    
    The Cohen f is often used with ANOVA, while Cohen f-squared with regression.
    
    Parameters
    ----------
    nomField : pandas series
        data with categories
    scaleField : pandas series
        data with the scores
    categories : list or dictionary, optional
        the categories to use from catField
        
    Returns
    -------
    f : float
        the Cohen f value
    
    Notes
    -----
    The formula used (Cohen, 1988, p. 284):
    $$f = \\sqrt{\\frac{\\eta^2}{1-\\eta^2}}$$
    
    Where \\(\\eta^2\\) is the value of eta-squared.
    
    It can also be calculated using (Cohen, 1988, p. 371):
    $$f = \\frac{\\sigma_{\\mu}}{\\sigma}$$
    With:
    $$\\sigma_{\\mu} = \\sqrt{\\frac{SS_b}{n}}$$
    $$\\sigma = \\sqrt{\\frac{SS_w}{n}}$$
    
    Where \\(SS_i\\) is the sum of squared differences, see the Fisher one-way ANOVA for details on how to calculate these.
    
    The \\(f^2\\) can be found in Cohen (1988, p. 410).
    
    References
    ----------
    Cohen, J. (1988). *Statistical power analysis for the behavioral sciences* (2nd ed.). L. Erlbaum Associates.
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    
    eta2 = es_eta_sq(nomField, scaleField, categories, useRanks=useRanks)
    
    f2 = eta2 / (1 - eta2)
        
    return (f2)**0.5