import pandas as pd
from statistics import NormalDist
from ..effect_sizes.eff_size_cohen_d_os import es_cohen_d_os
from ..correlations.cor_rank_biserial_os import r_rank_biserial_os

def es_common_language_os(scores, levels=None, mu=None, version="brute"):
    '''
    Common Language Effect Size (One-Sample)
    -----------------------------------------------
    The Common Language Effect Size is most often used for independent samples or paired samples, but some have adapted the concept for one-sample as well.
    
    It is the probability of taking a random score and the probability it is higher than the selected value: 
    $$P(X > \\mu_{H_0})$$
    
    Some will also argue to count ties equally, which makes the definition:
    $$P(X > \\mu_{H_0}) + \\frac{P(X = \\mu_{H_0})}{2}$$
    
    This version is implemented in MatLab (see <a href="https://nl.mathworks.com/matlabcentral/fileexchange/113020-cles">here</a>) based on a Python version from Tulimieri (2021) 
    
    For scale data, an approximation using the standard normal distribution is also available using Cohen's d, alternatively a conversion via the rank-biserial coefficient can be done. These two are used in R’s *effectsize* library from Ben-Shachar et al. (2020).

    Parameters
    ----------
    scores : dataframe or list
        the scores
    levels : list or dictionary, optional
        the scores in order
    mu : float, optional 
        test statistic (default is mid-range)
    method : {"brute", "brute-it", "rb", "normal"} : optional
        method to use. see details
        
    Returns
    -------
    CLES : float
        the Common Language Effect Size
    
    Notes
    ------
    For "brute" simply counts all scores above the test statistic and half of the ones that are equal (Tulimieri, 2021):
    $$CL = P(X > \\mu_{H_0}) + \\frac{P(X = \\mu_{H_0})}{2}$$

    With "brute-it" the ties are ignored (it = ignore ties):
    $$CL = P(X > \\mu_{H_0})$$

    The "normal", uses Cohen's d and a normal approximation (Ben-Shachar et al., 2020):
    $$CL = \\Phi\\left(\\frac{d'}{\\sqrt{2}}\\right)$$

    Where \\(d'\\) is Cohen's d for one-sample, and \\(\\Phi\\left(\\dots\\right)\\) the cumulative density function of the normal distribution
    This is like a one-sample version of the McGraw and Wong (1992, p. 361) version with the independent samples.

    The "rb", uses the rank-biserial correlation coefficient (Ben-Shachar et al., 2020):
    $$CL = \\frac{1+r_b}{2}$$

    The CLE can be converted to a Rank Biserial (= Cliff delta) using the **es_convert()** function. This can then be converted to a Cohen d, and then the rules-of-thumb for Cohen d could be used (**th_cohen_d()**)
    
    The CLE for the other category is simply 1 - CLE, except for the case where ties are ignored ("brute-it").

    See Also
    --------
    stikpetP.effect_sizes.eff_size_cohen_d_os.es_cohen_d_os : Cohen d' for one-sample
    stikpetP.correlations.cor_rank_biserial_os.r_rank_biserial_os : Rank Biserial Correlation Coefficient (one-sample)
    stikpetP.effect_sizes.convert_es.es_convert : to convert an CLE to a rank biserial use `fr="cle", to="rb"`. To convert the result to Cohen d, use `fr="rb", to="cohend"`.
    stikpetP.other.thumb_cohen_d.th_cohen_d : rules of thumb for Cohen d
    
    References
    ----------
    Ben-Shachar, M., Lüdecke, D., & Makowski, D. (2020). effectsize: Estimation of Effect Size Indices and Standardized Parameters. *Journal of Open Source Software, 5*(56), 1–7. doi:10.21105/joss.02815
    
    Grissom, R. J. (1994). Statistical analysis of ordinal categorical status after therapies. *Journal of Consulting and Clinical Psychology, 62*(2), 281–284. doi:10.1037/0022-006X.62.2.281
    
    McGraw, K. O., & Wong, S. P. (1992). A common language effect size statistic. *Psychological Bulletin, 111*(2), 361–365. doi:10.1037/0033-2909.111.2.361

    Tulimieri, D. (2021). CLES/CLES. https://github.com/tulimid1/CLES/tree/main
    
    Wolfe, D. A., & Hogg, R. V. (1971). On constructing statistics and reporting data. *The American Statistician, 25*(4), 27–30. doi:10.1080/00031305.1971.10477278
    
    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    if type(scores) is list:
        scores = pd.Series(scores)
    
    #remove missing values
    scores = scores.dropna()
    if levels is not None:
        scores = scores.replace(levels)
        scores = pd.to_numeric(scores)
    else:
        scores = pd.to_numeric(scores)
    
    scores = scores.sort_values()
    n = len(scores)

    #set hypothesized median to mid range if not provided
    if mu is None:
        mu = (min(scores) + max(scores)) / 2
    
    if version=="brute-it":
        n_gt = sum([1 for i in scores if i > mu])
        cles = n_gt / n
    elif version=="brute":
        n_gt = sum([1 for i in scores if i > mu])
        n_eq = sum([1 for i in scores if i == mu])
        cles = n_gt / n + 1/2*(n_eq/n)
    elif version=="rb":
        rb = r_rank_biserial_os(scores, mu=mu).iloc[0,1]
        cles = (1 + rb)/2
    elif version=="normal":
        d_os = es_cohen_d_os(scores, mu=mu)
        cles = NormalDist().cdf(d_os/(2**0.5))
    return cles