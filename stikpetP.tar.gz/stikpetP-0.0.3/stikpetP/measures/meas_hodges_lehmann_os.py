import pandas as pd
from statistics import median

def es_hodges_lehmann_os(scores, levels=None):
    '''
    Common Language Effect Size (One-Sample)
    ----------------------------------------
    The Hodges-Lehmann Estimate (Hodges & Lehmann, 1963) for a one-sample scenario, is the median of the Walsh averages. The Walsh averages (Walsh, 1949a, 1949b) are the average of each possible pair by taking one score and combining it with each of the other scores. Note that each is only counted once, so taking the second and fifth score is the same as taking the fifth and the second, so only one of these is used. It does also include self-pairs, e.g. the third score and third score.
    
    It is in the one-sample case therefor a measure of central tendancy and sometimes referred to as the pseudo median.
    
    Parameters
    ----------
    scores : dataframe or list
        the scores
    levels : list or dictionary, optional
        the scores in order
    
    Returns
    -------
    HL : float
        the Hodges-Lehmann Estimate
    
    Notes
    ------
    The formula used (Hodges & Lehmann, 1963, p. 599):
    
    $$HL = \\text{median}\\left(\\frac{x_i + x_j}{2} | i \\leq i \\leq j \\leq n\\right)$$

    
    References
    ----------
    Hodges, J. L., & Lehmann, E. L. (1963). Estimates of location based on rank tests. *The Annals of Mathematical Statistics, 34*(2), 598–611. doi:10.1214/aoms/1177704172
    
    Monahan, J. F. (1984). Algorithm 616: Fast computation of the Hodges-Lehmann location estimator. *ACM Transactions on Mathematical Software, 10*(3), 265–270. doi:10.1145/1271.319414
    
    Walsh, J. E. (1949a). Applications of some significance tests for the median which are valid under very general conditions. Journal of the American Statistical Association, 44(247), 342–355. doi:10.1080/01621459.1949.10483311
    
    Walsh, J. E. (1949b). Some significance tests for the median which are valid under very general conditions. *The Annals of Mathematical Statistics, 20*(1), 64–81. doi:10.1214/aoms/1177730091

    Author
    ------
    Made by P. Stikker
    
    Companion website: https://PeterStatistics.com  
    YouTube channel: https://www.youtube.com/stikpet  
    Donations: https://www.patreon.com/bePatron?u=19398076
    
    '''
    if type(scores) is list:
        scores = pd.Series(scores)
    
    #remove missing values
    scores = scores.dropna()

    #apply levels
    if levels is not None:
        scores = scores.replace(levels)
        scores = pd.to_numeric(scores)
    else:
        scores = pd.to_numeric(scores)

    #sample size
    n = len(scores)

    #convert to list
    scores = list(scores)
    
    #Walsh Averages
    walsh = []
    for i in range(0, n):
        for j in range(i, n):
            walsh.append((scores[i] + scores[j])/2)

    #Hodges-Lehmann Estimate
    HL = median(walsh)
    return HL