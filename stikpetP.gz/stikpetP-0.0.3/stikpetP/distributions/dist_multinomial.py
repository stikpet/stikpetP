from math import gamma

def di_mpmf(counts, probs):
    nr = len(counts)
    
    freq = [0]*nr
    prs = [0]*nr

    for i in range(0, nr):
        freq[i] = counts[i]
        prs[i] = probs[i]
    
    den = 1
    n = 0
    for i in range(0, nr):
        den = den * gamma(freq[i] + 1)
        n = n + freq[i]
    
    factor1 = gamma(1 + n) / den
    
    factor2 = 1
    for i in range(0, nr):
        factor2 = factor2 * probs[i]**(freq[i])
    
    pVal = factor1 * factor2
    
    return pVal